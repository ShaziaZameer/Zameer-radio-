package com.zameer.radio;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public final class SmartVolume47Test {
    private static int checks;
    private static void check(boolean condition,String why){if(!condition)throw new AssertionError(why);checks++;}
    private static byte[] sine(int rate,int channels,double seconds,double rms){
        int frames=(int)(seconds*rate);ByteBuffer b=ByteBuffer.allocate(frames*channels*2).order(ByteOrder.LITTLE_ENDIAN);
        for(int f=0;f<frames;f++){short v=(short)Math.round(Math.min(.999,rms*Math.sqrt(2))*32767*Math.sin(2*Math.PI*1000*f/rate));for(int c=0;c<channels;c++)b.putShort(c==1?(short)-v:v);}
        return b.array();
    }
    private static byte[] run(byte[] pcm,int rate,int channels,boolean enabled,int fragment){
        SmartVolumeEngine e=new SmartVolumeEngine(rate,channels);ByteBuffer result=ByteBuffer.allocate(pcm.length+e.maximumPendingBytes());
        for(int at=0;at<pcm.length;at+=fragment)e.queue(ByteBuffer.wrap(pcm,at,Math.min(fragment,pcm.length-at)),result,enabled);
        e.drain(result,enabled);check(result.position()==pcm.length,"No samples lost or added, including final short block");
        return Arrays.copyOf(result.array(),result.position());
    }
    private static double rms(byte[] b,int from){double sum=0;int n=0;ByteBuffer p=ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);p.position(from-from%2);while(p.remaining()>=2){double v=p.getShort()/32768.0;sum+=v*v;n++;}return Math.sqrt(sum/n);}
    private static double peak(byte[] b){int n=0;ByteBuffer p=ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);while(p.remaining()>=2)n=Math.max(n,Math.abs((int)p.getShort()));return n/32768.0;}
    public static void main(String[] args){
        for(int rate:new int[]{8000,44100,48000,96000})for(int channels:new int[]{1,2}){
            byte[] normal=sine(rate,channels,1.237,.1);
            check(Arrays.equals(normal,run(normal,rate,channels,false,137)),"Off is byte-identical at "+rate+" Hz / "+channels+" channels");
            check(Arrays.equals(normal,run(normal,rate,channels,true,1003)),"Balanced tone remains transparent at "+rate+" Hz / "+channels+" channels");
        }
        int rate=48000;
        byte[] quiet=sine(rate,2,12,.025),raised=run(quiet,rate,2,true,4093);
        double increase=20*Math.log10(rms(raised,raised.length-rate*4)/rms(quiet,quiet.length-rate*4));
        check(increase>5.8&&increase<=6.01,"Quiet station gains at most 6 dB: "+increase);
        check(Arrays.equals(Arrays.copyOfRange(quiet,0,rate),Arrays.copyOfRange(raised,0,rate)),"Observe input before increasing volume");
        byte[] quietChunks=run(quiet,rate,2,true,7);check(Arrays.equals(raised,quietChunks),"Identical result across arbitrary decoder chunk boundaries");
        ByteBuffer stereo=ByteBuffer.wrap(raised).order(ByteOrder.LITTLE_ENDIAN);
        while(stereo.remaining()>=4){int l=stereo.getShort(),r=stereo.getShort();if(Math.abs(l+r)>1)throw new AssertionError("Stereo image shifted");}
        check(true,"Same gain preserves stereo ratio and phase");
        byte[] loud=run(sine(rate,2,8,.3),rate,2,true,2048);double balanced=rms(loud,loud.length-rate*4);
        check(balanced>.085&&balanced<.12,"Loud station moves toward target, RMS "+balanced);
        check(peak(loud)<=SmartVolumeEngine.PEAK_CEILING+1.0/32768,"Loud sine peak ceiling");
        byte[] transientAudio=Arrays.copyOf(quiet,quiet.length+rate*4);
        for(int i=quiet.length;i<quiet.length+1920;i+=2){transientAudio[i]=(byte)255;transientAudio[i+1]=127;}
        byte[] transientOutput=run(transientAudio,rate,2,true,999);
        check(peak(transientOutput)<=SmartVolumeEngine.PEAK_CEILING+1.0/32768,"Sudden full-scale transient after quiet audio never clips");
        byte[] silence=new byte[rate*4];check(Arrays.equals(silence,run(silence,rate,2,true,613)),"Digital silence stays silent");
        byte[] noise=sine(rate,2,3,.001);check(Arrays.equals(noise,run(noise,rate,2,true,997)),"Very low-level background is not amplified");
        byte[] afterQuiet=Arrays.copyOf(quiet,quiet.length+noise.length);System.arraycopy(noise,0,afterQuiet,quiet.length,noise.length);
        byte[] afterQuietOutput=run(afterQuiet,rate,2,true,500);
        check(rms(afterQuietOutput,quiet.length)<=rms(noise,0)+1.0/32768,"Noise after boosted programme is not raised");
        SmartVolumeEngine e=new SmartVolumeEngine(rate,2);ByteBuffer output=ByteBuffer.allocate(quiet.length*2+10000);
        e.queue(ByteBuffer.wrap(quiet),output,true);e.drain(output,true);e.reset();output.clear();
        e.queue(ByteBuffer.wrap(quiet),output,false);e.drain(output,false);
        check(Arrays.equals(quiet,Arrays.copyOf(output.array(),output.position())),"Disable/reset restores exact original PCM");
        e.reset();output.clear();byte[] normal=sine(rate,2,1,.1);e.queue(ByteBuffer.wrap(normal),output,true);e.drain(output,true);
        check(Arrays.equals(normal,Arrays.copyOf(output.array(),output.position())),"Next station does not inherit previous gain");
        byte[] tail={1,2,3,4,5};check(Arrays.equals(tail,run(tail,rate,2,false,1)),"Off mode preserves odd fragment tail");
        check(e.maximumPendingBytes()<=rate*4*.021,"Algorithm buffer is at most about 20 ms");
        System.out.println(checks+" Smart Volume signal checks passed; quiet gain="+increase+" dB, loud RMS="+balanced+", transient peak="+peak(transientOutput)+". No resampling or codec changes.");
    }
}
