package com.zameer.radio;
public class SmartStreaming40Test {
 static int n;static void ok(boolean b){n++;if(!b)throw new AssertionError("Check "+n);}
 public static void main(String[] args){
  SmartBufferPolicy buffer=new SmartBufferPolicy();
  ok(buffer.requiredMs(0,0)==8000);
  for(int i=0;i<20;i++)ok(buffer.requiredMs(i,0)==8000);
  ok(buffer.requiredMs(1000,1)==12000);ok(buffer.requiredMs(2000,2)==16000);
  ok(buffer.requiredMs(3000,3)==20000);ok(buffer.requiredMs(4000,4)==20000);
  ok(buffer.requiredMs(124000,5)==8000);buffer.reset();ok(buffer.requiredMs(125000,6)==8000);
  ok(SmartBufferPolicy.capToLiveWindow(20000000,6000000)==3000000);
  NetworkHandoverPolicy p=new NetworkHandoverPolicy();
  p.validated("wifi",0);ok(!p.reconnect(5000,0)); // Initial connection is not a handover.
  p.validated("wifi",1000);ok(!p.reconnect(5000,0));
  p.validated("cell",6000);ok(!p.reconnect(6000,0));ok(!p.reconnect(9999,0));ok(p.reconnect(10000,0));ok(!p.reconnect(14000,0));
  p.validated("wifi",15000);ok(!p.reconnect(15000,0));ok(!p.reconnect(19000,0)); // Rate limit.
  ok(p.reconnect(30000,0));
  p.validated("cell",40000);ok(!p.reconnect(40000,0));
  for(int i=1;i<=12;i++)ok(!p.reconnect(40000+i*2000,i*300)); // Advancing buffer survives.
  ok(!p.reconnect(71000,3600)); // Expired change cannot cause a late reconnect.
  p.lost("old-wifi");p.validated("cell",72000);ok(!p.reconnect(78000,0));
  p.lost("cell");p.validated("cell",80000);ok(!p.reconnect(80000,0));ok(p.reconnect(84000,0));
  p.validated("wifi",90000);p.cancel();ok(!p.reconnect(95000,0)); // Pause/stop cancels handover.
  System.out.println(n+" checks passed: buffer growth without bitrate changes, duplicate events, stable restore, handover progress, cooldown, loss, pause cancellation.");
 }
}
