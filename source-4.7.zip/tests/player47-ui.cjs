const {chromium}=require('playwright');
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../app/src/main/assets'),out=path.resolve(__dirname,'../qa/4.7');
const server=http.createServer((req,res)=>{try{const p=path.join(root,req.url==='/'?'index.html':req.url.split('?')[0]);res.setHeader('Content-Type',p.endsWith('.js')?'text/javascript':p.endsWith('.css')?'text/css':'text/html');res.end(fs.readFileSync(p));}catch(_){res.writeHead(404);res.end();}});
(async()=>{
 fs.mkdirSync(out,{recursive:true});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});let page;
 try {
  page=await browser.newPage({viewport:{width:393,height:851}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
  // The native bridge delivers state asynchronously: wait for the rendered
  // station, not just the mock transport's synchronously updated index.
  const renderedStation=(index,count)=>page.waitForFunction(({index,count})=>at===index&&q.length===count&&document.querySelector('#now').textContent===q[index].name&&document.querySelector('#playerState').textContent.includes((index+1)+' / '+count),{index,count});
  await page.addInitScript(()=>{
   window.q=[];window.at=0;window.position=0;window.starts=0;window.visited=new Set();window.played=[];window.transport=0;window.applied={};window.playing=false;
   window.emit=()=>onNativeState({...q[at],playing,wants:playing,state:3,index:at,count:q.length,duration:(q[at]?.duration||0)*1000,position,transportRequest:transport,smartVolumeStatus:applied.smartVolume===false?"off":q[at]?.kind==="podcast"?"radioOnly":q.length?"active":"waiting",radioInfo:{}});
   window.AndroidPlayer={language:()=> 'hi',playbackVolume:()=>1,consumeWelcome:()=>false,settings:j=>Object.assign(applied,JSON.parse(j)),library:()=>'[]',usageStats:()=>'{}',saveRadioDirectory:()=>{},consumeVoice:()=>'',consumeLaunch:()=>'{}',playbackQueue:()=>JSON.stringify(q),requestRadio:id=>setTimeout(()=>onRadioResponse(id,503,'{}'),5),
    playQueueWithId:(j,i,s)=>{q=JSON.parse(j);at=i;position=0;starts++;transport=s;playing=true;visited=new Set([q[at].url]);played=[q[at].url];setTimeout(emit,0);},
    appendRadioQueue:(j,url,s)=>{if(playing&&transport===s&&q[at]?.url===url){q=JSON.parse(j);setTimeout(emit,0);}},
    commandWithId:(a,v,s)=>{transport=s;if(a==='seek')position=v;if(['pause','stop','clearQueue'].includes(a))playing=false;if(a==='clearQueue'||a==='stop'){q=[];at=0;}if(a==='play')playing=true;if(['next','prev'].includes(a)){const next=RadioCore.cycleIndex(q,q[at]?.id,visited,a==='prev'?-1:1,q[at]?.kind!=='podcast'&&!!applied.radioShuffle);if(next>=0){at=next;position=0;visited.add(q[at].url);played.push(q[at].url);}}setTimeout(emit,0);}
   };
  });
  await page.goto('http://127.0.0.1:'+server.address().port);
  if(errors.length)throw Error('Startup errors: '+errors.join('; '));
  await page.waitForFunction(()=>window.ZrRadio);
  assert.deepEqual(await page.evaluate(()=>({slider:Number(document.querySelector('#volume').value),native:applied.volume,audio:document.querySelector('#audio').volume,label:document.querySelector('#volumeValue').textContent})),{slider:1,native:1,audio:1,label:'100%'});
  await page.evaluate(()=>{const v=document.querySelector('#volume');v.value='0.35';v.dispatchEvent(new Event('input'));});await page.reload();await page.waitForFunction(()=>window.ZrRadio);
  assert.equal(await page.evaluate(()=>applied.volume),0.35);assert.equal(await page.textContent('#volumeValue'),'35%');
  await page.evaluate(()=>{const v=document.querySelector('#volume');v.value='0';v.dispatchEvent(new Event('input'));});await page.reload();await page.waitForFunction(()=>window.ZrRadio);assert.equal(await page.evaluate(()=>applied.volume),0);
  await page.evaluate(()=>document.querySelector('#restoreVolume').click());assert.equal(await page.evaluate(()=>applied.volume),1);
  assert.equal(await page.isChecked('#smartVolume'),true);assert.equal(await page.evaluate(()=>applied.smartVolume),true);
  await page.evaluate(()=>document.querySelector('#smartVolume').click());assert.equal(await page.evaluate(()=>applied.smartVolume),false);
  await page.reload();await page.waitForFunction(()=>window.ZrRadio);assert.equal(await page.isChecked('#smartVolume'),false);assert.equal(await page.evaluate(()=>applied.smartVolume),false);assert.match(await page.textContent('#smartVolumeStatus'),/बंद/);
  await page.evaluate(()=>document.querySelector('#smartVolume').click());assert.equal(await page.evaluate(()=>applied.smartVolume),true);
  const moods=await page.evaluate(()=>Object.keys(RadioCore.groups));
  const audit=[];
  for(const mood of moods){
   await page.selectOption('#genreFilter',mood);await page.waitForTimeout(180);
   const result=await page.evaluate(()=>({list:ZrRadio.selectedRows().map(s=>s.url),queue:q.map(s=>s.url),status:document.querySelector('#discoveryStatus').textContent,playing}));
   assert.deepEqual(new Set(result.queue),new Set(result.list),mood+' list/queue mismatch');
   assert(result.status.startsWith((mood==='kavita'?6:result.list.length)+' '),mood+' visible count');
   if(!result.list.length)assert.equal(result.playing,false,mood+' must not play off-theme fallback');
   audit.push({mood,count:result.queue.length});
  }
  await page.selectOption('#genreFilter','kavita');
  assert.equal(await page.locator('#kavitaRecordings .recorded-poem').count(),6);
  assert.equal(await page.evaluate(()=>playing),false);
  await page.locator('#kavitaRecordings .recorded-poem').first().getByRole('button',{name:'▶ कविता सुनें',exact:true}).click();await renderedStation(0,6);await page.waitForSelector('#nowDialog[open]');
  assert(await page.evaluate(()=>q.every(e=>e.kind==='podcast'&&e.url.startsWith('https://media.transistor.fm/'))));
  assert.match(await page.textContent('#playerState'),/रिकॉर्डेड कविता/);assert.equal(await page.textContent('#npStatus'),'रिकॉर्डेड कविता');assert(!((await page.textContent('#npBroadcastNote')).includes('लाइव')));assert.equal(await page.locator('#npShuffle').isVisible(),false);
  assert.match(await page.textContent('#smartVolumeStatus'),/रिकॉर्डिंग की मूल आवाज़/);
  for(let i=1;i<=6;i++){await page.click('#npNext');await renderedStation(i%6,6);}
  await page.click('#npPrev');await renderedStation(5,6);
  await page.evaluate(()=>{const e=document.querySelector('#npSeek');e.value='30000';e.dispatchEvent(new Event('change'));});await page.waitForFunction(()=>document.querySelector('#npTime').textContent.startsWith('0:30'));
  await page.click('#npPlay');await page.waitForFunction(()=>!playing);await page.click('#npPlay');await page.waitForFunction(()=>playing);assert.equal(await page.evaluate(()=>position),30000);
  await page.screenshot({path:path.join(out,'recorded-poetry-player.png')});await page.click('#closeNow');
  assert.equal(await page.evaluate(()=>ZrRadio.pool().some(e=>e.kind==='podcast')),false);
  await page.fill('#stationSearch','पंत');await page.waitForTimeout(300);assert.equal(await page.locator('#kavitaRecordings .recorded-poem').count(),1);
  await page.locator('#kavitaRecordings .recorded-poem').getByRole('button',{name:'▶ कविता सुनें',exact:true}).click();await renderedStation(0,1);await page.waitForSelector('#nowDialog[open]');await page.click('#npNext');await renderedStation(0,1);await page.click('#closeNow');
  await page.fill('#stationSearch','News');await page.waitForTimeout(300);assert.equal(await page.locator('#kavitaRecordings .recorded-poem').count(),0);
  await page.selectOption('#genreFilter','ghazal');await renderedStation(0,4);
  assert.match(await page.textContent('#smartVolumeStatus'),/सक्रिय/);
  const initial=await page.evaluate(()=>starts),expected=await page.evaluate(()=>q.map(s=>s.url));
  for(let i=0;i<expected.length;i++){await page.click('#next');await renderedStation((i+1)%expected.length,expected.length);await page.waitForFunction(n=>played.length===n,i+2);}
  assert.deepEqual(await page.evaluate(()=>played),[...expected,expected[0]]);assert.equal(await page.evaluate(()=>starts),initial);
  await page.click('#prev');await renderedStation(3,4);assert.match(await page.textContent('#playerState'),/4 \/ 4/);
  await page.click('#openNow');await page.waitForSelector('#nowDialog[open]');await page.click('#npPrev');await renderedStation(2,4);await page.click('#npNext');await renderedStation(3,4);await page.click('#npNext');await renderedStation(0,4);
  await page.screenshot({path:path.join(out,'player-next-previous.png')});await page.click('#closeNow');
  await page.selectOption('#genreFilter','naat');await page.waitForFunction(()=>q.length===1);
  assert.equal(await page.evaluate(()=>q.some(e=>e.kind==='podcast')),false);assert.equal(await page.evaluate(()=>q[0].name),'DC Naat Radio');assert.equal(await page.locator('#programmeLive .radio-card').count(),3);
  assert((await page.textContent('#programmeLive')).includes('मुख्य मूड सूची और उसकी कतार में शामिल नहीं'));
  await page.locator('#discoveryStatus').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(out,'naat-separated-programmes.png')});
  await page.locator('#programmeLive .radio-card').first().getByRole('button',{name:/मिश्रित लाइव/}).click();await page.waitForFunction(()=>q.length===3);await page.waitForSelector('#nowDialog[open]');await page.click('#closeNow');
  await page.selectOption('#genreFilter','ghazal');await page.fill('#stationSearch','News');await page.waitForTimeout(220);assert.equal(await page.evaluate(()=>ZrRadio.selectedRows().length),0);
  await page.evaluate(()=>ZrRadio.ask('सुकून रेडियो चलाओ'));await page.waitForTimeout(180);assert.equal(await page.evaluate(()=>q.length),2);assert.equal(await page.evaluate(()=>playing),true);
  await page.evaluate(()=>ZrRadio.ask('कविता चलाओ'));await page.waitForTimeout(180);assert.equal(await page.evaluate(()=>q.length),0);assert.equal(await page.evaluate(()=>playing),false);assert.equal(await page.locator('#programmeLive .radio-card').count(),0);
  await page.evaluate(()=>ZrRadio.ask('ग़ज़ल चलाओ'));await page.waitForFunction(()=>q.length===4);
  await page.click('#radioShuffle');for(let i=0;i<4;i++){await page.click('#next');await page.waitForTimeout(20);}const shuffled=await page.evaluate(()=>played);assert.equal(new Set(shuffled.slice(0,4)).size,4);assert.notEqual(shuffled[3],shuffled[4]);
  await page.selectOption('#uiLanguage','en');await page.selectOption('#genreFilter','naat');await page.waitForFunction(()=>document.querySelector('#discoveryStatus').textContent.startsWith('1 stations'));
  await page.setViewportSize({width:320,height:568});await page.click('#openNow');await page.waitForSelector('#nowDialog[open]');assert(await page.evaluate(()=>document.querySelector('#nowDialog').scrollWidth<=innerWidth));await page.screenshot({path:path.join(out,'player-small.png')});
  await page.click('#closeNow');await page.selectOption('#genreFilter','kavita');await page.waitForTimeout(100);assert.match(await page.textContent('#kavitaRecordings'),/Recorded recitations/);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);await page.screenshot({path:path.join(out,'recorded-poetry-list-320.png'),fullPage:true});
  await page.evaluate(()=>{ZrNavigation.go('settings');});await page.waitForTimeout(100);await page.locator('#smartVolume').scrollIntoViewIfNeeded();
  assert.equal(await page.locator('#smartVolume').isVisible(),true);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await page.evaluate(()=>{onNativeState({...q[at],smartVolumeStatus:'unsupported'});});assert.match(await page.textContent('#smartVolumeStatus'),/Unavailable for this audio format/);
  await page.screenshot({path:path.join(out,'smart-volume-settings-320.png')});
  assert.deepEqual(errors,[]);fs.writeFileSync(path.join(out,'ui-audit.json'),JSON.stringify(audit,null,2));
  console.log('PASS: Smart Volume default, native setting, saved opt-out, recording bypass, active and unsupported status, narrow settings layout; six recorded poems, native queue parity, Next/Previous wrapping, seeking, pause/resume, Hindi/English labels, source links, filtered recording queue, no live-radio pool pollution, 320px layout; all 13 mood list/queue counts; no off-theme autoplay; search intersection; mixed programme separation; Next/Previous wrapping in both players; shuffle; 320px layout.');
 } catch(error){if(page){await page.screenshot({path:path.join(out,'ui-failure.png')}).catch(()=>{});fs.writeFileSync(path.join(out,'ui-failure.json'),JSON.stringify(await page.evaluate(()=>({queue:q.map(s=>({id:s.id,name:s.name})),at,transport,starts,playing,player:document.querySelector('#playerState').textContent,station:document.querySelector('#now').textContent,status:document.querySelector('#discoveryStatus').textContent})),null,2));}throw error;
 } finally {await browser.close();server.close();}
})().catch(e=>{console.error(e);server.close();process.exit(1)});
