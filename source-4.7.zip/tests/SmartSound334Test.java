package com.zameer.radio;
public class SmartSound334Test {
 public static void main(String[] args){int checks=0;
  for(String tags:new String[]{"news,talk","poetry,shayari","naat,community"}){if(!SmartSoundProfile.choose(tags).equals("speech"))throw new AssertionError(tags);checks++;}
  for(String tags:new String[]{"bollywood,romantic","oldies","",null,"newschool pop"}){if(!SmartSoundProfile.choose(tags).equals("music"))throw new AssertionError(tags);checks++;}
  for(String mode:new String[]{"music","speech"})for(int hz:new int[]{60,230,910,3600,14000}){int db=SmartSoundProfile.level(mode,hz*1000,(short)-1500,(short)1500);if(db>0||db< -300)throw new AssertionError("Unexpected gain");checks++;}
  if(SmartSoundProfile.level("speech",60000,(short)-100,(short)100)!=-100)throw new AssertionError("Device bounds");checks++;
  if(SmartSoundProfile.level("speech",910000,(short)-1500,(short)1500)!=0)throw new AssertionError("Voice band must stay neutral");checks++;
  System.out.println(checks+" Smart Sound profile, no-gain and device-bound checks passed.");
 }
}
