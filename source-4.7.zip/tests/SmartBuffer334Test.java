package com.zameer.radio;
public class SmartBuffer334Test {
 public static void main(String[] args){int n=0;SmartBufferPolicy p=new SmartBufferPolicy();
  if(p.requiredMs(1000,1000)!=8000)throw new AssertionError("First interruption");n++;
  for(int i=0;i<20;i++){if(p.requiredMs(1100+i,1000)!=8000)throw new AssertionError("Polling inflated target");n++;}
  if(p.requiredMs(2000,2000)!=12000||p.requiredMs(3000,3000)!=16000||p.requiredMs(4000,4000)!=20000)throw new AssertionError("Bounded adaptation");n++;
  if(p.requiredMs(124000,124000)!=8000)throw new AssertionError("Stable reset");n++;
  p.reset();if(p.requiredMs(125000,125000)!=8000)throw new AssertionError("Station reset");n++;
  if(SmartBufferPolicy.capToLiveWindow(16000000,6000000)!=3000000||SmartBufferPolicy.capToLiveWindow(16000000,-1)!=16000000)throw new AssertionError("Live window cap");n++;
  BufferWatchdog w=new BufferWatchdog();w.begin(0,0);
  if(w.stalled(11999,0,12000,60000)||!w.stalled(12000,0,12000,60000))throw new AssertionError("Radio no-progress threshold");n++;
  w.reset();w.begin(0,0);for(int i=1;i<=25;i++){if(w.stalled(i*2000,i*400,12000,60000))throw new AssertionError("Discarded advancing buffer");n++;}
  if(!w.stalled(60000,11000,12000,60000))throw new AssertionError("Total wait bound");n++;
  System.out.println(n+" adaptive live buffer, progress and latency-bound checks passed.");
 }
}
