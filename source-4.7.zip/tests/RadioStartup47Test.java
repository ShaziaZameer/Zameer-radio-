package com.zameer.radio;

public final class RadioStartup47Test {
    private static int checks;
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
    public static void main(String[] args){
        check(!SmartBufferPolicy.readyToStart(0,1,-1),"Never start with no audio");
        check(!SmartBufferPolicy.readyToStart(-1,1,-1),"Invalid duration is not ready");
        check(!SmartBufferPolicy.readyToStart(1_499_999,1,-1),"Retain a real startup cushion");
        check(SmartBufferPolicy.readyToStart(1_500_000,1,-1),"Start live radio at 1.5 seconds");
        check(SmartBufferPolicy.readyToStart(2_499_999,1,-1),"No need to wait for the former 2.5 seconds");
        check(!SmartBufferPolicy.readyToStart(2_999_999,2,-1),"Faster playback needs enough playout time");
        check(SmartBufferPolicy.readyToStart(3_000_000,2,-1),"2x playback threshold");
        check(SmartBufferPolicy.readyToStart(750_000,.5f,-1),"Slower playback threshold");
        check(!SmartBufferPolicy.readyToStart(599_999,1,1_200_000),"Short live window still needs its cushion");
        check(SmartBufferPolicy.readyToStart(600_000,1,1_200_000),"Do not wait beyond half of a short live window");
        check(!SmartBufferPolicy.readyToStart(499_999,1,100_000),"Retain minimum cushion for tiny windows");
        check(SmartBufferPolicy.readyToStart(500_000,1,100_000),"Tiny live-window bound");
        check(SmartBufferPolicy.readyToStart(1_500_000,1,0),"Unknown live offset");
        check(!SmartBufferPolicy.readyToStart(1_000_000,Float.NaN,-1),"Invalid speed is not ready");
        SmartBufferPolicy recovery=new SmartBufferPolicy();
        check(recovery.requiredMs(0,0)==8_000,"First real stall still requires 8 seconds");
        for(int i=0;i<50;i++)check(recovery.requiredMs(i,0)==8_000,"Polling cannot add interruptions");
        check(recovery.requiredMs(1000,1)==12_000,"Repeated stalls retain larger recovery buffer");
        check(recovery.requiredMs(2000,2)==16_000,"Third stall cushion");
        check(recovery.requiredMs(3000,3)==20_000,"Bounded recovery cushion");
        recovery.reset();check(recovery.requiredMs(4000,4)==8_000,"Station changes reset recovery state");
        System.out.println(checks+" radio startup checks passed: 1.5s cushion, playback speed, live-window bounds and unchanged stall protection.");
    }
}
