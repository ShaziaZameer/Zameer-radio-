package com.zameer.radio;

import java.nio.ByteBuffer;

/** Conservative stereo-linked PCM16 levelling, not a broadcast LUFS meter.
 * Fixed 10 ms blocks make behaviour independent of decoder buffer boundaries.
 * One block of look-ahead protects peaks without a nonlinear waveshaper.
 * No resampling, EQ, compression codec, sample insertion or sample removal.
 */
final class SmartVolumeEngine {
    static final double MAX_GAIN_DB=6.0, MIN_GAIN_DB=-12.0;
    static final double PEAK_CEILING=Math.pow(10,-1.5/20);
    private static final double TARGET_RMS=0.1, NOISE_FLOOR=Math.pow(10,-48.0/20);
    private final int rate,channels,frameBytes,blockBytes;
    private byte[] current,previous;
    private int currentSize,previousSize;
    private double energy,levelDb,outputDb;
    private long measuredFrames;
    private boolean wasEnabled;
    SmartVolumeEngine(int sampleRate,int channelCount){
        if(sampleRate<8000||sampleRate>192000||channelCount<1||channelCount>2)throw new IllegalArgumentException();
        rate=sampleRate;channels=channelCount;frameBytes=channels*2;
        blockBytes=Math.max(1,sampleRate/100)*frameBytes;
        current=new byte[blockBytes];previous=new byte[blockBytes];
    }
    int maximumPendingBytes(){return blockBytes*2;}
    double gainDb(){return outputDb;}
    void resetGain(){energy=0;levelDb=0;outputDb=0;measuredFrames=0;}
    void reset(){currentSize=previousSize=0;wasEnabled=false;resetGain();}
    void queue(ByteBuffer input,ByteBuffer output,boolean enabled){
        mode(enabled);
        while(input.hasRemaining()){
            int count=Math.min(input.remaining(),blockBytes-currentSize);
            input.get(current,currentSize,count);currentSize+=count;
            if(currentSize==blockBytes){
                if(previousSize>0)emit(previous,previousSize,peak(current,currentSize),output,enabled);
                byte[] swap=previous;previous=current;current=swap;previousSize=currentSize;currentSize=0;
            }
        }
    }
    void drain(ByteBuffer output,boolean enabled){
        mode(enabled);
        if(previousSize>0)emit(previous,previousSize,peak(current,currentSize),output,enabled);
        if(currentSize>0)emit(current,currentSize,0,output,enabled);
        previousSize=currentSize=0;
    }
    private void mode(boolean enabled){if(enabled!=wasEnabled){resetGain();wasEnabled=enabled;}}
    private static int sample(byte[] b,int i){return (short)((b[i]&255)|(b[i+1]<<8));}
    private static double peak(byte[] b,int size){double p=0;for(int i=0;i+1<size;i+=2)p=Math.max(p,Math.abs(sample(b,i)/32768.0));return p;}
    private void emit(byte[] bytes,int size,double nextPeak,ByteBuffer out,boolean enabled){
        if(!enabled){out.put(bytes,0,size);return;}
        int frames=size/frameBytes;
        if(frames==0){out.put(bytes,0,size);return;}
        double left=0,right=0;
        for(int i=0;i<frames;i++){
            int at=i*frameBytes;double l=sample(bytes,at)/32768.0;left+=l*l;
            if(channels==2){double r=sample(bytes,at+2)/32768.0;right+=r*r;}
        }
        double blockEnergy=Math.max(left,right)/frames,seconds=frames/(double)rate;
        double rms=Math.sqrt(blockEnergy),weight=1-Math.exp(-seconds/.5);
        energy=measuredFrames==0?blockEnergy:energy+weight*(blockEnergy-energy);measuredFrames+=frames;
        boolean quiet=rms<NOISE_FLOOR;
        double desired=quiet?0:20*Math.log10(TARGET_RMS/Math.max(NOISE_FLOOR,Math.sqrt(energy)));
        if(Math.abs(desired)<1.5)desired=0; // Preserve an already balanced station.
        desired=Math.max(MIN_GAIN_DB,Math.min(MAX_GAIN_DB,desired));
        if(measuredFrames<rate/2)desired=Math.min(0,desired); // Observe before boosting.
        levelDb+=Math.max(-6*seconds,Math.min(seconds,desired-levelDb));
        if(quiet)levelDb=Math.min(0,levelDb); // Never boost gated silence/background hiss.
        double thisPeak=peak(bytes,frames*frameBytes),aheadPeak=Math.max(thisPeak,nextPeak);
        double limitDb=aheadPeak>0?20*Math.log10(PEAK_CEILING/aheadPeak):MAX_GAIN_DB;
        double target=Math.min(levelDb,limitDb);
        double endDb=target>outputDb?Math.min(target,outputDb+seconds):target;
        double startGain=Math.pow(10,outputDb/20),endGain=Math.pow(10,endDb/20);
        double currentLimit=thisPeak>0?PEAK_CEILING/thisPeak:Double.POSITIVE_INFINITY;
        startGain=Math.min(startGain,currentLimit);endGain=Math.min(endGain,currentLimit);
        if(quiet){startGain=Math.min(1,startGain);endGain=Math.min(1,endGain);}
        // The previous block already saw this block's peak, so normal limiter
        // attacks ramp in the preceding audio instead of clipping the transient.
        for(int frame=0;frame<frames;frame++){
            double gain=startGain+(endGain-startGain)*(frame+1)/(double)frames;
            for(int channel=0;channel<channels;channel++){
                int value=(int)Math.round(sample(bytes,frame*frameBytes+channel*2)*gain);
                value=Math.max(Short.MIN_VALUE,Math.min(Short.MAX_VALUE,value));
                out.put((byte)value).put((byte)(value>>8));
            }
        }
        // A malformed final partial frame is preserved rather than silently lost.
        out.put(bytes,frames*frameBytes,size-frames*frameBytes);
        outputDb=endGain>0?20*Math.log10(endGain):MIN_GAIN_DB;
    }
}
