package com.zameer.radio;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicInteger;
import androidx.media3.common.C;
import androidx.media3.common.audio.BaseAudioProcessor;

@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
final class SmartVolumeAudioProcessor extends BaseAudioProcessor {
    private volatile boolean enabled=true,radio,configured,supported,seen;
    private volatile double gain;
    private final AtomicInteger epoch=new AtomicInteger();
    private int appliedEpoch;
    private SmartVolumeEngine engine;
    void settings(boolean value,boolean liveRadio){
        if(enabled!=value||radio!=liveRadio){enabled=value;radio=liveRadio;epoch.incrementAndGet();}
    }
    void stationChanged(){epoch.incrementAndGet();seen=false;}
    String status(){return !enabled?"off":!radio?"radioOnly":!configured?"waiting":!supported?"unsupported":!seen?"waiting":"active";}
    double gainDb(){return gain;}
    @Override protected AudioFormat onConfigure(AudioFormat format){
        boolean usable=format.encoding==C.ENCODING_PCM_16BIT&&format.channelCount>=1&&format.channelCount<=2&&format.sampleRate>=8000&&format.sampleRate<=192000;
        configured=true;supported=usable;seen=false;
        return usable?format:AudioFormat.NOT_SET;
    }
    @Override protected void onFlush(){
        supported=outputAudioFormat!=AudioFormat.NOT_SET;seen=false;gain=0;
        engine=supported?new SmartVolumeEngine(inputAudioFormat.sampleRate,inputAudioFormat.channelCount):null;
        appliedEpoch=epoch.get();
    }
    @Override public void queueInput(ByteBuffer input){
        if(!input.hasRemaining())return;
        if(engine==null){ByteBuffer output=replaceOutputBuffer(input.remaining());output.put(input).flip();return;}
        int latest=epoch.get();if(latest!=appliedEpoch){engine.resetGain();appliedEpoch=latest;gain=0;}
        ByteBuffer output=replaceOutputBuffer(input.remaining()+engine.maximumPendingBytes());
        engine.queue(input,output,enabled&&radio);output.flip();seen=true;gain=engine.gainDb();
    }
    @Override protected void onQueueEndOfStream(){
        if(engine==null)return;
        ByteBuffer output=replaceOutputBuffer(engine.maximumPendingBytes());
        engine.drain(output,enabled&&radio);output.flip();gain=engine.gainDb();
    }
    @Override protected void onReset(){engine=null;configured=false;supported=false;seen=false;gain=0;}
}
