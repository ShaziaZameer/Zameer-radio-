package com.zameer.radio;

/** One event per genuine rebuffer, not per decoder poll. Bounded extra live latency. */
final class SmartBufferPolicy {
    // Only the first live-radio start/seek uses this smaller cushion. It does
    // not change the audio format, forward-buffer size or stall recovery.
    private static final long START_BUFFER_US=1_500_000;
    static boolean readyToStart(long bufferedUs,float playbackSpeed,long liveOffsetUs){
        long goal=capToLiveWindow(START_BUFFER_US,liveOffsetUs);
        return bufferedUs>=0&&bufferedUs/Math.max(0.1f,playbackSpeed)>=goal;
    }
    private long lastEvent=Long.MIN_VALUE,lastAt=-1;
    private int interruptions;
    synchronized void reset(){lastEvent=Long.MIN_VALUE;lastAt=-1;interruptions=0;}
    synchronized long requiredMs(long now,long event){
        if(lastEvent!=event){
            if(lastAt<0||now-lastAt>=120_000)interruptions=0;
            interruptions=Math.min(4,interruptions+1);lastEvent=event;lastAt=now;
        }
        return 4_000L+4_000L*Math.max(1,interruptions);
    }
    static long capToLiveWindow(long desiredUs,long liveOffsetUs){return liveOffsetUs>0?Math.min(desiredUs,Math.max(500_000,liveOffsetUs/2)):desiredUs;}
}
