package com.zameer.radio;

import static org.junit.Assert.*;
import org.junit.Test;
import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor.AudioFormat;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Random;

/** Exercises the real Media3 processor lifecycle, including delayed tail output. */
public class SmartVolumeAudioProcessorTest {
    private SmartVolumeAudioProcessor create(boolean enabled,boolean radio) throws Exception {
        SmartVolumeAudioProcessor p=new SmartVolumeAudioProcessor();p.settings(enabled,radio);
        AudioFormat f=new AudioFormat(48000,2,C.ENCODING_PCM_16BIT);
        assertEquals(f,p.configure(f));assertTrue(p.isActive());p.flush();return p;
    }
    private static void collect(SmartVolumeAudioProcessor p,ByteArrayOutputStream out) {
        ByteBuffer b=p.getOutput();byte[] bytes=new byte[b.remaining()];b.get(bytes);out.write(bytes,0,bytes.length);
    }
    private static byte[] process(SmartVolumeAudioProcessor p,byte[] bytes,int chunk) {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        for(int i=0;i<bytes.length;i+=chunk){
            ByteBuffer b=ByteBuffer.wrap(bytes,i,Math.min(chunk,bytes.length-i));
            p.queueInput(b);assertFalse(b.hasRemaining());collect(p,out);
        }
        p.queueEndOfStream();assertFalse(p.isEnded());collect(p,out);assertTrue(p.isEnded());
        assertFalse(p.getOutput().hasRemaining());return out.toByteArray();
    }
    @Test public void disabledAndRecordingsPreserveEveryByteIncludingTail() throws Exception {
        byte[] bytes=new byte[15367];new Random(47).nextBytes(bytes);
        assertArrayEquals(bytes,process(create(false,true),bytes,17));
        assertArrayEquals(bytes,process(create(true,false),bytes,4093));
    }
    @Test public void enabledProcessorKeepsDurationAndBoundsPeaks() throws Exception {
        byte[] bytes=new byte[48000*4];new Random(48).nextBytes(bytes);
        SmartVolumeAudioProcessor p=create(true,true);byte[] result=process(p,bytes,4093);
        assertEquals(bytes.length,result.length);assertEquals("active",p.status());
        for(int i=0;i<result.length;i+=2){int value=(short)((result[i]&255)|(result[i+1]<<8));assertTrue(Math.abs(value)<=Math.ceil(32768*SmartVolumeEngine.PEAK_CEILING));}
    }
    @Test public void flushDropsOldStationTailAndResetAllowsReconfiguration() throws Exception {
        SmartVolumeAudioProcessor p=create(true,true);
        p.queueInput(ByteBuffer.wrap(new byte[120]));assertFalse(p.getOutput().hasRemaining());
        p.stationChanged();p.settings(false,true);p.flush();
        byte[] next=new byte[8000];new Random(49).nextBytes(next);
        assertArrayEquals(next,process(p,next,37));assertEquals("off",p.status());
        p.reset();p.settings(true,true);assertEquals("waiting",p.status());
        p.configure(new AudioFormat(44100,1,C.ENCODING_PCM_16BIT));p.flush();
        assertArrayEquals(new byte[882],process(p,new byte[882],441));
    }
    @Test public void unsupportedFormatsUseMedia3Bypass() throws Exception {
        SmartVolumeAudioProcessor p=new SmartVolumeAudioProcessor();p.settings(true,true);
        assertEquals("waiting",p.status());
        assertEquals(AudioFormat.NOT_SET,p.configure(new AudioFormat(48000,2,C.ENCODING_PCM_FLOAT)));
        assertFalse(p.isActive());assertEquals("unsupported",p.status());
        assertEquals(AudioFormat.NOT_SET,p.configure(new AudioFormat(48000,6,C.ENCODING_PCM_16BIT)));
        assertFalse(p.isActive());
    }
}
