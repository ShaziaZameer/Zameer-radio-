package com.zameer.radio;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaLibraryService;
import androidx.media3.session.MediaLibraryService.MediaLibrarySession;

/** Playback, recovery and sleep deadlines survive closing the activity or its WebView. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public class PlaybackService extends MediaLibraryService {
    static final RadioQueueHistory radioQueueHistory=new RadioQueueHistory();
    private static final RadioNowPlaying radioNowPlaying=new RadioNowPlaying();
    static RadioNowPlaying.Info radioInfo(String id){return radioNowPlaying.snapshot(id);}
    private ExoPlayer player;
    private SmartSound smartSound;
    private SmartRadioLoadControl smartLoadControl;
    private boolean waitingForNetwork;
    private AssistantLibrary assistantLibrary;
    private AudioManager audioManager;
    private boolean audioRegistered, routePausing;
    private String lastBluetooth="";
    private long bluetoothRemovedAt=-10000;
    private final BluetoothResumePolicy bluetoothResume=new BluetoothResumePolicy();
    private final Runnable reconnect=()->tryBluetoothResume();
    private final AudioDeviceCallback audioDevices=new AudioDeviceCallback(){
        @Override public void onAudioDevicesAdded(AudioDeviceInfo[] devices){
            if(destroyed)return;
            if(player.getPlayWhenReady())rememberBluetooth();
            if(bluetoothResume.pending(SystemClock.elapsedRealtime())){handler.removeCallbacks(reconnect);handler.postDelayed(reconnect,1500);}
        }
        @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] devices){
            if(destroyed)return;
            for(AudioDeviceInfo device:devices)if(isBluetoothMedia(device)&&deviceKey(device).equals(lastBluetooth)){
                bluetoothRemovedAt=SystemClock.elapsedRealtime();
                if(player.getPlayWhenReady()&&connectedBluetooth()==null){
                    armBluetoothResume();routePausing=true;player.pause();routePausing=false;
                    report("Bluetooth हट गया; दोबारा जुड़ने की प्रतीक्षा है",true);
                }
            }
        }
    };
    private MediaLibrarySession session;
    private SharedPreferences prefs;
    private ConnectivityManager connectivity;
    private boolean networkRegistered, destroyed, sleepStopping, retrying;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final RecoveryBudget budget=new RecoveryBudget();
    private final BufferWatchdog bufferWatchdog=new BufferWatchdog();
    private final NetworkHandoverPolicy networkHandover=new NetworkHandoverPolicy();
    private Runnable retryTask;
    private final QueueFailurePolicy queueFailures=new QueueFailurePolicy();
    private long transportGeneration;
    private final RadioFallbackPolicy radioFailures=new RadioFallbackPolicy();
    private long radioBufferAt,usageAt;private MediaItem usageItem;private boolean usagePlaying, fallbackPending;
    private final Runnable usageTick=new Runnable(){public void run(){updateUsage();if(!destroyed)handler.postDelayed(this,15000);}};
    private void updateUsage(){long now=SystemClock.elapsedRealtime();if(prefs!=null&&usagePlaying&&usageItem!=null&&usageAt>0)UsageStore.add(prefs,System.currentTimeMillis(),now-usageAt,usageItem.mediaId,String.valueOf(usageItem.mediaMetadata.title),String.valueOf(usageItem.mediaMetadata.genre),false);usageAt=now;usagePlaying=player!=null&&player.isPlaying();usageItem=player==null?null:player.getCurrentMediaItem();}
    private boolean isRadio(MediaItem item){if(item==null||item.localConfiguration==null||!"https".equals(item.localConfiguration.uri.getScheme()))return false;String kind=item.mediaMetadata.extras==null?"":item.mediaMetadata.extras.getString("kind","");return kind.isEmpty()||"radio".equals(kind)||"artistRadio".equals(kind);}
    private boolean online(){if(connectivity==null)return false;android.net.NetworkCapabilities caps=connectivity.getNetworkCapabilities(connectivity.getActiveNetwork());return caps!=null&&caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED);}
    private String meta(MediaItem item,String key){return item.mediaMetadata.extras==null?"":item.mediaMetadata.extras.getString(key,"");}
    private String description(MediaItem item){return String.valueOf(item.mediaMetadata.title)+" "+String.valueOf(item.mediaMetadata.genre)+" "+meta(item,"tags");}
    private boolean switchRadio(){
        MediaItem expected=player.getCurrentMediaItem();
        if(!isRadio(expected)||!prefs.getBoolean("autoFallback",true)||!canRecover()||!online())return false;
        if(fallbackPending)return true;
        radioQueueHistory.visit(expected.localConfiguration.uri.toString());
        java.util.List<String> urls=new java.util.ArrayList<>();java.util.List<Integer> scores=new java.util.ArrayList<>();
        for(int i=0;i<player.getMediaItemCount();i++){MediaItem other=player.getMediaItemAt(i);urls.add(other.localConfiguration==null?"":other.localConfiguration.uri.toString());scores.add(isRadio(other)&&!radioQueueHistory.contains(other.localConfiguration.uri.toString())?RadioMatch.similarity(description(expected),meta(expected,"language"),description(other),meta(other,"language")):0);}
        int next=radioFailures.next(expected.localConfiguration.uri.toString(),urls,scores,true,SystemClock.elapsedRealtime());
        cancelRecovery();
        if(next<0){player.pause();prefs.edit().putString("fallbackMessage","कोई और उपलब्ध समान स्टेशन नहीं मिला। दूसरा स्टेशन चुनें।").putString("fallbackMessageEn","No more similar stations are available. Choose another station.").putLong("fallbackAt",System.currentTimeMillis()).apply();report("समान स्टेशन नहीं मिला; प्लेबैक रोक दिया",true);return true;}
        long generation=transportGeneration;fallbackPending=true;
        handler.post(()->{fallbackPending=false;if(destroyed||generation!=transportGeneration||!canRecover()||!online()||!prefs.getBoolean("autoFallback",true)||!expected.equals(player.getCurrentMediaItem()))return;
            player.seekToDefaultPosition(next);player.prepare();
            prefs.edit().putString("fallbackMessage","स्टेशन नहीं खुला; मिलता-जुलता स्टेशन चला रहे हैं।").putString("fallbackMessageEn","Station unavailable; switching to a similar station.").putLong("fallbackAt",System.currentTimeMillis()).apply();report("समान स्टेशन पर स्विच किया",true);
        });return true;
    }
    private final Runnable stalled=new Runnable(){@Override public void run(){
        if(!canRecover()||player.getPlaybackState()!=Player.STATE_BUFFERING||retryTask!=null){bufferWatchdog.reset();radioBufferAt=0;return;}
        long now=SystemClock.elapsedRealtime();
        if(!online()){scheduleRecovery("इंटरनेट वापस आने की प्रतीक्षा है");return;}
        boolean radio=isRadio(player.getCurrentMediaItem());
        if(radio&&networkHandover.reconnect(now,player.getTotalBufferedDuration())){scheduleRecovery("नेटवर्क बदला; इसी स्टेशन से फिर जुड़ रहे हैं");return;}
        if(bufferWatchdog.stalled(now,player.getTotalBufferedDuration(),radio?12_000:BufferWatchdog.NO_PROGRESS_MS,radio?60_000:BufferWatchdog.MAX_WAIT_MS)){
            if(radio&&budget.attempts()>=2&&switchRadio())return;
            scheduleRecovery("स्ट्रीम का बफ़र अटक गया");
        }
        else handler.postDelayed(this,2000);
    }};
    private final Runnable expire=()->{
        if(player==null)return;
        sleepStopping=true;cancelBluetoothResume();transportGeneration++;if(assistantLibrary!=null)assistantLibrary.cancelSearch();
        cancelRecovery();
        player.pause();player.clearMediaItems();
        prefs.edit().putLong("sleepEnds",0).apply();
        report("स्लीप टाइमर पूरा हुआ",true);
        sleepStopping=false;
    };
    private void networkReady(Network network){
        if(destroyed||connectivity==null||!network.equals(connectivity.getActiveNetwork())||!online())return;
        networkHandover.validated(network.toString(),SystemClock.elapsedRealtime());
        if(!canRecover())return;
        if(waitingForNetwork&&retryTask!=null){Runnable pending=retryTask;handler.removeCallbacks(pending);pending.run();}
        else watchBuffer();
    }
    private final ConnectivityManager.NetworkCallback networkCallback=new ConnectivityManager.NetworkCallback(){
        @Override public void onAvailable(Network network){handler.post(()->networkReady(network));}
        @Override public void onCapabilitiesChanged(Network network,android.net.NetworkCapabilities caps){
            if(caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED))handler.post(()->networkReady(network));
            else handler.post(()->networkHandover.lost(network.toString()));
        }
        @Override public void onLost(Network network){handler.post(()->networkHandover.lost(network.toString()));}
    };
    private final SharedPreferences.OnSharedPreferenceChangeListener changes=(p,key)->{
        if(key==null){usageAt=SystemClock.elapsedRealtime();usagePlaying=false;radioFailures.reset();cancelBluetoothResume();cancelRecovery();applyAudioSettings();scheduleSleep();return;}
        if("bitrate".equals(key)||"repeat".equals(key)||"shuffle".equals(key)||"radioShuffle".equals(key)||"volume".equals(key)||"smartSound".equals(key))applyAudioSettings();
        else if("transportEpoch".equals(key)||"bluetoothResume".equals(key)){cancelBluetoothResume();if("transportEpoch".equals(key)){transportGeneration++;radioFailures.reset();if(assistantLibrary!=null)assistantLibrary.cancelSearch();}}
        else if("usageEnabled".equals(key)||"usageReset".equals(key)){usageAt=SystemClock.elapsedRealtime();usagePlaying=player!=null&&player.isPlaying();usageItem=player==null?null:player.getCurrentMediaItem();}
        else if("sleepEnds".equals(key))scheduleSleep();
        else if("uiLanguage".equals(key))AppLanguage.apply(this);
    };
    @Override public void onCreate(){
        super.onCreate();radioQueueHistory.reset();
        radioNowPlaying.reset("","","");
        prefs=getSharedPreferences("player",MODE_PRIVATE);
        prefs.edit().putString("soundProfile",prefs.getBoolean("smartSound",true)?"waiting":"off").apply();
        smartSound=new SmartSound(value->prefs.edit().putString("soundProfile",value).apply());
        AppLanguage.apply(this);
        // A deadline from a terminated earlier session must not pause a newly started song.
        long saved=prefs.getLong("sleepEnds",0);
        long restored=RecoveryBudget.restoredSleepDeadline(saved,System.currentTimeMillis());
        prefs.edit().putLong("sleepEnds",restored).putLong("fallbackAt",0).putBoolean("waitingForNetwork",false).putBoolean("recovering",false).putInt("recoveryAttempt",0).apply();
        androidx.media3.datasource.DefaultHttpDataSource.Factory http=new androidx.media3.datasource.DefaultHttpDataSource.Factory().setUserAgent("ZameerRadio/4.3 (Android music player; com.zameer.radio)").setConnectTimeoutMs(8_000).setReadTimeoutMs(12_000).setAllowCrossProtocolRedirects(false);
        androidx.media3.datasource.DefaultDataSource.Factory data=new androidx.media3.datasource.DefaultDataSource.Factory(this,http);
        // Keep more audio ahead; after a stall, refill enough to avoid rapid stop/start.
        smartLoadControl=new SmartRadioLoadControl();
        player=new ExoPlayer.Builder(this).setLoadControl(smartLoadControl).setMediaSourceFactory(new androidx.media3.exoplayer.source.DefaultMediaSourceFactory(this).setDataSourceFactory(data)).build();
        player.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),true);
        player.setHandleAudioBecomingNoisy(true);
        player.setWakeMode(C.WAKE_MODE_NETWORK);
        player.addListener(new Player.Listener(){
            @Override public void onAudioSessionIdChanged(int audioSessionId){applySmartSound();}
            @Override public void onPlayWhenReadyChanged(boolean ready,int reason){
                if(!ready){
                    if(reason==Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_BECOMING_NOISY){
                        if(connectedBluetooth()!=null||SystemClock.elapsedRealtime()-bluetoothRemovedAt<3000)armBluetoothResume();
                        // The noisy broadcast can precede the device-removal callback.
                        else if(!lastBluetooth.isEmpty())armBluetoothResume();
                    }else if(!routePausing)cancelBluetoothResume();
                    cancelRecovery();
                    if(!sleepStopping)report(reason==Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_BECOMING_NOISY?"हेडफोन / ऑडियो डिवाइस हट गया":reason==Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_FOCUS_LOSS?"कॉल या दूसरे ऐप ने ऑडियो लिया":"प्लेबैक रोका गया",true);
                }else{
                    cancelBluetoothResume();rememberBluetooth();
                    cancelRecovery();
                    report("प्ले शुरू किया",false);
                    watchBuffer();
                }
            }
            @Override public void onMediaItemTransition(MediaItem item,int reason){
                smartLoadControl.station(isRadio(item));
                if(isRadio(item))radioQueueHistory.visit(item.localConfiguration.uri.toString());
                updateUsage();applyAudioSettings();
                String kind=item==null||item.mediaMetadata.extras==null?"":item.mediaMetadata.extras.getString("kind","");
                radioNowPlaying.reset(item==null?"":item.mediaId,kind,item==null||item.mediaMetadata.title==null?"":item.mediaMetadata.title.toString());
                cancelBluetoothResume();cancelRecovery();watchBuffer();
            }
            @Override public void onMetadata(androidx.media3.common.Metadata metadata){
                MediaItem item=player.getCurrentMediaItem();
                if(item!=null&&!destroyed&&!prefs.getBoolean("wipeWebData",false))RadioMetadataReader.accept(radioNowPlaying,item.mediaId,metadata,System.currentTimeMillis());
            }
            @Override public void onPlayerError(PlaybackException error){
                MediaItem item=player.getCurrentMediaItem();if(item!=null)radioNowPlaying.icy(item.mediaId,"",0);
                if(bluetoothResume.pending(SystemClock.elapsedRealtime())&&retryable(error)){cancelRecovery();report("Bluetooth हट गया; दोबारा जुड़ने की प्रतीक्षा है",true);return;}
                cancelBluetoothResume();
                if(isRadio(item)&&retryable(error)&&canRecover()&&(!online()||budget.attempts()<2)){scheduleRecovery("नेटवर्क या स्ट्रीम की अस्थायी समस्या");return;}
                if(switchRadio())return;
                if(retryable(error)&&canRecover())scheduleRecovery("नेटवर्क या स्ट्रीम की अस्थायी समस्या");
                else{cancelRecovery();if(!skipFailedSong(permanentError(error))){player.pause();report(permanentError(error),true);}}
            }
            @Override public void onPlaybackStateChanged(int state){
                if(state==Player.STATE_IDLE||state==Player.STATE_ENDED){if(assistantLibrary!=null)assistantLibrary.clearArtistContext();MediaItem item=player.getCurrentMediaItem();if(item!=null)radioNowPlaying.icy(item.mediaId,"",0);}
                if(state==Player.STATE_READY){
                    waitingForNetwork=false;prefs.edit().putBoolean("waitingForNetwork",false).apply();
                    handler.removeCallbacks(stalled);
                    removeRetry();retrying=false;
                    report(player.isPlaying()?"प्लेबैक चल रहा है":"प्लेयर तैयार है",false);
                }else if(state==Player.STATE_ENDED){if(switchRadio())return;cancelRecovery();report("कतार पूरी हुई",true);}
                else if(state==Player.STATE_BUFFERING&&!retrying)report("स्ट्रीम का बफ़र भर रहा है",false);
                watchBuffer();
            }
            @Override public void onIsPlayingChanged(boolean playing){
                updateUsage();radioFailures.playing(playing,SystemClock.elapsedRealtime());
                budget.playing(playing,SystemClock.elapsedRealtime());
                if(playing){MediaItem active=player.getCurrentMediaItem();if(isRadio(active))radioQueueHistory.visit(active.localConfiguration.uri.toString());rememberBluetooth();retrying=false;report("प्लेबैक चल रहा है",false);}
            }
            @Override public void onPlaybackSuppressionReasonChanged(int reason){
                // Media3 owns transient audio-focus resumption. Recovery never overrides it.
                handler.removeCallbacks(stalled);
                if(reason!=Player.PLAYBACK_SUPPRESSION_REASON_NONE){
                    bufferWatchdog.reset();
                    removeRetry();retrying=false;
                    report("कॉल या दूसरे ऑडियो के कारण अस्थायी विराम",true);
                }else if(player.getPlayerError()!=null&&retryable(player.getPlayerError())&&canRecover())scheduleRecovery("ऑडियो फ़ोकस वापस मिला");
                else watchBuffer();
            }
        });
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        assistantLibrary=new AssistantLibrary(prefs,player,()->transportGeneration,value->{prefs.edit().putString("assistantStatus",value).apply();}){
            @Override public MediaSession.ConnectionResult onConnect(MediaSession session,MediaSession.ControllerInfo controller){
                if(!ControllerAccessPolicy.allowed(android.os.Process.myUid(),controller.getUid(),controller.isTrusted()))return MediaSession.ConnectionResult.reject();
                return super.onConnect(session,controller);
            }
            @Override public int onPlayerCommandRequest(MediaSession session,MediaSession.ControllerInfo controller,int command){
                if(command==Player.COMMAND_PLAY_PAUSE||command==Player.COMMAND_STOP||command==Player.COMMAND_CHANGE_MEDIA_ITEMS||command==Player.COMMAND_SET_MEDIA_ITEM||command==Player.COMMAND_SEEK_TO_NEXT||command==Player.COMMAND_SEEK_TO_PREVIOUS||command==Player.COMMAND_SEEK_FORWARD||command==Player.COMMAND_SEEK_BACK||command==Player.COMMAND_SEEK_TO_DEFAULT_POSITION||command==Player.COMMAND_SEEK_TO_MEDIA_ITEM||command==Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM||command==Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM||command==Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM){
                    transportGeneration++;radioFailures.reset();cancelBluetoothResume();if(assistantLibrary!=null)assistantLibrary.cancelSearch();
                    if(controller.getUid()!=android.os.Process.myUid())prefs.edit().putLong("externalTransportEpoch",prefs.getLong("externalTransportEpoch",0)+1).apply();
                }
                if(command==Player.COMMAND_CHANGE_MEDIA_ITEMS){queueFailures.reset();radioQueueHistory.reset();}
                return androidx.media3.session.SessionResult.RESULT_SUCCESS;
            }
        };
        session=new MediaLibrarySession.Builder(this,player,assistantLibrary).setSessionActivity(open).build();
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        if(audioManager!=null){audioManager.registerAudioDeviceCallback(audioDevices,handler);audioRegistered=true;}
        connectivity=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        if(connectivity!=null)try{connectivity.registerDefaultNetworkCallback(networkCallback);networkRegistered=true;}catch(SecurityException ignored){}
        prefs.registerOnSharedPreferenceChangeListener(changes);
        applyAudioSettings();scheduleSleep();handler.post(usageTick);
    }
    private static boolean isBluetoothMedia(AudioDeviceInfo d){
        int t=d.getType();return d.isSink()&&(t==AudioDeviceInfo.TYPE_BLUETOOTH_A2DP||(Build.VERSION.SDK_INT>=28&&t==AudioDeviceInfo.TYPE_HEARING_AID)||(Build.VERSION.SDK_INT>=31&&(t==AudioDeviceInfo.TYPE_BLE_HEADSET||t==AudioDeviceInfo.TYPE_BLE_SPEAKER)));
    }
    private static String deviceKey(AudioDeviceInfo d){
        String address=Build.VERSION.SDK_INT>=28?d.getAddress():"";
        return d.getType()+":"+(address==null||address.isEmpty()?String.valueOf(d.getProductName()):address);
    }
    private AudioDeviceInfo connectedBluetooth(){
        if(audioManager==null)return null;AudioDeviceInfo selected=null;
        for(AudioDeviceInfo d:audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)){
            if(d.isSink()&&(d.getType()==AudioDeviceInfo.TYPE_WIRED_HEADPHONES||d.getType()==AudioDeviceInfo.TYPE_WIRED_HEADSET||d.getType()==AudioDeviceInfo.TYPE_USB_DEVICE||d.getType()==AudioDeviceInfo.TYPE_USB_HEADSET))return null;
            if(isBluetoothMedia(d)){
            if(selected!=null)return null; // Ambiguous multi-device output: require an explicit Play.
            selected=d;
            }
        }
        return selected;
    }
    private void rememberBluetooth(){AudioDeviceInfo d=connectedBluetooth();lastBluetooth=d==null?"":deviceKey(d);}
    private void armBluetoothResume(){
        MediaItem item=player.getCurrentMediaItem();
        bluetoothResume.arm(prefs.getBoolean("bluetoothResume",true),true,item==null?"":item.mediaId,lastBluetooth,SystemClock.elapsedRealtime());
        if(bluetoothResume.pending(SystemClock.elapsedRealtime()))report("Bluetooth हट गया; दोबारा जुड़ने की प्रतीक्षा है",true);
    }
    private void cancelBluetoothResume(){bluetoothResume.cancel();handler.removeCallbacks(reconnect);}
    private void tryBluetoothResume(){
        if(destroyed||player==null||!prefs.getBoolean("bluetoothResume",true))return;
        AudioDeviceInfo device=connectedBluetooth();MediaItem item=player.getCurrentMediaItem();
        if(device==null||item==null||!bluetoothResume.matches(item.mediaId,deviceKey(device),SystemClock.elapsedRealtime()))return;
        long ends=prefs.getLong("sleepEnds",0);
        if(player.getPlayWhenReady()||player.getPlaybackState()==Player.STATE_ENDED||(ends>0&&ends<=System.currentTimeMillis())||audioManager.getMode()!=AudioManager.MODE_NORMAL||audioManager.isMusicActive()||player.getPlaybackSuppressionReason()!=Player.PLAYBACK_SUPPRESSION_REASON_NONE){cancelBluetoothResume();return;}
        if(player.getPlayerError()!=null&&!retryable(player.getPlayerError())){cancelBluetoothResume();return;}
        cancelBluetoothResume();
        // Prefer the reconnected media output; the noisy handler still pauses on subsequent loss.
        player.setPreferredAudioDevice(device);
        String kind=item.mediaMetadata.extras==null?"":item.mediaMetadata.extras.getString("kind","");
        if(kind.isEmpty()||"artistRadio".equals(kind))player.seekToDefaultPosition();
        if(player.getPlaybackState()==Player.STATE_IDLE)player.prepare();
        player.play(); // Media3 requests focus; never bypass audio focus or a phone call.
        report("Bluetooth जुड़ गया; प्लेबैक फिर शुरू हुआ",false);
    }
    private boolean skipFailedSong(String reason){
        MediaItem expected=player.getCurrentMediaItem();
        if(expected==null||destroyed)return false;
        String kind=expected.mediaMetadata.extras==null?"":expected.mediaMetadata.extras.getString("kind","");
        int index=player.getCurrentMediaItemIndex();
        int next=queueFailures.nextIndex(index,player.getMediaItemCount(),player.getRepeatMode()==Player.REPEAT_MODE_ALL,player.getPlayWhenReady(),player.getPlaybackSuppressionReason()!=Player.PLAYBACK_SUPPRESSION_REASON_NONE,"audius".equals(kind)||"archive".equals(kind)||"ccmixter".equals(kind)||"commons".equals(kind));
        if(next<0)return false;
        long generation=transportGeneration;
        report(reason,true);
        // Leave the error callback before touching the playlist. Recheck user intent.
        handler.post(()->{
            if(destroyed||generation!=transportGeneration||!canRecover()||!expected.equals(player.getCurrentMediaItem()))return;
            player.removeMediaItem(index); // Broken entries cannot loop with Repeat All.
            player.seekToDefaultPosition(next>index?next-1:next);
            player.prepare(); // Never override pause, focus, Bluetooth loss or a timer.
            report("यह गाना नहीं खुला; कतार का अगला गाना चला रहे हैं।",false);
        });
        return true;
    }
    private boolean canRecover(){
        if(destroyed||player==null||!player.getPlayWhenReady()||player.getPlaybackSuppressionReason()!=Player.PLAYBACK_SUPPRESSION_REASON_NONE)return false;
        MediaItem item=player.getCurrentMediaItem();
        return item!=null&&item.localConfiguration!=null&&"https".equals(item.localConfiguration.uri.getScheme());
    }
    private static boolean retryable(PlaybackException error){
        if(error.errorCode==PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS){
            for(Throwable cause=error.getCause();cause!=null;cause=cause.getCause())if(cause instanceof HttpDataSource.InvalidResponseCodeException){
                int code=((HttpDataSource.InvalidResponseCodeException)cause).responseCode;
                return code==408||code==429||code>=500&&code<=599;
            }
            return false;
        }
        return error.errorCode==PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED||error.errorCode==PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT||error.errorCode==PlaybackException.ERROR_CODE_TIMEOUT||error.errorCode==PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW;
    }
    private void watchBuffer(){
        handler.removeCallbacks(stalled);
        if(canRecover()&&retryTask==null&&player.getPlaybackState()==Player.STATE_BUFFERING){if(radioBufferAt==0)radioBufferAt=SystemClock.elapsedRealtime();bufferWatchdog.begin(SystemClock.elapsedRealtime(),player.getTotalBufferedDuration());handler.postDelayed(stalled,2000);}
        else {bufferWatchdog.reset();radioBufferAt=0;}
    }
    private static String permanentError(PlaybackException error){
        for(Throwable cause=error.getCause();cause!=null;cause=cause.getCause())if(cause instanceof HttpDataSource.InvalidResponseCodeException){
            int code=((HttpDataSource.InvalidResponseCodeException)cause).responseCode;
            if(code==401||code==403)return "सर्वर ने ऑडियो की अनुमति नहीं दी (HTTP "+code+")। दूसरा गाना या संगीत सेवा चुनें।";
            if(code==404||code==410)return "यह ऑडियो अब उपलब्ध नहीं है (HTTP "+code+")। दूसरा गाना चुनें।";
        }
        return "ऑडियो नहीं खुला ("+error.getErrorCodeName()+")";
    }
    private void scheduleRecovery(String reason){
        if(retryTask!=null||!canRecover())return;
        handler.removeCallbacks(stalled);
        bufferWatchdog.reset();
        long delay=budget.nextDelay(SystemClock.elapsedRealtime());
        if(delay<0){finishRecovery();return;}
        MediaItem expected=player.getCurrentMediaItem();
        retrying=true;report(reason+" — फिर जुड़ रहे हैं ("+budget.attempts()+"/6)",true);
        retryTask=()->{
            if(!canRecover()||!expected.equals(player.getCurrentMediaItem())){cancelRecovery();return;}
            if(budget.expired(SystemClock.elapsedRealtime())){finishRecovery();return;}
            if(!online()){
                waitingForNetwork=true;prefs.edit().putBoolean("waitingForNetwork",true).apply();
                report("इंटरनेट वापस आने पर इसी स्टेशन से फिर जुड़ेंगे।",false);return;
            }
            retryTask=null;waitingForNetwork=false;prefs.edit().putBoolean("waitingForNetwork",false).apply();
            if(player.getPlaybackState()==Player.STATE_BUFFERING)player.stop();
            // Refresh live radio at its live edge; on-demand songs retain their position.
            String kind=expected.mediaMetadata.extras==null?"":expected.mediaMetadata.extras.getString("kind","");
            if(kind.isEmpty()||"artistRadio".equals(kind)||player.getPlayerError()!=null&&player.getPlayerError().errorCode==PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW)player.seekToDefaultPosition();
            player.prepare(); // Do not call play(): manual pause and audio focus remain authoritative.
            watchBuffer();
        };
        if(online())handler.postDelayed(retryTask,delay);else retryTask.run();
    }
    private void finishRecovery(){
        cancelRecovery();player.pause();
        report("कनेक्शन वापस नहीं मिला। इंटरनेट जाँचकर प्ले दबाएँ या दूसरा स्टेशन चुनें।",true);
    }
    private void removeRetry(){if(retryTask!=null){handler.removeCallbacks(retryTask);retryTask=null;}}
    private void cancelRecovery(){networkHandover.cancel();waitingForNetwork=false;if(prefs!=null)prefs.edit().putBoolean("waitingForNetwork",false).apply();radioBufferAt=0;removeRetry();handler.removeCallbacks(stalled);bufferWatchdog.reset();retrying=false;budget.reset();if(prefs!=null)prefs.edit().putBoolean("recovering",false).putInt("recoveryAttempt",0).apply();}
    private void report(String reason,boolean interruption){
        SharedPreferences.Editor edit=prefs.edit().putString("playbackStatus",reason).putBoolean("recovering",retrying).putInt("recoveryAttempt",budget.attempts());
        if(interruption)edit.putString("lastInterruption",reason).putLong("lastInterruptionAt",System.currentTimeMillis());
        edit.apply();
    }
    private void applySmartSound(){
        if(player==null||smartSound==null||destroyed)return;
        MediaItem item=player.getCurrentMediaItem();
        smartSound.apply(player.getAudioSessionId(),prefs.getBoolean("smartSound",true),item==null?"":String.valueOf(item.mediaMetadata.genre)+" "+meta(item,"tags"));
    }
    private void applyAudioSettings(){
        if(player==null)return;
        // Buffer recovery never lowers quality: only the listener sets this limit.
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setMaxAudioBitrate(prefs.getInt("bitrate",Integer.MAX_VALUE)).build());
        player.setRepeatMode(isRadio(player.getCurrentMediaItem())?Player.REPEAT_MODE_OFF:prefs.getInt("repeat",Player.REPEAT_MODE_ALL));
        player.setShuffleModeEnabled(prefs.getBoolean(isRadio(player.getCurrentMediaItem())?"radioShuffle":"shuffle",false));
        player.setVolume(prefs.getFloat("volume",1f));
        applySmartSound();
    }
    private void scheduleSleep(){
        handler.removeCallbacks(expire);
        long ends=prefs.getLong("sleepEnds",0);
        if(ends>0)handler.postDelayed(expire,Math.max(0,ends-System.currentTimeMillis()));
    }
    static final String ACTION_EXIT="com.zameer.radio.EXIT";
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&ACTION_EXIT.equals(intent.getAction())){
            prefs.edit().putLong("sleepEnds",0).putLong("transportEpoch",System.nanoTime()).putString("activePlaybackQueue","[]").apply();
            cancelRecovery();cancelBluetoothResume();handler.removeCallbacks(expire);
            if(player!=null){player.pause();player.stop();player.clearMediaItems();}
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY;
        }
        return super.onStartCommand(intent,flags,startId);
    }
    @Override public MediaLibrarySession onGetSession(MediaSession.ControllerInfo controller){return session;}
    @Override public void onDestroy(){
        updateUsage();destroyed=true;cancelBluetoothResume();
        radioNowPlaying.reset("","","");
        if(assistantLibrary!=null)assistantLibrary.close();
        if(audioRegistered)audioManager.unregisterAudioDeviceCallback(audioDevices);
        handler.removeCallbacksAndMessages(null);
        if(networkRegistered)try{connectivity.unregisterNetworkCallback(networkCallback);}catch(IllegalArgumentException ignored){}
        if(prefs!=null)prefs.unregisterOnSharedPreferenceChangeListener(changes);
        if(session!=null)session.release();
        if(smartSound!=null)smartSound.release();
        if(prefs!=null)prefs.edit().putString("soundProfile",prefs.getBoolean("smartSound",true)?"waiting":"off").apply();
        if(player!=null)player.release();
        super.onDestroy();
    }
}
