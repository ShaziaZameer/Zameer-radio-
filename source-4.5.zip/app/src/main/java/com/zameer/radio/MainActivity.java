package com.zameer.radio;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.*;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.webkit.WebViewAssetLoader;

/** Bundled, trusted UI only. Playback lives independently in PlaybackService. */
public class MainActivity extends ComponentActivity {
    private static final String HOME="https://appassets.androidplatform.net/assets/index.html";
    private WebView webView;
    private RadioCompanion companion;
    private ValueCallback<Uri[]> photoCallback;
    private final Handler timerHandler=new Handler(Looper.getMainLooper());
    private boolean destroyed;
    private volatile boolean erasingPrivateData;
    private volatile int importEpoch, activeImportEpoch;
    private String voiceResult="";
    private VoiceInput voiceInput;
    private volatile boolean pageReady;
    private String pendingLaunch="{}";
    private long lastTransportRequest;
    private final PendingPlayerAction pendingPlayerAction=new PendingPlayerAction();
    private final Runnable playerReadyTimeout=()->{if(pendingPlayerAction.clear())message("प्लेयर तैयार नहीं हुआ। फिर प्ले दबाएँ।");};
    private final java.util.concurrent.ExecutorService radioWorker=java.util.concurrent.Executors.newFixedThreadPool(4);
    private final java.util.concurrent.atomic.AtomicInteger radioPending=new java.util.concurrent.atomic.AtomicInteger();
    private long foregroundAt;private boolean foreground;
    private androidx.core.os.CancellationSignal locationCancel;
    private int locationEpoch;
    private final Runnable foregroundTick=new Runnable(){public void run(){flushForeground();if(foreground)timerHandler.postDelayed(this,15000);}};
    private void flushForeground(){long now=android.os.SystemClock.elapsedRealtime();if(foreground&&foregroundAt>0)UsageStore.add(prefs,System.currentTimeMillis(),now-foregroundAt,"","","",true);foregroundAt=now;}
    private void locationReply(android.location.Location value,int epoch){if(epoch!=locationEpoch||destroyed)return;locationEpoch++;if(locationCancel!=null){locationCancel.cancel();locationCancel=null;}try{org.json.JSONObject o=new org.json.JSONObject();if(value==null)o.put("error",true);else o.put("lat",value.getLatitude()).put("lon",value.getLongitude());js("window.onNearLocation && window.onNearLocation("+o+")");}catch(Exception ignored){}}
    private void locate(){
        if(destroyed||exiting||erasingPrivateData)return;
        if(androidx.core.content.ContextCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_COARSE_LOCATION)!=android.content.pm.PackageManager.PERMISSION_GRANTED){androidx.core.app.ActivityCompat.requestPermissions(this,new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION},327);return;}
        if(locationCancel!=null)locationCancel.cancel();final int epoch=++locationEpoch;
        android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
        try{if(lm==null||!lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER)){locationReply(null,epoch);return;}
            android.location.Location cached=lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER);
            if(cached!=null&&android.os.SystemClock.elapsedRealtimeNanos()-cached.getElapsedRealtimeNanos()<300_000_000_000L){locationReply(cached,epoch);return;}
            locationCancel=new androidx.core.os.CancellationSignal();
            androidx.core.location.LocationManagerCompat.getCurrentLocation(lm,android.location.LocationManager.NETWORK_PROVIDER,locationCancel,androidx.core.content.ContextCompat.getMainExecutor(this),value->locationReply(value,epoch));
            timerHandler.postDelayed(()->locationReply(null,epoch),15000);
        }catch(SecurityException|IllegalArgumentException e){locationReply(null,epoch);}
    }
    private volatile androidx.media3.session.MediaController controller;
    private com.google.common.util.concurrent.ListenableFuture<androidx.media3.session.MediaController> controllerFuture;
    private android.content.SharedPreferences prefs;
    private boolean welcomePending, exiting;
    private final java.util.concurrent.ExecutorService importer=java.util.concurrent.Executors.newSingleThreadExecutor();
    private final Runnable pulse=new Runnable(){public void run(){sendState();if(!destroyed)timerHandler.postDelayed(this,800);}};
    private void js(String code){if(!destroyed&&webView!=null)webView.evaluateJavascript(code,null);}
    private void message(String message){js("window.nativeMessage && window.nativeMessage("+org.json.JSONObject.quote(message)+")");}
    private void sendState(){
        if(controller==null||destroyed)return;
        try{
            org.json.JSONObject s=new org.json.JSONObject();
            androidx.media3.common.MediaItem m=controller.getCurrentMediaItem();
            s.put("url",m!=null&&m.mediaMetadata.extras!=null?m.mediaMetadata.extras.getString("url",""):"");s.put("kind",m!=null&&m.mediaMetadata.extras!=null?m.mediaMetadata.extras.getString("kind",""):"");
            s.put("id",m==null?"":m.mediaId);s.put("name",m==null?"":String.valueOf(m.mediaMetadata.title));
            s.put("artist",m==null||m.mediaMetadata.artist==null?"":m.mediaMetadata.artist.toString());
            RadioNowPlaying.Info info=PlaybackService.radioInfo(m==null?"":m.mediaId);
            org.json.JSONObject radio=new org.json.JSONObject();
            radio.put("id",info.id).put("raw",info.raw).put("title",info.title).put("artist",info.artist).put("album",info.album).put("source",info.source).put("updatedAt",info.updatedAt);
            s.put("radioInfo",radio);
            for(String key:new String[]{"tags","language","state","country"})s.put(key,m!=null&&m.mediaMetadata.extras!=null?m.mediaMetadata.extras.getString(key,""):"");
            s.put("transportRequest",lastTransportRequest);s.put("externalTransportEpoch",prefs.getLong("externalTransportEpoch",0));
            s.put("wants",controller.getPlayWhenReady());s.put("playing",controller.isPlaying());
            s.put("state",controller.getPlaybackState());s.put("error",controller.getPlayerError()!=null);
            s.put("position",controller.getCurrentPosition());s.put("duration",Math.max(0,controller.getDuration()));
            s.put("bufferedMs",Math.max(0,controller.getTotalBufferedDuration()));
            s.put("index",controller.getCurrentMediaItemIndex());s.put("count",controller.getMediaItemCount());
            s.put("soundProfile",prefs.getString("soundProfile",prefs.getBoolean("smartSound",true)?"waiting":"off"));
            s.put("sleepEnds",prefs.getLong("sleepEnds",0));
            s.put("assistantStatus",prefs.getString("assistantStatus",""));
            s.put("fallbackAt",prefs.getLong("fallbackAt",0));s.put("fallbackMessage",prefs.getString("fallbackMessage",""));s.put("fallbackMessageEn",prefs.getString("fallbackMessageEn",""));
            s.put("assistantLanguageAt",prefs.getLong("assistantLanguageAt",0));
            s.put("musicLanguage",prefs.getString("musicLanguage","hi"));
            s.put("waitingForNetwork",prefs.getBoolean("waitingForNetwork",false));
            s.put("recovering",prefs.getBoolean("recovering",false));
            s.put("playbackStatus",prefs.getString("playbackStatus",""));
            s.put("lastInterruption",prefs.getString("lastInterruption",""));
            s.put("lastInterruptionAt",prefs.getLong("lastInterruptionAt",0));
            js("window.onNativeState && window.onNativeState("+s+")");
        }catch(org.json.JSONException ignored){}
    }
    private void applyScreenPrivacy(){
        if(prefs.getBoolean("secureScreen",false))getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
    }
    private WebResourceResponse blockedResource(){return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));}
    public final class PlayerBridge {
        @JavascriptInterface public void exportPersonalBackup(String json){if(json==null||json.length()>2_000_000)return;runOnUiThread(()->{if(!destroyed&&!erasingPrivateData)companion.exportBackup(json);});}
        @JavascriptInterface public void importPersonalBackup(){runOnUiThread(()->{if(!destroyed&&!erasingPrivateData)companion.importBackup();});}
        @JavascriptInterface public void openProgrammeCalendar(String json){if(json==null||json.length()>16000)return;runOnUiThread(()->{if(!destroyed&&!erasingPrivateData)companion.calendar(json);});}
        @JavascriptInterface public void shareRadioText(String text){if(text==null||text.length()>5000)return;runOnUiThread(()->{if(!destroyed&&!erasingPrivateData)companion.share(text);});}
        @JavascriptInterface public void requestRadio(String id,String path,String json,String method){
            if(destroyed||erasingPrivateData||id==null||id.length()>80||json==null||json.length()>16000)return;
            if(radioPending.incrementAndGet()>20){radioPending.decrementAndGet();runOnUiThread(()->js("window.onRadioResponse && window.onRadioResponse("+org.json.JSONObject.quote(id)+",429,\"{}\")"));return;}
            final int epoch=importEpoch;
            radioWorker.execute(()->{String response="{}";int code=200;try{response=RadioApi.request(path,new org.json.JSONObject(json),method);}catch(Exception e){code=503;}finally{radioPending.decrementAndGet();}final String body=response;final int status=code;runOnUiThread(()->{if(!destroyed&&!erasingPrivateData&&epoch==importEpoch)js("window.onRadioResponse && window.onRadioResponse("+org.json.JSONObject.quote(id)+","+status+","+org.json.JSONObject.quote(body)+")");});});
        }
        @JavascriptInterface public void saveRadioDirectory(String json){if(destroyed||erasingPrivateData||json==null||json.length()>5_000_000)return;try{org.json.JSONArray input=new org.json.JSONArray(json),clean=new org.json.JSONArray();for(int i=0;i<Math.min(input.length(),5000);i++){org.json.JSONObject row=input.optJSONObject(i);if(row!=null&&RadioMatch.publicUrl(row.optString("url"))&&!row.optString("id").isEmpty())clean.put(row);}prefs.edit().putString("radioDirectory",clean.toString()).apply();}catch(Exception ignored){}}
        @JavascriptInterface public String playbackQueue(){return prefs.getString("activePlaybackQueue","[]");}
        @JavascriptInterface public String usageStats(){return UsageStore.read(prefs);}
        @JavascriptInterface public void clearUsage(){runOnUiThread(()->{foregroundAt=android.os.SystemClock.elapsedRealtime();UsageStore.clear(prefs);js("window.onUsageChanged && window.onUsageChanged()");});}
        @JavascriptInterface public void requestNearLocation(){runOnUiThread(()->locate());}
        @JavascriptInterface public void exitApp(){runOnUiThread(()->{
            if(destroyed||exiting)return;
            exiting=true;pendingPlayerAction.clear();timerHandler.removeCallbacks(playerReadyTimeout);
            if(voiceInput!=null)voiceInput.cancel();
            synchronized(MainActivity.this){pendingLaunch="{}";voiceResult="";welcomePending=false;}
            prefs.edit().putLong("sleepEnds",0).putLong("transportEpoch",System.nanoTime()).putString("activePlaybackQueue","[]").apply();
            if(controller!=null){controller.pause();controller.stop();controller.clearMediaItems();}
            startService(new Intent(MainActivity.this,PlaybackService.class).setAction(PlaybackService.ACTION_EXIT));
            finishAndRemoveTask();
        });}
        @JavascriptInterface public boolean consumeWelcome(){synchronized(MainActivity.this){boolean show=welcomePending;welcomePending=false;return show;}}
        @JavascriptInterface public String consumeLaunch(){synchronized(MainActivity.this){if(controller==null||!pageReady||erasingPrivateData)return "{}";String result=pendingLaunch;pendingLaunch="{}";return result;}}
        @JavascriptInterface public void openAssistantSettings(){runOnUiThread(()->{
            try{startActivity(new Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS));}
            catch(ActivityNotFoundException|SecurityException e){try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception ignored){message("फोन की असिस्टेंट सेटिंग नहीं खुली। सेटिंग ऐप से खोलें।");}}
        });}
        @JavascriptInterface public boolean pendingPrivateDataErase(){return prefs.getBoolean("wipeWebData",false);}
        @JavascriptInterface public void completePrivateDataErase(){prefs.edit().putBoolean("wipeWebData",false).apply();}
        @JavascriptInterface public String language(){return AppLanguage.code(MainActivity.this);}
        @JavascriptInterface public String musicSettings(){try{org.json.JSONObject o=new org.json.JSONObject();for(String key:new String[]{"musicLanguage","catalogProvider"})if(prefs.contains(key))o.put(key,prefs.getString(key,""));return o.toString();}catch(Exception ignored){return "{}";}}
        @JavascriptInterface public String privacySettings(){return "{\"secureScreen\":"+prefs.getBoolean("secureScreen",false)+",\"bluetoothResume\":"+prefs.getBoolean("bluetoothResume",true)+"}";}
        @JavascriptInterface public void erasePrivateData(){runOnUiThread(()->{
            companion.clear();
            if(erasingPrivateData||destroyed)return;
            erasingPrivateData=true;pendingPlayerAction.clear();timerHandler.removeCallbacks(playerReadyTimeout);if(voiceInput!=null)voiceInput.cancel();importEpoch++;synchronized(MainActivity.this){pendingLaunch="{}";}
            prefs.edit().putLong("sleepEnds",0).putBoolean("wipeWebData",true).apply();
            if(controller!=null){controller.pause();controller.clearMediaItems();}
            synchronized(MainActivity.this){voiceResult="";}
            final String language=AppLanguage.code(MainActivity.this);
            importer.execute(()->{
                for(android.content.UriPermission grant:getContentResolver().getPersistedUriPermissions())try{getContentResolver().releasePersistableUriPermission(grant.getUri(),Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}
                runOnUiThread(()->{
                    foregroundAt=android.os.SystemClock.elapsedRealtime();
                    prefs.edit().clear().putString("uiLanguage",language).putBoolean("wipeWebData",true).apply();
                    WebStorage.getInstance().deleteAllData();
                    if(webView!=null){webView.clearCache(true);webView.clearHistory();webView.clearFormData();}
                    CookieManager.getInstance().removeAllCookies(null);
                    erasingPrivateData=false;
                    js("window.onPrivateDataErased && window.onPrivateDataErased()");
                });
            });
        });}
        @JavascriptInterface public String consumeVoice(){synchronized(MainActivity.this){if(controller==null||!pageReady||erasingPrivateData)return "";String result=voiceResult;voiceResult="";return result;}}
        @JavascriptInterface public void startVoice(){runOnUiThread(()->{
            if(destroyed||exiting||erasingPrivateData)return;
            if(voiceInput==null)voiceInput=new VoiceInput(MainActivity.this,new VoiceInput.Host(){
                public void pausePlayback(){
                    prefs.edit().putLong("transportEpoch",System.nanoTime()).apply();
                    if(controller!=null)controller.pause();
                    sendState();
                }
                public void status(String value){js("window.onVoiceStatus && window.onVoiceStatus("+org.json.JSONObject.quote(value)+")");}
                public void result(String value){
                    if(destroyed||exiting||erasingPrivateData)return;
                    synchronized(MainActivity.this){voiceResult=value;}
                    dispatchVoice();
                }
                public void typeInstead(){
                    js("window.focusVoiceCommand && window.focusVoiceCommand()");
                    if(webView!=null)webView.postDelayed(()->{
                        if(!destroyed&&webView!=null)((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(webView,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
                    },150);
                }
            });
            voiceInput.start();
        });}
        @JavascriptInterface public String library(){return prefs.getString("library","[]");}
        @JavascriptInterface public void importSongs(){runOnUiThread(()->{
            if(erasingPrivateData)return;activeImportEpoch=importEpoch;
            Intent picker=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE);
            picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            try{startActivityForResult(picker,102);}catch(ActivityNotFoundException e){message("गाने चुनने वाला ऐप उपलब्ध नहीं है।");}
        });}
        @JavascriptInterface public void settings(String json){if(json==null||json.length()>4096)return;runOnUiThread(()->{
            if(erasingPrivateData)return;
            try{org.json.JSONObject o=new org.json.JSONObject(json);android.content.SharedPreferences.Editor e=prefs.edit();
                if(o.has("bitrate"))e.putInt("bitrate",Math.max(32000,o.getInt("bitrate")));
                if(o.has("repeat"))e.putInt("repeat",Math.max(0,Math.min(2,o.getInt("repeat"))));
                if(o.has("smartSound"))e.putBoolean("smartSound",o.getBoolean("smartSound"));
                if(o.has("autoFallback"))e.putBoolean("autoFallback",o.getBoolean("autoFallback"));
                if(o.has("usageEnabled")){flushForeground();e.putBoolean("usageEnabled",o.getBoolean("usageEnabled"));}
                if(o.has("bluetoothResume"))e.putBoolean("bluetoothResume",o.getBoolean("bluetoothResume"));
                if(o.has("shuffle"))e.putBoolean("shuffle",o.getBoolean("shuffle"));
                if(o.has("radioShuffle"))e.putBoolean("radioShuffle",o.getBoolean("radioShuffle"));
                if(o.has("volume"))e.putFloat("volume",(float)Math.max(0,Math.min(1,o.getDouble("volume"))));
                if(o.has("sleepEnds")){long t=o.getLong("sleepEnds");e.putLong("sleepEnds",t>System.currentTimeMillis()&&t<=System.currentTimeMillis()+480L*60000?t:0);}
                if(o.has("uiLanguage")&&("hi".equals(o.getString("uiLanguage"))||"en".equals(o.getString("uiLanguage"))))e.putString("uiLanguage",o.getString("uiLanguage"));
                if(o.has("secureScreen"))e.putBoolean("secureScreen",o.getBoolean("secureScreen"));
                if(o.has("remoteArtwork"))e.putBoolean("remoteArtwork",o.getBoolean("remoteArtwork"));
                if(o.has("musicLanguage"))e.putString("musicLanguage",MusicRequest.valid(o.getString("musicLanguage")));
                if(o.has("catalogProvider")&&java.util.Arrays.asList("all","both","audius","archive","ccmixter","commons","artistRadio").contains(o.getString("catalogProvider")))e.putString("catalogProvider",o.getString("catalogProvider"));
                e.apply();
                if(o.has("uiLanguage")){AppLanguage.apply(MainActivity.this);AppLanguage.apply(getApplicationContext());}
                if(o.has("secureScreen"))applyScreenPrivacy();
                if(o.has("remoteArtwork")&&!o.getBoolean("remoteArtwork")&&webView!=null)webView.clearCache(true);
            }catch(Exception ignored){message("सेटिंग सहेजी नहीं गई।");}
        });}
        @JavascriptInterface public void playQueue(String json,int index){playQueueWithId(json,index,0);}
        @JavascriptInterface public void playQueueWithId(String json,int index,long requestId){if(json==null||json.length()>2_000_000)return;runOnUiThread(()->withPlayer(requestId,()->{
            prefs.edit().putLong("transportEpoch",System.nanoTime()).apply();
            try{
                org.json.JSONArray rows=new org.json.JSONArray(json), library=new org.json.JSONArray(prefs.getString("library","[]"));
                java.util.HashSet<String> allowed=new java.util.HashSet<>();for(int i=0;i<library.length();i++)allowed.add(library.getJSONObject(i).getString("url"));
                java.util.ArrayList<androidx.media3.common.MediaItem> items=new java.util.ArrayList<>();
                for(int i=0;i<Math.min(rows.length(),500);i++){
                    org.json.JSONObject row=rows.getJSONObject(i);Uri uri=Uri.parse(row.getString("url"));
                    if(!((RadioMatch.publicUrl(uri.toString()))||("content".equals(uri.getScheme())&&allowed.contains(uri.toString()))))throw new IllegalArgumentException();
                    Bundle meta=new Bundle();meta.putString("url",uri.toString());meta.putString("kind",row.optString("kind",""));for(String key:new String[]{"tags","language","state","country"})meta.putString(key,row.optString(key,""));
                    items.add(new androidx.media3.common.MediaItem.Builder().setMediaId(row.getString("id")).setUri(uri).setMediaMetadata(new androidx.media3.common.MediaMetadata.Builder().setTitle(row.optString("name","Zameer Radio • AI")).setArtist(row.optString("artist","Zameer Radio • AI")).setGenre(row.optString("genre","")+" "+row.optString("tags","")+" "+row.optString("assignedMood","")).setExtras(meta).build()).build());
                }
                if(items.isEmpty())return;
                prefs.edit().putString("activePlaybackQueue",rows.toString()).apply();
                controller.setMediaItems(items,Math.max(0,Math.min(index,items.size()-1)),0);controller.prepare();controller.play();sendState();
            }catch(Exception e){message("गाना नहीं खुला। फ़ाइल दोबारा जोड़ें या दूसरा स्टेशन चुनें।");}
        }));}
        // Extend the current city queue without interrupting its stream or reviving an old Play.
        @JavascriptInterface public void appendRadioQueue(String json,String expectedUrl,long requestId){
            if(json==null||json.length()>2_000_000)return;
            runOnUiThread(()->{
                if(destroyed||exiting||erasingPrivateData||controller==null||requestId!=lastTransportRequest||!controller.getPlayWhenReady())return;
                androidx.media3.common.MediaItem now=controller.getCurrentMediaItem();
                if(now==null||now.mediaMetadata.extras==null||!expectedUrl.equals(now.mediaMetadata.extras.getString("url","")))return;
                try{
                    org.json.JSONArray rows=new org.json.JSONArray(json),saved=new org.json.JSONArray(prefs.getString("activePlaybackQueue","[]"));
                    java.util.HashSet<String> urls=new java.util.HashSet<>();
                    for(int i=0;i<controller.getMediaItemCount();i++){androidx.media3.common.MediaItem item=controller.getMediaItemAt(i);if(item.mediaMetadata.extras!=null)urls.add(item.mediaMetadata.extras.getString("url",""));}
                    java.util.ArrayList<androidx.media3.common.MediaItem> added=new java.util.ArrayList<>();
                    for(int i=0;i<rows.length()&&controller.getMediaItemCount()+added.size()<500;i++){
                        org.json.JSONObject row=rows.getJSONObject(i);String url=row.optString("url");
                        if(!RadioMatch.publicUrl(url)||!urls.add(url))continue;
                        Bundle meta=new Bundle();meta.putString("url",url);meta.putString("kind","");for(String key:new String[]{"tags","language","state","country"})meta.putString(key,row.optString(key));
                        added.add(new androidx.media3.common.MediaItem.Builder().setMediaId(row.optString("id",url)).setUri(url).setMediaMetadata(new androidx.media3.common.MediaMetadata.Builder().setTitle(row.optString("name","Radio")).setArtist("Live radio").setGenre(row.optString("tags")).setExtras(meta).build()).build());saved.put(row);
                    }
                    if(!added.isEmpty()){controller.addMediaItems(added);prefs.edit().putString("activePlaybackQueue",saved.toString()).apply();sendState();}
                }catch(Exception ignored){}
            });
        }
        @JavascriptInterface public void command(String action,long value){commandWithId(action,value,0);}
        @JavascriptInterface public void commandWithId(String action,long value,long requestId){runOnUiThread(()->withPlayer(requestId,()->{
            prefs.edit().putLong("transportEpoch",System.nanoTime()).apply();
            switch(action){
                case "clearQueue":controller.stop();controller.clearMediaItems();prefs.edit().putString("activePlaybackQueue","[]").apply();break;
                case "play":if(controller.getPlaybackState()==androidx.media3.common.Player.STATE_IDLE)controller.prepare();controller.play();break;
                case "pause":controller.pause();break;
                case "stop":controller.pause();controller.clearMediaItems();break;
                case "next":case "prev":{
                    androidx.media3.common.MediaItem now=controller.getCurrentMediaItem();boolean radio=now!=null&&now.mediaMetadata.extras!=null&&now.mediaMetadata.extras.getString("kind","").isEmpty();
                    if(radio){
                        java.util.List<String> urls=new java.util.ArrayList<>();for(int i=0;i<controller.getMediaItemCount();i++){androidx.media3.common.MediaItem item=controller.getMediaItemAt(i);urls.add(item.mediaMetadata.extras==null?"":item.mediaMetadata.extras.getString("url",""));}
                        int currentIndex=controller.getCurrentMediaItemIndex();PlaybackService.radioQueueHistory.visit(now.mediaMetadata.extras.getString("url",""));
                        int target=PlaybackService.radioQueueHistory.step(urls,currentIndex,"prev".equals(action)?-1:1,prefs.getBoolean("radioShuffle",false));
                        if(target>=0&&target!=currentIndex){PlaybackService.radioQueueHistory.visit(urls.get(target));controller.seekToDefaultPosition(target);}
                    }else if("prev".equals(action))controller.seekToPreviousMediaItem();else controller.seekToNextMediaItem();
                    if(controller.getPlaybackState()==androidx.media3.common.Player.STATE_IDLE)controller.prepare();break;}

                case "seek":if(controller.isCurrentMediaItemSeekable())controller.seekTo(Math.max(0,value));break;
            }sendState();
        }));}
        @JavascriptInterface public void checkLibrary(){checkAudioLibrary();}
        @JavascriptInterface public void clearLibrary(){runOnUiThread(()->{
            importEpoch++;pendingPlayerAction.clear();timerHandler.removeCallbacks(playerReadyTimeout);prefs.edit().putLong("transportEpoch",System.nanoTime()).apply();
            if(controller!=null){controller.pause();controller.clearMediaItems();}
            for(android.content.UriPermission grant:getContentResolver().getPersistedUriPermissions())try{getContentResolver().releasePersistableUriPermission(grant.getUri(),Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}
            prefs.edit().putString("library","[]").apply();js("window.onLibraryChanged && window.onLibraryChanged()");
        });}
    }
    private void importAudio(Intent data){
        java.util.ArrayList<Uri> selected=new java.util.ArrayList<>();
        if(data.getClipData()!=null){for(int i=0;i<Math.min(500,data.getClipData().getItemCount());i++)selected.add(data.getClipData().getItemAt(i).getUri());}else if(data.getData()!=null)selected.add(data.getData());
        final int epoch=activeImportEpoch;
        importer.execute(()->{
            try{
                org.json.JSONArray old=new org.json.JSONArray(prefs.getString("library","[]"));java.util.LinkedHashMap<String,org.json.JSONObject> songs=new java.util.LinkedHashMap<>();
                for(int i=0;i<old.length();i++)songs.put(old.getJSONObject(i).getString("url"),old.getJSONObject(i));
                int added=0;
                for(Uri uri:selected){if(epoch!=importEpoch||erasingPrivateData)break;if(songs.size()>=500&&!songs.containsKey(uri.toString()))break;if(!"content".equals(uri.getScheme()))continue;
                    try{
                        String mime=getContentResolver().getType(uri);if(mime==null||!mime.startsWith("audio/"))continue;
                        getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        String title="en".equals(AppLanguage.code(MainActivity.this))?"My song":"मेरा गाना";
                        try(android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())title=c.getString(0);if(title==null||title.trim().isEmpty())title="Audio";if(title.length()>300)title=title.substring(0,300);}
                        org.json.JSONObject row=new org.json.JSONObject();row.put("id",uri.toString());row.put("url",uri.toString());row.put("name",title);row.put("kind","local");readAudioMetadata(uri,row);songs.put(uri.toString(),row);added++;
                    }catch(Exception ignored){}
                }
                org.json.JSONArray result=new org.json.JSONArray();for(org.json.JSONObject row:songs.values())result.put(row);
                final int count=added;
                runOnUiThread(()->{if(epoch!=importEpoch||erasingPrivateData||destroyed)return;prefs.edit().putString("library",result.toString()).apply();js("window.onLibraryChanged && window.onLibraryChanged()");message(count>0?count+" गाने जोड़ दिए गए।":"गाने नहीं जुड़े। डिवाइस पर उपलब्ध ऑडियो फ़ाइल चुनें (अधिकतम 500)।");});
            }catch(Exception e){runOnUiThread(()->message("गाने नहीं जोड़े जा सके।"));}
        });
    }
    private void readAudioMetadata(Uri uri,org.json.JSONObject row){
        try(android.os.ParcelFileDescriptor fd=getContentResolver().openFileDescriptor(uri,"r")){
            if(fd==null)throw new java.io.IOException();
            row.put("available",true);
            android.media.MediaMetadataRetriever metadata=new android.media.MediaMetadataRetriever();
            try{
                metadata.setDataSource(this,uri);
                for(String[] field:new String[][]{{"name",String.valueOf(android.media.MediaMetadataRetriever.METADATA_KEY_TITLE)},{"artist",String.valueOf(android.media.MediaMetadataRetriever.METADATA_KEY_ARTIST)},{"genre",String.valueOf(android.media.MediaMetadataRetriever.METADATA_KEY_GENRE)}}){
                    String value=metadata.extractMetadata(Integer.parseInt(field[1]));if(value!=null&&!value.trim().isEmpty())row.put(field[0],value.trim().substring(0,Math.min(300,value.trim().length())));
                }
            }catch(Exception ignored){} // Valid audio may have no embedded tags.
            finally{try{metadata.release();}catch(Exception ignored){}}
        }catch(Exception e){try{row.put("available",false);}catch(org.json.JSONException ignored){}}
    }
    private void checkAudioLibrary(){runOnUiThread(()->{
        if(erasingPrivateData||destroyed)return;
        final int epoch=importEpoch;final String snapshot=prefs.getString("library","[]");
        importer.execute(()->{
            try{
                org.json.JSONArray rows=new org.json.JSONArray(snapshot);int unavailable=0;
                for(int i=0;i<rows.length();i++){
                    if(epoch!=importEpoch||erasingPrivateData||destroyed)return;
                    org.json.JSONObject row=rows.getJSONObject(i);Uri uri=Uri.parse(row.getString("url"));
                    if(!"content".equals(uri.getScheme()))continue;readAudioMetadata(uri,row);if(!row.optBoolean("available",true))unavailable++;
                }
                final int missing=unavailable;
                runOnUiThread(()->{
                    if(epoch!=importEpoch||erasingPrivateData||destroyed)return;
                    // Do not overwrite a newer import that completed after this snapshot.
                    if(!snapshot.equals(prefs.getString("library","[]")))return;
                    prefs.edit().putString("library",rows.toString()).apply();js("window.onLibraryChanged && window.onLibraryChanged()");
                    message(missing==0?"गानों की जाँच पूरी हुई। सभी चुनी फ़ाइलें खुल रही हैं।":missing+" फ़ाइलें उपलब्ध नहीं हैं। उन्हें फोन पर रखकर दोबारा जोड़ें।");
                });
            }catch(Exception e){runOnUiThread(()->message("गानों की जाँच नहीं हो सकी। फिर कोशिश करें।"));}
        });
    });}
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        companion=new RadioCompanion(this,this::js,this::message);
        welcomePending=state==null&&launcherEntry(getIntent());
        prefs=getSharedPreferences("player",MODE_PRIVATE);
        if("youtubeMusic".equals(prefs.getString("catalogProvider","all")))prefs.edit().putString("catalogProvider","all").apply();
        if(state==null)captureLaunch(getIntent());
        AppLanguage.apply(this);AppLanguage.apply(getApplicationContext());applyScreenPrivacy();
        controllerFuture=new androidx.media3.session.MediaController.Builder(this,new androidx.media3.session.SessionToken(this,new android.content.ComponentName(this,PlaybackService.class))).buildAsync();
        controllerFuture.addListener(()->{try{if(!destroyed&&!exiting){controller=controllerFuture.get();pendingPlayerAction.run();timerHandler.removeCallbacks(playerReadyTimeout);timerHandler.post(pulse);dispatchLaunch();dispatchVoice();}}catch(Exception e){pendingPlayerAction.clear();timerHandler.removeCallbacks(playerReadyTimeout);message("प्लेयर शुरू नहीं हो पाया। ऐप फिर खोलें।");}},androidx.core.content.ContextCompat.getMainExecutor(this));
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(16,24,25));
        webView=new WebView(this);webView.setBackgroundColor(Color.rgb(16,24,25));root.addView(webView,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root,(view,insets)->{Insets bars=insets.getInsets(WindowInsetsCompat.Type.systemBars()|WindowInsetsCompat.Type.displayCutout()|WindowInsetsCompat.Type.ime());view.setPadding(bars.left,bars.top,bars.right,bars.bottom);return WindowInsetsCompat.CONSUMED;});ViewCompat.requestApplyInsets(root);
        WebSettings settings=webView.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setMediaPlaybackRequiresUserGesture(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setJavaScriptCanOpenWindowsAutomatically(false);settings.setSupportMultipleWindows(false);settings.setSaveFormData(false);
        CookieManager.getInstance().setAcceptCookie(false);CookieManager.getInstance().setAcceptThirdPartyCookies(webView,false);CookieManager.getInstance().removeAllCookies(null);WebView.setWebContentsDebuggingEnabled(false);if(Build.VERSION.SDK_INT>=26)settings.setSafeBrowsingEnabled(true);
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(photoCallback!=null)photoCallback.onReceiveValue(null);photoCallback=callback;
                Intent picker=new Intent(Intent.ACTION_GET_CONTENT);picker.setType("image/*");picker.addCategory(Intent.CATEGORY_OPENABLE);picker.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/jpeg","image/png","image/webp"});
                try{startActivityForResult(picker,101);}catch(ActivityNotFoundException e){photoCallback.onReceiveValue(null);photoCallback=null;}return true;
            }
        });
        webView.addJavascriptInterface(new PlayerBridge(),"AndroidPlayer");
        webView.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap icon){if(HOME.equals(url)){pageReady=false;lastTransportRequest=0;pendingPlayerAction.clear();timerHandler.removeCallbacks(playerReadyTimeout);}}
            @Override public void onPageFinished(WebView view,String url){applyScreenPrivacy();if(HOME.equals(url)){pageReady=true;dispatchLaunch();dispatchVoice();}}
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
                Uri uri=request.getUrl();
                // Bundled cover art and the selected local photo never leave the device.
                if(!request.isForMainFrame()&&"data".equals(uri.getScheme())&&uri.toString().startsWith("data:image/"))return null;
                if(!"https".equals(uri.getScheme())||uri.getUserInfo()!=null||uri.getPort()!=-1)return blockedResource();
                if("appassets.androidplatform.net".equals(uri.getHost())){
                    WebResourceResponse local=loader.shouldInterceptRequest(uri);return local!=null?local:blockedResource();
                }
                if(request.isForMainFrame())return blockedResource();
                boolean api=java.util.Arrays.asList("de1.api.radio-browser.info","nl1.api.radio-browser.info","at1.api.radio-browser.info").contains(uri.getHost());
                return api||prefs.getBoolean("remoteArtwork",false)?null:blockedResource();
            }
            @Override public void onReceivedSslError(WebView view,SslErrorHandler handler,android.net.http.SslError error){handler.cancel();message("असुरक्षित कनेक्शन रोक दिया गया।");}
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){if(!request.isForMainFrame())return true;return navigate(request.getUrl(),request.hasGesture());}
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return navigate(Uri.parse(url),false);}
            @Override public boolean onRenderProcessGone(WebView view,RenderProcessGoneDetail detail){
                pageReady=false;pendingPlayerAction.clear();timerHandler.removeCallbacksAndMessages(null);if(photoCallback!=null){photoCallback.onReceiveValue(null);photoCallback=null;}root.removeView(view);view.destroy();webView=null;
                LinearLayout recovery=new LinearLayout(MainActivity.this);recovery.setOrientation(LinearLayout.VERTICAL);recovery.setPadding(48,80,48,48);
                TextView message=new TextView(MainActivity.this);message.setText(R.string.screen_closed);message.setTextColor(Color.WHITE);message.setTextSize(18);
                Button retry=new Button(MainActivity.this);retry.setText(R.string.reopen);retry.setOnClickListener(v->recreate());recovery.addView(message);recovery.addView(retry);root.addView(recovery);return true;
            }
        });
        getOnBackPressedDispatcher().addCallback(this,new OnBackPressedCallback(true){@Override public void handleOnBackPressed(){handleBack();}});
        webView.loadUrl(HOME);
    }
    private void withPlayer(long requestId,Runnable action){
        if(destroyed||exiting||erasingPrivateData)return;
        if(requestId>0&&requestId<lastTransportRequest)return;
        if(requestId>0)lastTransportRequest=requestId;
        if(controller!=null){pendingPlayerAction.clear();timerHandler.removeCallbacks(playerReadyTimeout);action.run();return;}
        // Keep only the newest intention: Stop/Pause supersede an earlier queued Play.
        pendingPlayerAction.replace(action);
        timerHandler.removeCallbacks(playerReadyTimeout);
        timerHandler.postDelayed(playerReadyTimeout,12000);
        message("प्लेयर तैयार हो रहा है। आदेश मिल गया है।");
    }
    // Publish the existing queue before interpreting Play, including a warm assistant launch.
    private void dispatchVoice(){if(pageReady&&controller!=null){sendState();js("window.readVoiceResult && window.readVoiceResult()");}}
    private void dispatchLaunch(){if(pageReady&&controller!=null){sendState();js("window.readLaunchRequest && window.readLaunchRequest()");}}
    private void captureLaunch(Intent intent){
        if(intent==null||erasingPrivateData)return;
        try{
            org.json.JSONObject request=new org.json.JSONObject();String action=intent.getAction();
            if(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH.equals(action)){
                String query=AssistantQuery.resolve(intent.getStringExtra(android.app.SearchManager.QUERY),
                    intent.getStringExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS),
                    intent.getStringExtra(android.provider.MediaStore.EXTRA_MEDIA_ARTIST),
                    intent.getStringExtra(android.provider.MediaStore.EXTRA_MEDIA_TITLE));
                if(query.length()>160)return;
                request.put("type",query.isEmpty()?"playDj":"search").put("query",query);
            }else if("com.zameer.radio.OPEN_FEATURE".equals(action)){
                String feature=intent.getStringExtra("feature");if(!java.util.Arrays.asList("dj","songs","local","settings").contains(feature))return;
                request.put("type",feature);
            }else return;
            synchronized(this){pendingLaunch=request.toString();}
        }catch(Exception ignored){}
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);captureLaunch(intent);dispatchLaunch();if(launcherEntry(intent)){synchronized(this){welcomePending=true;}if(pageReady)js("window.showWelcomeForLaunch && window.showWelcomeForLaunch()");}}
    private static boolean launcherEntry(Intent intent){return intent!=null&&Intent.ACTION_MAIN.equals(intent.getAction())&&intent.hasCategory(Intent.CATEGORY_LAUNCHER);}
    private boolean navigate(Uri uri,boolean userGesture){
        if("https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost()) && "/assets/index.html".equals(uri.getPath()) && uri.getPort()==-1)return false;
        if(userGesture&&RadioMatch.publicUrl(uri.toString())){try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(ActivityNotFoundException ignored){}}return true;
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(companion!=null&&companion.result(requestCode,resultCode,data))return;if(requestCode==102 && resultCode==RESULT_OK && data!=null){if(!erasingPrivateData&&activeImportEpoch==importEpoch)importAudio(data);return;}if(requestCode==101 && photoCallback!=null){Uri[] result=WebChromeClient.FileChooserParams.parseResult(resultCode,data);if(result!=null){for(Uri uri:result){if(!"content".equals(uri.getScheme())){result=null;break;}}}photoCallback.onReceiveValue(result);photoCallback=null;}}
    private void handleBack(){if(webView==null){finish();return;}webView.evaluateJavascript("(function(){var ids=['mixDialog','collectionDialog','welcomeDialog','nowDialog','designDialog'];for(var i=0;i<ids.length;i++){var d=document.getElementById(ids[i]);if(d&&d.open){if(d.tagName==='DETAILS')d.open=false;else d.close();return true;}}return window.ZrNavigation ? window.ZrNavigation.back() : false;})()",value->{if(!destroyed&&!"true".equals(value))finish();});}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==327){if(grants.length>0&&grants[0]==android.content.pm.PackageManager.PERMISSION_GRANTED)locate();else locationReply(null,locationEpoch);return;}
        if(requestCode==VoiceInput.PERMISSION_REQUEST&&voiceInput!=null&&!destroyed&&!erasingPrivateData)voiceInput.permissionResult(grants);
    }
    @Override protected void onStart(){super.onStart();UsageStore.open(prefs);}
    @Override protected void onResume(){super.onResume();foreground=true;foregroundAt=android.os.SystemClock.elapsedRealtime();timerHandler.removeCallbacks(foregroundTick);timerHandler.postDelayed(foregroundTick,15000);}
    @Override protected void onPause(){flushForeground();foreground=false;timerHandler.removeCallbacks(foregroundTick);super.onPause();}
    @Override protected void onStop(){if(voiceInput!=null)voiceInput.cancel();super.onStop();}
    @Override protected void onDestroy(){pendingPlayerAction.clear();if(voiceInput!=null)voiceInput.cancel();destroyed=true;locationEpoch++;if(locationCancel!=null)locationCancel.cancel();radioWorker.shutdownNow();importer.shutdown();if(controllerFuture!=null)androidx.media3.session.MediaController.releaseFuture(controllerFuture);timerHandler.removeCallbacksAndMessages(null);if(photoCallback!=null){photoCallback.onReceiveValue(null);photoCallback=null;}if(webView!=null){webView.removeJavascriptInterface("AndroidPlayer");webView.stopLoading();if(webView.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)webView.getParent()).removeView(webView);webView.destroy();webView=null;}if(companion!=null)companion.destroy();super.onDestroy();}
}
