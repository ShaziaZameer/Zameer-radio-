'use strict';
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./radio-core.js'),require('./radio-programmes.js'));else root.RadioMoodStatus=factory(root.RadioCore,root.RadioProgrammes);})(typeof window!=='undefined'?window:this,function(C,P){
 function current(station,selected,info={},now=new Date()){
  if(station.kind==='local')return {key:'local',basis:'local'};
  // Track labels can suggest a mood, but do not prove the contents of a live stream.
  const track=[info.genre,info.title,info.raw,info.album].filter(Boolean).join(' ');
  const inferred=track?C.categories({name:track,tags:info.genre||'',language:''}).filter(k=>!['regional','bhojpuri','poetry','naat','kavita'].includes(k)):[];
  if(inferred.length)return {key:inferred[0],basis:'track'};
  const programmes=P.forStation(station.url,[]),active=programmes.filter(p=>{const slot=P.occurrence(p.slot,now);return slot&&slot.start<=now.getTime()&&slot.end>now.getTime();});
  if(active.length){const p=active.find(p=>p.mood===selected)||active[0];return {key:p.mood,basis:'schedule',show:p.show};}
  if(programmes.length)return {key:'mixed',basis:'mixed'};
  const categories=C.categories(station),key=categories.includes(selected)?selected:categories[0]||'mixed';
  return {key,basis:categories.length?'station':'mixed'};
 }
 function label(mood,lang='hi'){return C.groups[mood.key]?.[lang==='en'?1:0]||({local:['फोन के गाने','Phone songs'],mixed:['मिश्रित लाइव रेडियो','Mixed live radio']}[mood.key]||['लाइव रेडियो','Live radio'])[lang==='en'?1:0];}
 function basis(mood,lang='hi'){
  const text={track:['ट्रैक के विवरण से अनुमानित मूड; ऑडियो की पहचान नहीं।','Mood estimated from track details; not audio recognition.'],schedule:['प्रकाशित कार्यक्रम का समय: '+(mood.show||'')+'। लाइव सामग्री बदल सकती है।','Published programme slot: '+(mood.show||'')+'. Live content may vary.'],station:['स्टेशन के विवरण पर आधारित मूड; स्टेशन बदलने पर अपने आप अपडेट होता है।','Mood based on station details; updates when the station changes.'],mixed:['अभी प्रसारित सामग्री का निश्चित मूड उपलब्ध नहीं है। कार्यक्रम और समय नीचे देखें।','The current programme’s mood is unconfirmed. See programme times below.'],local:['फोन की चुनी हुई ऑडियो फ़ाइल।','Selected audio from your phone.']};return (text[mood.basis]||text.mixed)[lang==='en'?1:0];
 }
 return {current,label,basis};
});
