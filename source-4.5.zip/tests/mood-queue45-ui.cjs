const {chromium}=require('playwright');
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../app/src/main/assets'),out=path.resolve(__dirname,'../qa/4.5');
const server=http.createServer((req,res)=>{try{const p=path.join(root,req.url==='/'?'index.html':req.url.split('?')[0]);res.setHeader('Content-Type',p.endsWith('.js')?'text/javascript':p.endsWith('.css')?'text/css':'text/html');res.end(fs.readFileSync(p));}catch(_){res.writeHead(404);res.end();}});
(async()=>{
 fs.mkdirSync(out,{recursive:true});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 try {
  const page=await browser.newPage({viewport:{width:393,height:851}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript(()=>{
   window.q=[];window.at=0;window.starts=0;window.visited=new Set();window.played=[];window.transport=0;window.applied={};window.playing=false;
   window.emit=()=>onNativeState({...q[at],playing,wants:playing,state:3,index:at,count:q.length,transportRequest:transport,radioInfo:{}});
   window.AndroidPlayer={language:()=> 'hi',consumeWelcome:()=>false,settings:j=>Object.assign(applied,JSON.parse(j)),library:()=>'[]',usageStats:()=>'{}',saveRadioDirectory:()=>{},consumeVoice:()=>'',consumeLaunch:()=>'{}',playbackQueue:()=>JSON.stringify(q),requestRadio:id=>setTimeout(()=>onRadioResponse(id,503,'{}'),5),
    playQueueWithId:(j,i,s)=>{q=JSON.parse(j);at=i;starts++;transport=s;playing=true;visited=new Set([q[at].url]);played=[q[at].url];setTimeout(emit,0);},
    appendRadioQueue:(j,url,s)=>{if(playing&&transport===s&&q[at]?.url===url){q=JSON.parse(j);setTimeout(emit,0);}},
    commandWithId:(a,v,s)=>{transport=s;if(['pause','stop','clearQueue'].includes(a))playing=false;if(a==='clearQueue'||a==='stop'){q=[];at=0;}if(a==='play')playing=true;if(['next','prev'].includes(a)){const next=RadioCore.cycleIndex(q,q[at]?.id,visited,a==='prev'?-1:1,!!applied.radioShuffle);if(next>=0){at=next;visited.add(q[at].url);played.push(q[at].url);}}setTimeout(emit,0);}
   };
  });
  await page.goto('http://127.0.0.1:'+server.address().port);
  const moods=await page.evaluate(()=>Object.keys(RadioCore.groups));
  const audit=[];
  for(const mood of moods){
   await page.selectOption('#genreFilter',mood);await page.waitForTimeout(180);
   const result=await page.evaluate(()=>({list:ZrRadio.selectedRows().map(s=>s.url),queue:q.map(s=>s.url),status:document.querySelector('#discoveryStatus').textContent,playing}));
   assert.deepEqual(new Set(result.queue),new Set(result.list),mood+' list/queue mismatch');
   assert(result.status.startsWith(result.list.length+' '),mood+' visible count');
   if(!result.list.length)assert.equal(result.playing,false,mood+' must not play off-theme fallback');
   audit.push({mood,count:result.queue.length});
  }
  await page.selectOption('#genreFilter','ghazal');await page.waitForFunction(()=>q.length===4);
  const initial=await page.evaluate(()=>starts),expected=await page.evaluate(()=>q.map(s=>s.url));
  for(let i=0;i<expected.length;i++){await page.click('#next');await page.waitForFunction(n=>played.length===n,i+2);}
  assert.deepEqual(await page.evaluate(()=>played),[...expected,expected[0]]);assert.equal(await page.evaluate(()=>starts),initial);
  await page.click('#prev');await page.waitForFunction(()=>at===q.length-1);assert.match(await page.textContent('#playerState'),/4 \/ 4/);
  await page.click('#openNow');await page.waitForSelector('#nowDialog[open]');await page.click('#npPrev');await page.waitForFunction(()=>at===2);await page.click('#npNext');await page.waitForFunction(()=>at===3);await page.click('#npNext');await page.waitForFunction(()=>at===0);
  await page.screenshot({path:path.join(out,'player-next-previous.png')});await page.click('#closeNow');
  await page.selectOption('#genreFilter','naat');await page.waitForFunction(()=>q.length===1);
  assert.equal(await page.evaluate(()=>q[0].name),'DC Naat Radio');assert.equal(await page.locator('#programmeLive .radio-card').count(),3);
  assert((await page.textContent('#programmeLive')).includes('मुख्य मूड सूची और उसकी कतार में शामिल नहीं'));
  await page.locator('#discoveryStatus').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(out,'naat-separated-programmes.png')});
  await page.locator('#programmeLive .radio-card').first().getByRole('button',{name:/मिश्रित लाइव/}).click();await page.waitForFunction(()=>q.length===3);await page.waitForSelector('#nowDialog[open]');await page.click('#closeNow');
  await page.selectOption('#genreFilter','ghazal');await page.fill('#stationSearch','News');await page.waitForTimeout(220);assert.equal(await page.evaluate(()=>ZrRadio.selectedRows().length),0);
  await page.evaluate(()=>ZrRadio.ask('सुकून रेडियो चलाओ'));await page.waitForTimeout(180);assert.equal(await page.evaluate(()=>q.length),2);assert.equal(await page.evaluate(()=>playing),true);
  await page.evaluate(()=>ZrRadio.ask('कविता चलाओ'));await page.waitForTimeout(180);assert.equal(await page.evaluate(()=>q.length),0);assert.equal(await page.evaluate(()=>playing),false);assert.equal(await page.locator('#programmeLive .radio-card').count(),0);
  await page.evaluate(()=>ZrRadio.ask('ग़ज़ल चलाओ'));await page.waitForFunction(()=>q.length===4);
  await page.click('#radioShuffle');for(let i=0;i<4;i++){await page.click('#next');await page.waitForTimeout(20);}const shuffled=await page.evaluate(()=>played);assert.equal(new Set(shuffled.slice(0,4)).size,4);assert.notEqual(shuffled[3],shuffled[4]);
  await page.selectOption('#uiLanguage','en');await page.selectOption('#genreFilter','naat');await page.waitForFunction(()=>document.querySelector('#discoveryStatus').textContent.startsWith('1 stations'));
  await page.setViewportSize({width:320,height:568});await page.click('#openNow');await page.waitForSelector('#nowDialog[open]');assert(await page.evaluate(()=>document.querySelector('#nowDialog').scrollWidth<=innerWidth));await page.screenshot({path:path.join(out,'player-small.png')});
  assert.deepEqual(errors,[]);fs.writeFileSync(path.join(out,'ui-audit.json'),JSON.stringify(audit,null,2));
  console.log('PASS: all 13 mood list/queue counts; no off-theme autoplay; search intersection; mixed programme separation; Next/Previous wrapping in both players; shuffle; 320px layout.');
 } finally {await browser.close();server.close();}
})().catch(e=>{console.error(e);server.close();process.exit(1)});
