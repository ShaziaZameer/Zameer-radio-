package com.zameer.radio;
public class RadioMood45Test {
 public static void main(String[] args){
  String[][] reject={{"भक्ति चलाओ","Islamabad Music","hindi"},{"पुराने गाने चलाओ","Classic Bhakti Sangeet","hindi"},{"समाचार सुनाओ","Regional FM music news","hindi"},{"सुकून चलाओ","Chilli Hits","hindi"},{"पार्टी चलाओ","Rocker Geetmala","hindi"}};
  for(String[] r:reject)if(RadioMatch.matches(r[0],r[1],r[2]))throw new AssertionError(r[1]);
  if(!RadioMatch.matches("पार्टी चलाओ","Bollywood Workout","hindi"))throw new AssertionError("Workout");
  if(RadioMatch.verifiedContent("नात चलाओ","https://stream.zeno.fm/2xuac28zpp8uv"))throw new AssertionError("Mixed programmes cannot confirm Naat now");
  String drone="https://ice5.somafm.com/dronezone-128-mp3",space="https://ice5.somafm.com/deepspaceone-128-mp3";
  if(!RadioMatch.matches("सुकून चलाओ","SomaFM Drone Zone ambient","instrumental",drone))throw new AssertionError("Curated ambient default");
  if(!RadioMatch.matches("ध्यान","SomaFM Deep Space One ambient","instrumental",space))throw new AssertionError("Curated ambient meditation");
  if(RadioMatch.matches("हिंदी सुकून","SomaFM Drone Zone ambient","instrumental",drone))throw new AssertionError("Explicit Hindi must remain strict");
  if(RadioMatch.matches("ग़ज़ल चलाओ","SomaFM Drone Zone ambient","instrumental",drone))throw new AssertionError("Not Ghazal");
  if(RadioMatch.matches("सुकून चलाओ","Unknown ambient","instrumental","https://fixture.example/stream"))throw new AssertionError("Unknown instrumental bypass");
  if(RadioMatch.verifiedContent("कविता चलाओ","https://listen.radioking.com/radio/416320/stream/469264"))throw new AssertionError("Rangoli is not dedicated Kavita");
  if(!RadioMatch.mood("कविता").equals("kavita"))throw new AssertionError("Kavita mood");
  RadioQueueHistory history=new RadioQueueHistory(new java.util.Random(1));
  java.util.List<String> queue=java.util.Arrays.asList("a","b","c");
  if(history.step(queue,2,1,false)!=0||history.step(queue,0,-1,false)!=2||history.step(queue,2,-1,false)!=1)throw new AssertionError("Manual wrapping");
  for(String url:queue)history.visit(url);if(history.step(queue,2,1,true)==2)throw new AssertionError("Shuffle repeated current");
  if(history.step(java.util.Collections.emptyList(),0,1,false)!=-1||history.step(java.util.Collections.singletonList("a"),0,1,false)!=0)throw new AssertionError("Small queue");
  System.out.println("20 native mood-filter/navigation assertions passed");
 }
}
