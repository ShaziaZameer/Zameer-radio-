const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const C=require('../app/src/main/assets/radio-core.js'),P=require('../app/src/main/assets/radio-programmes.js');
const box={window:{}};vm.runInNewContext(fs.readFileSync(require.resolve('../app/src/main/assets/radio-seed.js'),'utf8'),box);
const rows=C.unique(box.window.RadioSeed),audit={};let checks=0;
const req=(m,query='')=>C.askRequest({strictMood:true,moods:[m],query,languages:['naat','poetry'].includes(m)?['urdu']:m==='kavita'?['hindi']:[]});
for(const mood of Object.keys(C.groups)){
 const request=req(mood),result=C.discover(C.rankFavorites(rows),request),q=C.stationQueue(result.rows[0],result.rows);
 assert.equal(result.generalFallback,false,mood);assert.equal(result.related,false,mood);assert(result.rows.every(s=>C.categories(s).includes(mood)),mood);
 assert.deepEqual(new Set(q.map(s=>s.url)),new Set(result.rows.map(s=>s.url)),mood+' visible/queue parity');
 assert.equal(C.discover(rows,req(mood,'zzzinvalidstationzz')).rows.length,0,mood+' search must not ignore unmatched terms');
 const seen=new Set();let id='';for(let i=0;i<q.length;i++){const at=C.nextIndex(q,id,seen);assert(at>=0);id=q[at].id;seen.add(q[at].url);}assert.equal(C.nextIndex(q,id,seen),-1);
 audit[mood]={stations:q.map(s=>({name:s.name,url:s.url})),count:q.length,scheduledOptions:P.select(rows,request,C).map(p=>({name:p.station.name,show:p.show}))};checks+=6;
}
const station=(name,tags,language='hindi')=>C.station({id:name,url:'https://fixture.example/'+encodeURIComponent(name),name,tags,language});
for(const [m,name,tags] of [
 ['devotional','Islamabad Music','bollywood'],['energy','Rocker Radio Geetmala','music'],['energy','Soft Pop Ballads','pop'],
 ['retro','Classic Bhakti Sangeet','bhakti'],['calm','Chilli Hits','music'],['ghazal','Sufiyan News','news'],
 ['news','Regional Music FM','regional,music,news'],['calm','Romantic Radio','romantic,love songs']
]){assert.equal(C.discover([station(name,tags)],req(m)).rows.length,0,m+' false positive '+name);checks++;}
for(const [m,name,tags] of [['energy','Workout Radio','workout'],['devotional','Bhaktisudha','bhakti'],['calm','Relaxing Instrumental','instrumental'],['news','News 24','news'],['ghazal','Ghazals','ghazal']]){assert.equal(C.discover([station(name,tags)],req(m)).rows.length,1,m+' positive');checks++;}
const mixed=rows.find(s=>s.name==='Radio Islam Urdu');assert(mixed);assert.equal(C.discover([mixed],req('naat')).rows.length,0);assert(P.select(rows,req('naat'),C).some(p=>p.station.url===mixed.url));checks+=2;
const bad=station('Invalid Ghazal','ghazal');bad.lastcheckok=0;assert.equal(C.discover([bad],req('ghazal')).rows.length,0);
const news=station('Unrelated News Favorite','news');assert.equal(C.discover(C.rankFavorites([news],{favorites:[news.id]}),req('ghazal')).rows.length,0);checks+=2;
fs.mkdirSync('qa/4.5',{recursive:true});fs.writeFileSync('qa/4.5/mood-audit.json',JSON.stringify(audit,null,2));
console.log(checks+' assertions passed: all 13 moods, exact search, queue parity/rotation, false-positive exclusions, mixed programmes and favorites.');

const cycle=['a','b','c'].map((id)=>({id,url:'https://fixture.example/'+id}));
assert.equal(C.cycleIndex(cycle,'c',new Set(cycle.map(s=>s.url))),0);
assert.equal(C.cycleIndex(cycle,'a',new Set(),-1),2);
assert.equal(C.cycleIndex(cycle,'c',new Set(),-1),1);
const visited=new Set(cycle.map(s=>s.url));assert.notEqual(C.cycleIndex(cycle,'c',visited,1,true),2);assert.equal(visited.size,1);
assert.equal(C.cycleIndex([],null),-1);assert.equal(C.cycleIndex([cycle[0]],'a'),0);
console.log('7 manual navigation assertions passed: next/previous wrap, shuffle cycle reset, single/empty queue.');

const calm=C.discover(rows,req('calm')).rows,ghazal=C.discover(rows,req('ghazal')).rows;
assert.equal(calm.length,2);assert(calm.every(s=>s.language==='instrumental'));
assert(!calm.some(s=>ghazal.some(g=>s.url===g.url)));
assert.equal(C.discover(rows,C.askRequest({...C.intent('सुकून रेडियो चलाओ'),strictMood:true})).rows.length,2);
assert.equal(C.discover(rows,C.askRequest({...C.intent('ध्यान'),strictMood:true})).rows.length,2);
assert.equal(C.discover(rows,C.askRequest({moods:['calm'],languages:['hindi'],strictMood:true})).rows.length,0);
assert.equal(C.discover([station('Unverified Ambient','ambient','instrumental')],req('calm')).rows.length,0);
assert.equal(C.discover(rows,req('kavita')).rows.length,0);assert.equal(P.select(rows,req('kavita'),C).length,0);
assert(calm.every(s=>s.lastcheckok===null),'Do not invent audio probe success');
const M=require('../app/src/main/assets/mahfil-core.js');
assert.equal(M.mixRows({moods:['kavita'],language:'hindi'},rows,C,P).length,0);
assert.equal(M.mixRows({moods:['calm'],language:''},rows,C,P).length,2);
console.log('12 station-curation assertions passed: distinct calm streams, typed requests, language boundaries, no fake probe success, Rangoli excluded and strict saved mixes.');
