const assert=require('node:assert/strict');
const K=require('../app/src/main/assets/kavita-recordings.js');
const M=require('../app/src/main/assets/radio-mood-status.js');
assert.equal(K.select({moods:['kavita'],languages:['hindi']}).length,6);
assert.equal(K.select({moods:['ghazal']}).length,0);
assert.equal(K.select({moods:['kavita'],languages:['urdu']}).length,0);
assert.equal(K.select({moods:['kavita'],query:'पंत'})[0].name,'लहरों का गीत');
assert.equal(K.select({moods:['kavita'],query:'news'}).length,0);
assert.equal(K.queue([{id:'fake',url:'https://fake.example/poem.mp3'}]).length,0);
assert.equal(K.queue([K.episodes[2],K.episodes[2]]).length,1);
assert.deepEqual(M.current(K.episodes[0],'ghazal',{title:'Dance Music'}),{key:'kavita',basis:'recorded'});
assert.equal(K.time(137),'2:17');
assert.equal(new Set(K.episodes.map(e=>e.url)).size,6);
assert(K.episodes.every(e=>e.kind==='podcast'&&e.duration>0&&e.artist&&e.sourceUrl.startsWith('https://share.transistor.fm/')));
console.log('PASS: recorded poetry curation, language/search matching, publisher attribution, strict queue whitelist, finite durations and recorded mood labels.');

assert.equal(require('../app/src/main/assets/radio-core.js').unique(K.episodes).length,0,'Recordings must not become saved radio stations');
