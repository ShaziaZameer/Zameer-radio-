"""Read-only network/codec probes. Genre evidence is separately reviewed from publishers.
A failed probe is not proof a station is globally offline (region/network limits apply).
"""
import concurrent.futures, datetime, json, subprocess
from pathlib import Path
out = Path('qa/4.5')
audit = json.loads((out / 'mood-audit.json').read_text())
by_url = {}
for mood, entry in audit.items():
    for station in entry['stations']:
        item = by_url.setdefault(station['url'], {**station, 'moods': []})
        item['moods'].append(mood)
def check(item):
    result = dict(item)
    try:
        proc = subprocess.run(['ffprobe', '-v', 'error', '-rw_timeout', '10000000', '-analyzeduration', '1000000', '-probesize', '65536', '-show_entries', 'stream=codec_type,codec_name,sample_rate', '-of', 'json', item['url']], capture_output=True, text=True, timeout=20)
        streams = json.loads(proc.stdout or '{}').get('streams', [])
        result['audioDecoded'] = proc.returncode == 0 and any(s.get('codec_type') == 'audio' for s in streams)
        result['streams'] = streams
        if not result['audioDecoded']:
            result['error'] = proc.stderr[-500:]
    except (subprocess.TimeoutExpired, json.JSONDecodeError) as error:
        result.update(audioDecoded=False, error=type(error).__name__)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
    rows = list(executor.map(check, by_url.values()))
report = {'checkedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'region': 'GitHub Actions runner', 'meaning': 'Stream/codec reachability only; not a continuous content or device playback guarantee.', 'stations': rows}
(out / 'stream-audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
print('Audio codec detected:', sum(r['audioDecoded'] for r in rows), '/', len(rows))
for row in rows:
    if 'calm' in row['moods']:
        print(row['name'], row['audioDecoded'], row.get('error', ''))
