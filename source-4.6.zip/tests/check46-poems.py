import concurrent.futures, datetime, json, pathlib, subprocess, urllib.request, xml.etree.ElementTree as ET

root=pathlib.Path(__file__).resolve().parents[1]
rows=json.loads(subprocess.check_output(['node','-e',"console.log(JSON.stringify(require('./app/src/main/assets/kavita-recordings.js').episodes))"],cwd=root))
remaining={r['url'] for r in rows}
with urllib.request.urlopen('https://feeds.transistor.fm/pratidin-ek-kavita',timeout=30) as response:
    for event,item in ET.iterparse(response,events=('end',)):
        if item.tag=='item':
            enclosure=item.find('enclosure')
            if enclosure is not None: remaining.discard(enclosure.get('url'))
            item.clear()
            if not remaining: break
assert not remaining, 'A selected recording is missing from the publisher feed: '+str(remaining)

def check(row):
    result=subprocess.run(['ffmpeg','-v','error','-rw_timeout','15000000','-i',row['url'],'-t','5','-f','null','-'],capture_output=True,text=True,timeout=40)
    return {'name':row['name'],'url':row['url'],'feedVerified':True,'firstFiveSecondsDecoded':result.returncode==0,'error':result.stderr[-600:]}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: results=list(pool.map(check,rows))
out=root/'qa/4.6';out.mkdir(parents=True,exist_ok=True)
(out/'recording-audit.json').write_text(json.dumps({'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'recordings':results},ensure_ascii=False,indent=2))
assert all(r['firstFiveSecondsDecoded'] for r in results), results
print('PASS: all six selected recordings match the publisher feed and decode audio successfully.')
