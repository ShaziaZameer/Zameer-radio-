'use strict';
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.RadioNear=api;})(typeof window!=='undefined'?window:this,()=>{
 const norm=v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^\p{L}\p{M}\p{N}]+/gu,' ').trim();
 const regions=new Set();
 function city(row){regions.add(row[2]+'|'+norm(row[3]));return {id:String(row[0]),name:row[1],country:row[2],region:row[3],lat:row[4],lon:row[5],aliases:row[6].split('|').filter(Boolean)};}
 const words=(text,name)=>(' '+text+' ').includes(' '+name+' '),placeNames=new WeakMap();
 function match(station,place){
  if(String(station.countrycode||'').toUpperCase()!==place.country||station.lastcheckok===0)return null;
  if(!placeNames.has(place))placeNames.set(place,[place.name,...place.aliases].map(norm).filter(n=>n.length>=3));const names=placeNames.get(place),explicit=norm(station.city),state=norm(station.state),hay=norm([station.name,station.tags].join(' '));
  if(state&&regions.has(place.country+'|'+state)&&state!==norm(place.region)&&!names.includes(state))return null;
  if(explicit&&!names.some(n=>words(explicit,n)))return null;
  if(!explicit&&!names.some(n=>words(hay,n)||String(station.state||'').split(/[,;/]/).map(norm).includes(n)))return null;
  const result={...station,placeMatch:'city'};delete result.distance;delete result.distanceBasis;delete result.nearCity;return result;
 }
 function validCoordinates(s){return Number.isFinite(s.geo_lat)&&Number.isFinite(s.geo_long)&&Math.abs(s.geo_lat)<=90&&Math.abs(s.geo_long)<=180&&!(s.geo_lat===0&&s.geo_long===0);}
 function createLocator(cities,C){
  const byName=new Map(),byCountry=new Map(),cache=new Map();
  for(const c of cities){if(!byCountry.has(c.country))byCountry.set(c.country,[]);byCountry.get(c.country).push(c);for(const name of new Set([c.name,...c.aliases].map(norm).filter(n=>n.length>=3))){const key=c.country+'|'+name;if(!byName.has(key))byName.set(key,[]);byName.get(key).push(c);}}
  function named(station){
   if(!station.city)return null;let places=byName.get(String(station.countrycode).toUpperCase()+'|'+norm(station.city))||[];
   const state=norm(station.state),scoped=places.filter(c=>norm(c.region)===state||[c.name,...c.aliases].some(n=>norm(n)===state));if(scoped.length)places=scoped;else if(state&&regions.has(station.countrycode+'|'+state))return null;
   return places.length===1?places[0]:null;
  }
  function nearby(place,radius){const key=place.id+'|'+radius;if(cache.has(key))return cache.get(key);const list=(byCountry.get(place.country)||[]).filter(c=>c.id!==place.id&&C.distance(place.lat,place.lon,{geo_lat:c.lat,geo_long:c.lon})<=radius).map(c=>({...c,names:[...new Set([c.name,...c.aliases].map(norm).filter(n=>n.length>=3))]}));cache.set(key,list);if(cache.size>30)cache.delete(cache.keys().next().value);return list;}
  function locate(station,place,radius){
   // Explicit city identity is authoritative when station coordinates are absent or inconsistent.
   const known=named(station);if(known)return {lat:known.lat,lon:known.lon,basis:'city',city:known.name};
   if(station.city)return validCoordinates(station)?{lat:station.geo_lat,lon:station.geo_long,basis:'coordinates',city:station.city}:null;
   const state=norm(station.state),hay=norm([station.name,station.tags].join(' ')),matches=nearby(place,radius).filter(c=>(!state||!regions.has(place.country+'|'+state)||norm(c.region)===state)&&c.names.some(n=>words(hay,n)||state===n));
   const exactState=matches.filter(c=>[c.name,...c.aliases].some(n=>norm(n)===state));const candidates=exactState.length?exactState:matches;
   if(candidates.length===1)return {lat:candidates[0].lat,lon:candidates[0].lon,basis:'city',city:candidates[0].name};
   if(validCoordinates(station))return {lat:station.geo_lat,lon:station.geo_long,basis:'coordinates',city:''};
   return null;
  }
  return {locate};
 }
 function select(rows,place,C,{radius=0,locator=null}={}){
  return C.unique(rows).flatMap(s=>{const exact=match(s,place);if(exact)return [exact];if(!radius||s.lastcheckok===0||String(s.countrycode).toUpperCase()!==place.country)return [];
   const position=locator?.locate(s,place,radius)||(validCoordinates(s)?{lat:s.geo_lat,lon:s.geo_long,basis:'coordinates',city:s.city||''}:null);if(!position)return [];
   const distance=C.distance(place.lat,place.lon,{geo_lat:position.lat,geo_long:position.lon});return Number.isFinite(distance)&&distance<=radius?[{...s,placeMatch:'nearby',distance,distanceBasis:position.basis,nearCity:position.city}]:[];
  }).sort((a,b)=>Number(a.placeMatch==='nearby')-Number(b.placeMatch==='nearby')||(a.distance||0)-(b.distance||0)||a.name.localeCompare(b.name));
 }
 function counts(rows){return {city:rows.filter(s=>s.placeMatch==='city').length,nearby:rows.filter(s=>s.placeMatch==='nearby').length};}
 // Every page is fetched. A repeated page is an incomplete search, never a successful empty result.
 async function scan(request,code,{active=()=>true,batch=()=>{},size=500}={}){
  const seen=new Set();let offset=0;
  while(active()){
   const rows=await request('/json/stations/search',{countrycode:code,hidebroken:'true',order:'name',reverse:'false',limit:String(size),offset:String(offset)});
   if(!active())return {cancelled:true};if(!Array.isArray(rows))throw Error('directory');
   const signature=JSON.stringify(rows.map(s=>s.stationuuid||s.id||s.url_resolved||s.url));if(rows.length&&seen.has(signature))throw Error('repeated-page');seen.add(signature);batch(rows,rows.length<size);offset+=rows.length;if(rows.length<size)return {complete:true,total:offset};
  }
  return {cancelled:true};
 }
 return {city,match,select,scan,createLocator,counts};
});
