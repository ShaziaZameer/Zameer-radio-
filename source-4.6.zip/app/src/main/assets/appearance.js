'use strict';
// Appearance is local and independent of audio, search and native playback.
(() => {
 const I18n=window.ZrI18n, $=id=>document.getElementById(id), key='zrHomeDesign';
 const names={classic:'क्लासिक',midnight:'मिडनाइट',aurora:'ऑरोरा',vintage:'विंटेज',blossom:'गुलाबी',minimal:'मिनिमल'};
 const dialog=$('designDialog');let design='classic',opener=null;
 try{const value=JSON.parse(localStorage.getItem(key)||'"classic"');if(Object.hasOwn(names,value))design=value;document.body.classList.toggle('light',JSON.parse(localStorage.getItem('zrTheme')||'"dark"')==='light')}catch(_){}
 function syncTheme(){document.querySelector('meta[name="theme-color"]').content=getComputedStyle(document.body).getPropertyValue('--bg').trim()||'#101819';}
 function apply(save=false){
  document.body.dataset.design=design;
  for(const button of dialog.querySelectorAll('[data-design-choice]')){const active=button.dataset.designChoice===design;button.setAttribute('aria-pressed',String(active));button.querySelector('.design-selected').hidden=!active;}
  I18n.put($('currentDesign'),names[design]);syncTheme();
  if(save){try{localStorage.setItem(key,JSON.stringify(design));I18n.put($('designStatus'),'डिज़ाइन सहेजा गया। अगली बार भी यही रूप खुलेगा।')}catch(_){I18n.put($('designStatus'),'डिवाइस पर सहेजना संभव नहीं है। बदलाव इस बार तक रहेंगे।')}}
 }
 function open(event){opener=event.currentTarget;I18n.put($('designStatus'),'पसंद का रूप चुनें। बदलाव तुरंत दिखेगा।');if(!dialog.open)dialog.showModal();dialog.querySelector('[aria-pressed="true"]').focus({preventScroll:true});dialog.scrollTop=0;}
 $('openDesign').addEventListener('click',open);$('settingsDesign').addEventListener('click',open);
 $('closeDesign').addEventListener('click',()=>dialog.close());
 dialog.addEventListener('close',()=>opener?.focus({preventScroll:true}));
 for(const button of dialog.querySelectorAll('[data-design-choice]'))button.addEventListener('click',()=>{const next=button.dataset.designChoice;if(!Object.hasOwn(names,next))return;design=next;apply(true)});
 $('resetDesign').addEventListener('click',()=>{design='classic';apply(true)});
 window.ZrAppearance={syncTheme,refresh:()=>apply(false)};apply();
})();
