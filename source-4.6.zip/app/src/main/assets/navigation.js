
'use strict';
(()=>{const $=id=>document.getElementById(id),sections=['home','discovery','ask','near','summary','owners','localPanel','settings','mahfil'];let active='home';
 const routes={mahfil:['mahfil'],home:['home','discovery'],ask:['ask'],near:['near'],summary:['summary'],settings:['settings','localPanel','owners']};
 function go(id,scroll=true,user=false){if(id==='discovery')id='home';if(!routes[id])return;active=id;window.dispatchEvent(new CustomEvent('zrnavigate',{detail:{id,user}}));if(id==='near')window.prepareNearCities?.();for(const key of sections)$(key).hidden=!routes[id].includes(key);document.querySelectorAll('.front-nav a').forEach(a=>{const on=a.getAttribute('href')==='#'+id;if(on)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});if(id==='summary')window.ZrRadio?.renderSummary();if(scroll)window.scrollTo({top:0,behavior:'instant'});}
 $('settings').after($('localPanel'),$('owners'));
 document.querySelectorAll('.front-nav a,.brand,.hero-cta').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();const target=a.getAttribute('href').slice(1);go(target,true,true);if(target==='discovery')$('discovery').scrollIntoView({behavior:'smooth'});}));
 window.ZrNavigation={go,current:()=>active,back(){if(active==='home')return false;go('home',true,true);return true;}};go('home',false);
})();
