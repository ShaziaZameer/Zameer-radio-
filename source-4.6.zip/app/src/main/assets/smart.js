'use strict';
/* Local, content-based recommender. Sparse TF-IDF + weighted user profile;
   no remote model, microphone capture, embeddings service or API credentials. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ZrSmart=api;})(typeof globalThis==='object'?globalThis:this,()=>{
 const stop=new Set(['radio','fm','the','and','live','hindi','india','online','रेडियो','हिंदी','लाइव']);
 const moodRules={
  calm:/\b(relax|ambient|chill|peaceful|soft|classical)\b|सुकून|शांत|मधुर/i,
  energy:/\b(dance|party|rock|energetic|excited|upbeat)\b|जोश/i,
  devotional:/\b(bhakti|bhajan|chhath|chhat|devotional|spiritual|religious|mantra|kirtan|aart[iy])\b|भक्ति|भजन|आरती|कीर्तन|देवी|छठ/i,
  retro:/\b(old|oldies|retro|classic|golden|nostalgic|evergreen|kishore|rafi|lata)\b|पुराने/i,
  news:/\b(news|talk|podcast)\b|समाचार|खबर/i,
  happy:/\b(happy|cheerful|uplifting|joy|joyful|upbeat)\b|खुशी|खुशियाँ/i,
  romantic:/\b(romantic|romance|love|tender|pyar|pyaar|mohabbat|prem|piya|sajan|saiyan)\b|रोमांटिक|प्यार|मोहब्बत|प्रेम|पिया|साजन/i,
  sad:/\b(sad|bewafa|birha|virah|melancholy|melancholic|heartbreak|heartbroken|emotional|yearning)\b|उदास|दर्द|बेवफा|विरह|बिरहा/i,
  focus:/\b(focus|study|lofi|lo[ -]fi|instrumental|concentration)\b|पढ़ाई|एकाग्रता|वाद्य/i,
  sleep:/\b(sleep|sleeping|lullaby|ambient|peaceful)\b|नींद|लोरी/i,
  party:/\b(party|dance|edm|house|disco|celebration)\b|पार्टी|नाच/i,
  workout:/\b(workout|gym|running|fitness|energetic|powerful)\b|कसरत|व्यायाम/i,
  meditation:/\b(meditation|meditative|mantra|zen|healing|peaceful)\b|ध्यान|मंत्र/i,
  travel:/\b(travel|road|journey|adventure|driving)\b|सफ़र|सफर|यात्रा/i,
  acoustic:/\b(acoustic|unplugged|guitar|folk|kajri|sohar)\b|अकूस्टिक|गिटार|लोकगीत|कजरी|सोहर/i
 };
 const radioQueries={personal:[],calm:['relax','soft','classical'],energy:['dance','party','rock'],devotional:['bhakti','bhajan','devotional'],retro:['retro','oldies','golden'],news:['news','talk'],happy:['happy','upbeat','joy'],romantic:['romantic','love','romance'],sad:['sad','emotional','heartbreak'],focus:['lofi','instrumental','study'],sleep:['sleep','ambient','peaceful'],party:['party','dance','disco'],workout:['workout','energetic','fitness'],meditation:['meditation','mantra','zen'],travel:['travel','road','journey'],acoustic:['acoustic','unplugged','folk']};
 const moodNames={personal:'मेरी पसंद',calm:'सुकून',energy:'जोश',devotional:'भक्ति',retro:'पुराने गीत',news:'खबरें',happy:'खुशियाँ',romantic:'रोमांटिक',sad:'उदास दिल',focus:'पढ़ाई / एकाग्रता',sleep:'नींद',party:'पार्टी',workout:'कसरत',meditation:'ध्यान',travel:'सफ़र',acoustic:'अकूस्टिक'};
 function matchesMood(row,mood){if(mood==='personal'||!Object.prototype.hasOwnProperty.call(moodRules,mood))return true;if(Object.prototype.hasOwnProperty.call(moodRules,row.assignedMood))return row.assignedMood===mood;return moodRules[mood].test([row.name,row.artist,row.tags,row.genre,row.mood].filter(Boolean).join(' ').replace(/[_./-]/g,' '));}
 function tokens(row){return [...new Set([row.name,row.artist,row.tags,row.genre,row.mood,row.assignedMood].filter(Boolean).join(' ').normalize('NFKC').toLowerCase().match(/[\p{L}\p{N}\p{M}]+/gu)||[])].filter(t=>t.length>1&&!stop.has(t)).slice(0,64)}
 function dot(a,b){let total=0;for(const [k,v]of a)total+=v*(b.get(k)||0);return total}
 function unit(v){let n=Math.sqrt(dot(v,v));if(n)for(const [k,x]of v)v.set(k,x/n);return v}
 function recommend(rows,options={},limit=6){
  const seed=options.seed&&typeof options.seed.id==='string'?options.seed:null;
  const all=[...new Map((Array.isArray(rows)?rows:[]).filter(s=>s&&typeof s.id==='string').map(s=>[s.id,s])).values()].slice(0,600);
  if(seed&&!all.some(s=>s.id===seed.id))all.push(seed);
  const excluded=new Set(options.exclude||[]);if(seed)excluded.add(seed.id);
  const feedback=options.feedback&&typeof options.feedback==='object'?options.feedback:{};
  const favorites=new Set(options.favorites||[]),recent=new Map((options.recent||[]).map((id,i)=>[id,Math.max(.2,.75-i*.025)]));
  const docs=all.map(tokens),df=new Map();for(const d of docs)for(const t of d)df.set(t,(df.get(t)||0)+1);
  const vectors=docs.map(d=>unit(new Map(d.map(t=>[t,Math.log(1+all.length/(1+df.get(t)))+1]))));
  const seedVector=seed?vectors[all.findIndex(s=>s.id===seed.id)]:null;
  const positive=new Map(),negative=new Map();let learned=false;
  all.forEach((row,i)=>{const fb=Object.prototype.hasOwnProperty.call(feedback,row.id)?Number(feedback[row.id]):0;const weight=fb<0?0:(favorites.has(row.id)?3:0)+(recent.get(row.id)||0)+(fb>0?4:0);if(weight>0)learned=true;for(const [t,v]of vectors[i]){if(weight)positive.set(t,(positive.get(t)||0)+v*weight);if(fb<0)negative.set(t,(negative.get(t)||0)+v)}});
  unit(positive);unit(negative);
  const mood=Object.prototype.hasOwnProperty.call(moodNames,options.mood)?options.mood:'personal',rule=moodRules[mood];
  const candidates=all.map((row,i)=>({row,i,similarity:seedVector?dot(vectors[i],seedVector):0,score:(seedVector?dot(vectors[i],seedVector):0)+(learned?dot(vectors[i],positive)*.8:0)-dot(vectors[i],negative)*.15+(favorites.has(row.id)?.12:0)+.06/(i+1)})).filter(x=>!excluded.has(x.row.id)&&!(Number(feedback[x.row.id])<0)&&matchesMood(x.row,mood)&&(!options.requireSimilarity||x.similarity>.05));
  const output=[];limit=Math.min(60,Math.max(0,Math.floor(Number(limit)||0)));
  while(candidates.length&&output.length<limit){
   for(const c of candidates)c.rank=c.score-(output.length?Math.max(...output.map(x=>dot(vectors[c.i],vectors[x.i])))*.06:0);
   candidates.sort((a,b)=>b.rank-a.rank||a.i-b.i);const best=candidates.shift();
   best.reason=seedVector?'अभी के ट्रैक से मिलते नाम/टैग':rule?(best.row.assignedMood===mood?'आपके चुने मूड से':moodNames[mood]+' से जुड़े नाम/टैग'):favorites.has(best.row.id)?'आपकी पसंद में शामिल':learned&&dot(vectors[best.i],positive)>.05?'आपकी पसंद से मिलते नाम/टैग':'उपलब्ध सूची से नई खोज';output.push(best);
  }
  return {learned,mood,items:output.map(x=>({...x.row,reason:x.reason}))};
 }

 // Bounded command grammar: every modifier must be recognized. Track metadata,
 // not an artist's reputation, is the evidence for a requested mood or era.
 const commandModifiers={पुराने:'retro',पुराना:'retro',पुरानी:'retro',old:'retro',oldies:'retro',retro:'retro',रोमांटिक:'romantic',रोमांस:'romantic',romantic:'romantic',romance:'romantic',सुकून:'calm',शांत:'calm',calm:'calm',relaxing:'calm',उदास:'sad',sad:'sad',खुशी:'happy',happy:'happy',भक्ति:'devotional',devotional:'devotional',पार्टी:'party',party:'party',पढ़ाई:'focus',focus:'focus',study:'focus',कसरत:'workout',workout:'workout',ध्यान:'meditation',meditation:'meditation'};
 const commandLanguages={हिंदी:'hi',हिन्दी:'hi',hindi:'hi',भोजपुरी:'bho',bhojpuri:'bho',पंजाबी:'pa',punjabi:'pa',उर्दू:'ur',urdu:'ur',बंगाली:'bn',bengali:'bn',मराठी:'mr',marathi:'mr',गुजराती:'gu',gujarati:'gu',तमिल:'ta',tamil:'ta',तेलुगु:'te',telugu:'te',कन्नड़:'kn',kannada:'kn',मलयालम:'ml',malayalam:'ml',अंग्रेजी:'en','अंग्रेज़ी':'en',english:'en'};
 function compositeArtist(s){
  const body=s.replace(/^play /,'').replace(/ चलाओ$/,'');let artist='',qualifiers='',followup=false;
  let m=body.match(/^(.+?) (?:के|की|का) (.*?)\s*(?:गाने|गीत|गाना|संगीत)$/);
  if(m){artist=m[1];qualifiers=m[2];followup=/^(?:इसी|इस|उस) (?:कलाकार|गायक)$/.test(artist);}
  else if((m=body.match(/^(?:इनके|उनके|उसी के) (.*?)\s*(?:गाने|गीत|गाना)$/))){followup=true;qualifiers=m[1];}
  else if((m=body.match(/^(.*?)\s*(?:songs?|music) (?:by|of) (.+)$/))){qualifiers=m[1];artist=m[2];followup=/^(?:(?:this|the same) artist|him|her|them)$/.test(artist);}
  else return null;
  const filters=[];let language;qualifiers=qualifiers.replace(/(?:19|20)\d0s|(?:19|20)\d0 के दशक|90s|90 के दशक/gi,v=>{filters.push('decade'+(/^90/.test(v)?1990:Number(v.slice(0,4))));return ' ';});
  for(const token of qualifiers.split(' ').filter(Boolean)){
   if(commandModifiers[token])filters.push(commandModifiers[token]);
   else if(commandLanguages[token]){if(language&&language!==commandLanguages[token])return {action:'unknown'};language=commandLanguages[token];}
   else return null;
  }
  if(!followup&&!qualifiers)return null;
  if(!followup&&(!artist||artist.length>80))return {action:'unknown'};
  return {action:followup?'followupArtist':'playArtist',...(!followup?{artist}:{}),...(filters.length?{filters:[...new Set(filters)]}:{}),...(language?{language}:{})};
 }
 function matchesFilters(row,filters=[]){
  if(!filters)filters=[];
  if(!filters.length)return true;
  if(!row.kind||row.kind==='artistRadio')return false;
  const info=[row.name,row.tags,row.genre,row.mood,row.album,row.year,row.releaseYear].filter(Boolean).join(' ').replace(/[_./-]/g,' ');
  return filters.every(mood=>{if(/^decade(?:19|20)\d0$/.test(mood)){const d=Number(mood.slice(6)),years=info.match(/\b(?:19|20)\d{2}\b/g)||[];return years.some(y=>Number(y)>=d&&Number(y)<d+10)||info.toLowerCase().includes(d+'s')||d===1990&&/\b90s\b/.test(info);}return row.assignedMood===mood|| (mood==='retro'?/\b(old|oldies|retro|classic|golden|nostalgic|evergreen)\b|पुरान[ेाी]/i.test(info):row.assignedMood===mood||!!moodRules[mood]?.test(info));});
 }
 function parseCommand(input){
  const normalized=String(input||'').normalize('NFKC').toLowerCase().replace(/[।.!?,]/g,' ').replace(/\s+/g,' ').trim().slice(0,160).replace(/^(?:कृपया|प्लीज|please)\s+/,'').replace(/(?: on zameer radio| (?:ज़मीर|जमीर|ज़मीर) रेडियो पर)$/,'').replace(/^(?:अब|अभी|now)\s+/,'');
  // Exact feedback phrases are the only exception to the negation guard.
  // A dislike records a preference; it never means play, skip or stop.
  if(/^(?:(?:मुझे )?(?:यह|ये|यह गाना|ये गाना|यह गीत|यह स्टेशन) पसंद नहीं(?: है)?|i (?:don't|do not) like (?:this|this song|this station)|dislike this(?: song| station)?)$/.test(normalized))return {action:'feedback',value:-1};
  if(/^(?:(?:मुझे )?(?:यह|ये|यह गाना|ये गाना|यह गीत|यह स्टेशन) पसंद(?: है)?|i like (?:this|this song|this station)|like this(?: song| station)?)$/.test(normalized))return {action:'feedback',value:1};
  if(/(?:^|\s)(?:मत|नहीं|नही|don't|dont|never|not)(?:\s|$)|\bdo not\b/.test(normalized))return {action:'unknown'};
  // Provider modifiers are music requests; transport and negation remain unchanged.
  const providerName='(?:youtube music|you tube music|यूट्यूब म्यूजिक|यूट्यूब म्यूज़िक|यू ट्यूब म्यूजिक|यूट्यूब म्यूज़िक)';
  const providerPrefix=new RegExp('^'+providerName+'(?: पर| में| पे)?\\s+'),providerSuffix=new RegExp('\\s+(?:on|in|पर|में) '+providerName+'$');
  const providerMiddle=new RegExp('(?:^|\\s+)'+providerName+' (?:पर|में|पे)(?=\\s|$)');
  const withoutProvider=normalized.replace(providerPrefix,'').replace(providerSuffix,'').replace(providerMiddle,' ').replace(/\s+/g,' ').trim();
  if(withoutProvider!==normalized){const result=parseCommand(withoutProvider);if(['followupArtist','playArtist','playSong','searchSong','mood','language','play','recommend','playStation'].includes(result.action))return {...result,source:'audius',provider:'youtubeMusic'};return {action:'unknown'};}
  const catalogs=[['all','all catalogs|all catalogues|सभी कैटलॉग|सभी कैटलोग|सभी catalog|सारे कैटलॉग'],['both','both catalogs|दोनों कैटलॉग'],['audius','audius|ऑडियस|ऑडियस कैटलॉग'],['archive','internet archive|archive|इंटरनेट आर्काइव|आर्काइव'],['ccmixter','ccmixter|cc mixter|सीसीमिक्सटर|सीसी मिक्स्टर'],['commons','wikimedia commons|commons|विकिमीडिया कॉमन्स'],['artistRadio','artist radio|कलाकार रेडियो|कलाकार लाइव रेडियो']];
  for(const [provider,names]of catalogs){
   const name='(?:'+names+')';
   const rest=normalized.replace(new RegExp('^(?:(?:from|on|in) )?'+name+'(?: में से| में| से| पर| पे)?\\s+'),'')
    .replace(new RegExp('\\s+(?:from|on|in) '+name+'$'),'')
    .replace(new RegExp('(?:^|\\s+)'+name+' (?:में से|में|से|पर|पे)(?=\\s|$)'),' ').replace(/\s+/g,' ').trim();
   if(rest!==normalized){const result=parseCommand(rest);return ['followupArtist','playArtist','playSong','searchSong','mood','language','play','recommend','playStation'].includes(result.action)&&!result.provider?{...result,source:'audius',provider}:{action:'unknown'};}
  }
  const languageIntent=parseLanguageCommand(normalized);if(languageIntent)return languageIntent;
  // Collection names are source qualifiers only with a bounded preposition;
  // the song title “मेरा गीत” must stay intact.
  if(/^(?:मेरे गाने|मेरे गीत|फोन के गाने|my songs|my music)(?: चलाओ| बजाओ| चला दो)?$/.test(normalized))return {action:'mood',mood:'personal',source:'local'};
  const sources=[['local',/^(?:(?:मेरे गीत|मेरे गीतों|मेरे गानों|मेरे गाने|फोन के गानों|फोन के गाने|फ़ोन के गानों|फ़ोन के गाने|मेरी प्लेलिस्ट|my songs|my music|my playlist)(?: में से| में| से)?|मेरा गीत (?:में से|में|से)|(?:फोन|फ़ोन|ऑफलाइन|offline|local)(?: पर)?|(?:in|from) my songs)\s+/],['audius',/^(?:ऑनलाइन|online)(?: संगीत में| में| से)?\s+/],['radio',/^(?:रेडियो पर|on radio)\s+/]];
  for(const [source,pattern]of sources){if(pattern.test(normalized)){
   const rest=normalized.replace(pattern,''),intent=parseLanguageCommand(rest)||parseBareCommand(rest);
   if(['mood','language','playSong','followupArtist','playArtist','searchSong','play','recommend'].includes(intent.action))return {...intent,source};
   return intent;
  }}
  return parseBareCommand(normalized);
 }
 function parseLanguageCommand(input){
  const aliases={'हिंदी':'hi','हिन्दी':'hi',hindi:'hi','भोजपुरी':'bho',bhojpuri:'bho','पंजाबी':'pa',punjabi:'pa','उर्दू':'ur',urdu:'ur','बंगाली':'bn',bengali:'bn','मराठी':'mr',marathi:'mr','गुजराती':'gu',gujarati:'gu','तमिल':'ta',tamil:'ta','तेलुगु':'te',telugu:'te','कन्नड़':'kn',kannada:'kn','मलयालम':'ml',malayalam:'ml','अंग्रेज़ी':'en','अंग्रेजी':'en',english:'en'};
  const words=Object.keys(aliases).join('|');let s=input.replace(/^(?:अब|अभी|now)\s+/,'');
  const source=/(?:^|\s)(?:ऑनलाइन|online)(?=\s|$)/.test(s)?'audius':null;
  if(source)s=s.replace(/(?:^|\s)(?:ऑनलाइन|online)(?=\s|$)/g,' ').trim().replace(/\s+/g,' ');
  s=s.replace(new RegExp('^(?:'+words+') से (?=(?:'+words+')(?: |$))'),'')
   .replace(new RegExp('^(?:switch |change )?from (?:'+words+') to '),'')
   .replace(/^(?:play |switch to |change to )/,'');
  const match=s.match(new RegExp('^('+words+')(?: में| भाषा में| language)?(?: |$)(.*)$'));
  if(!match){if(!/(?:गाने|songs|tracks|music)(?: (?:चलाओ|बजाओ|सुनाओ))?$/.test(s))return null;let found=[];const rest=s.replace(new RegExp('(^| )('+words+')(?= |$)','g'),(_,space,word)=>{found.push(aliases[word]);return space}).trim().replace(/\s+/g,' ');if(!found.length)return null;if(new Set(found).size>1)return {action:'unknown'};const next=parseBareCommand(rest);return next.action==='playSong'?{...next,language:found[0],...(source?{source}:{})}:null;}

  const language=aliases[match[1]],rest=match[2].replace(/(?:लगाओ|लगा दो)$/,'चलाओ').replace(/\s+में (?:बदलो|बदल दो)$/,'').trim();
  const intent=rest?parseBareCommand(rest):{action:'play'};
  if(!['play','language','mood','playSong','followupArtist','playArtist','searchSong','playStation'].includes(intent.action)&&!/^(?:गाने|गाना|गीत|संगीत|songs?|music)(?: (?:now|चलाओ))?$/.test(rest)&&!['बदलो','बदल दो'].includes(rest))return null;
  if(['mood','playSong','followupArtist','playArtist','searchSong','playStation'].includes(intent.action))return {...intent,language,...(source?{source}:{} )};
  return {action:'language',language,...(source?{source}:{} )};
 }
 function parseBareCommand(input){
  let s=String(input||'').normalize('NFKC').toLowerCase().replace(/[०-९]/g,c=>String(c.charCodeAt(0)-0x0966)).replace(/[।.!?,]/g,' ').replace(/\s+/g,' ').trim().slice(0,160);
  s=s.replace(/^(कृपया|प्लीज|please)\s+/,'').replace(/\s+(please|प्लीज)$/,'');
  // Common speech-service spellings, bounded to a command suffix.
  if(/(?:^|\s)(?:मत|नहीं|नही)(?:\s|$)/.test(s)||/^(?:don't|dont|do not|never|not)\s/.test(s))return {action:'unknown'};
  s=s.replace(/(?:चला दो|चला दें|चला दीजिए|चलाएं|चलाएँ|चलाइए|चलाईए|चलाये|चलाइये|बजाओ|बजा दो|बजा दें|बजा दीजिए|बजाइए|बजाइये|बजाएं|बजाएँ|प्ले करो|प्ले कर दो|सुनाओ|सुना दो|सुनाइए|सुनाइये)$/,'चलाओ').replace(/^listen to /,'play ');
  const composite=compositeArtist(s);if(composite)return composite;
  if(/^(?:(?:इसी|इस) (?:कलाकार|गायक) के (?:और|दूसरे) (?:गाने|गीत)(?: चलाओ)?|(?:play )?(?:more songs by (?:this|the same) artist|more by (?:this|the same) artist))$/.test(s))return {action:'sameArtist'};
  if(/^(?:ऐसा ही (?:दूसरा|और)(?: गाना| गीत| स्टेशन)?(?: चलाओ)?|ऐसे (?:ही )?और (?:गाने|गीत)(?: चलाओ)?|(?:play )?(?:something similar|more like this|another like this))$/.test(s))return {action:'similar'};
  const activities=[
   ['focus',/^(?:(?:मुझे )?पढ़ाई करनी है|(?:मुझे )?काम करना है|i (?:want|need) to (?:study|focus)|help me focus)$/],
   ['calm',/^(?:(?:मुझे )?सुकून चाहिए|(?:मुझे )?आराम करना है|i (?:want|need) to relax)$/],
   ['sleep',/^(?:(?:मुझे )?सोना है|(?:मुझे )?नींद आ रही है|i (?:want|need) to sleep)$/],
   ['workout',/^(?:(?:मुझे )?कसरत करनी है|(?:मुझे )?व्यायाम करना है|i (?:am working out|want to exercise))$/],
   ['meditation',/^(?:(?:मुझे )?ध्यान लगाना है|i (?:want|need) to meditate)$/],
   ['sad',/^(?:(?:आज )?(?:मेरा )?मन उदास है|i (?:feel|am) sad)$/]
  ];
  for(const [mood,pattern]of activities)if(pattern.test(s))return {action:'mood',mood};
  const exact={pause:/^(रुको|रोकें|रोक दो|रोक दो गाना|गाना रोक दो|गाना रोकें|म्यूजिक रोकें|पॉज|पॉज़|pause|pause music|pause song|pause the music|pause playback)$/,play:/^(चलाओ|चलाएँ|चालू करो|गाना चलाओ|गीत चलाओ|गाना चलाएँ|रेडियो चलाओ|संगीत चलाओ|म्यूजिक चलाओ|कोई गाना चलाओ|गाने चलाओ|गाना प्ले|गाना चालू करो|play|resume|resume music|continue playing|play music|play song|play a song|play songs)$/,next:/^(अगला|गाना बदलो|अगला गाना|अगला स्टेशन|अगला गाना चलाओ|अगला स्टेशन चलाओ|नेक्स्ट|next|next song|play next song|skip song|next track|next station)$/,prev:/^(पिछला|पिछला गाना|पिछला स्टेशन|पिछला गाना चलाओ|पिछला स्टेशन चलाओ|previous|previous song|play previous song|previous track)$/,stop:/^(बंद करो|रेडियो बंद करो|गाना बंद करो|संगीत बंद करो|म्यूजिक बंद करो|stop|stop music|stop playback)$/,cancelTimer:/^(टाइमर बंद करो|टाइमर रद्द करो|स्लीप टाइमर बंद करो|cancel timer)$/,recommend:/^(मेरी पसंद|मेरी पसंद चलाओ|मेरे लिए रेडियो चलाओ|स्मार्ट डीजे|स्मार्ट डीजे चलाओ|smart dj|open smart dj|play smart dj|डीजे खोलो|स्मार्ट डीजे खोलो|डीजे चलाओ)$/};
  for(const [action,pattern]of Object.entries(exact))if(pattern.test(s))return {action};
  if(/^(?:आवाज़|आवाज|वॉल्यूम|साउंड) (?:बढ़ाओ|बढ़ा दो|तेज करो|ज़्यादा करो|ज्यादा करो)$|^(?:volume up|increase volume|turn volume up|turn up the volume|louder|turn it up)$/.test(s))return {action:'volume',delta:10};
  if(/^(?:आवाज़|आवाज|वॉल्यूम|साउंड) (?:कम करो|कम कर दो|घटाओ|धीमा करो)$|^(?:volume down|decrease volume|turn volume down|turn down the volume|quieter|turn it down)$/.test(s))return {action:'volume',delta:-10};
  if(/^(?:म्यूट|mute|आवाज़ बंद करो|आवाज बंद करो|mute music)$/.test(s))return {action:'mute'};
  if(/^(?:अनम्यूट|unmute|आवाज़ चालू करो|आवाज चालू करो|unmute music)$/.test(s))return {action:'unmute'};
  const volumeWords={'पच्चीस':'25','पचास':'50','पचहत्तर':'75','सौ':'100'};if(/^(?:आवाज़|आवाज|वॉल्यूम) /.test(s))s=s.replace(/ (पच्चीस|पचास|पचहत्तर|सौ)(?= |$)/,(_,word)=>' '+volumeWords[word]);
  const level=s.match(/^(?:आवाज़|आवाज|वॉल्यूम) (\d{1,3})(?: प्रतिशत| परसेंट| percent|%)?(?: करो| कर दो| रखो)$/)||s.match(/^(?:set )?volume(?: to)? (\d{1,3})(?: percent|%)?$/);
  if(level)return Number(level[1])<=100?{action:'volume',percent:Number(level[1])}:{action:'unknown'};
  if(/^(?:शफ़ल|शफल|shuffle) (?:चालू करो|ऑन|on)$/.test(s))return {action:'shuffle',enabled:true};
  if(/^(?:शफ़ल|शफल|shuffle) (?:बंद करो|ऑफ|off)$/.test(s))return {action:'shuffle',enabled:false};
  if(/^(?:यही गाना दोहराओ|इस गाने को दोहराओ|गाना रिपीट करो|repeat (?:this )?song|repeat one)$/.test(s))return {action:'repeat',mode:1};
  if(/^(?:सभी गाने दोहराओ|सभी गाने रिपीट करो|repeat all)$/.test(s))return {action:'repeat',mode:2};
  if(/^(?:रिपीट बंद करो|दोहराना बंद करो|repeat off)$/.test(s))return {action:'repeat',mode:0};
  const artist=s.match(/^(?:गायक |कलाकार )?(.+?) (?:के|की|का) (?:गाने|गीत|गाना|संगीत)(?: चलाओ)?$/)||s.match(/^(?:play )?(?:songs?|music) (?:by|of) (.+)$/)||s.match(/^(?:play )?(?:artist|singer) (.+)$/)||s.match(/^(?:गायक|कलाकार) (.+?)(?: चलाओ)?$/);
  if(artist&&artist[1].length<=80)return {action:'playArtist',artist:artist[1]};
  const words={'एक':1,'दो':2,'पांच':5,'पाँच':5,'दस':10,'पंद्रह':15,'पन्द्रह':15,'बीस':20,'तीस':30,'पैंतालीस':45,'साठ':60};
  let t=s.match(/^(\d{1,3}|एक|दो|पांच|पाँच|दस|पंद्रह|पन्द्रह|बीस|तीस|पैंतालीस|साठ) मिनट (?:का )?(?:स्लीप )?टाइमर(?: लगाओ| लगाएँ| लगाएं)?$/)||s.match(/^(?:set )?(?:sleep )?timer (\d{1,3})(?: minutes?)?$/);
  if(t){let minutes=Number(t[1])||words[t[1]];return minutes>=1&&minutes<=480?{action:'timer',minutes}:{action:'invalidTimer'}}
  for(const [word,language]of [['भोजपुरी','bho'],['हिंदी','hi'],['हिन्दी','hi'],['पंजाबी','pa'],['bhojpuri','bho'],['hindi','hi'],['punjabi','pa']])if(s===word+' गाने चलाओ'||s===word+' गाना चलाओ'||s==='play '+word+' songs')return {action:'language',language};
  const moodInput=s.replace(/^play\s+/,'').replace(/\s+चलाओ$/,'').replace(/\s+(?:गाने|गाना|गीत|संगीत|songs?|music)$/,'').trim();
  const moods={'पुराने':'retro','खुशी':'happy','पढ़ाई':'focus','एकाग्रता':'focus','उदास':'sad','रोमांस':'romantic','यात्रा':'travel','व्यायाम':'workout','सुकून':'calm','शांत संगीत':'calm','जोश':'energy','भक्ति':'devotional','भजन':'devotional','पुराने गाने':'retro','पुराने गीत':'retro','समाचार':'news','खबरें':'news'};
  for(const [name,mood]of Object.entries(moods))if(s===name||s===name+' चलाओ'||moodInput===name)return {action:'mood',mood};
  for(const [mood,name]of Object.entries(moodNames))if(s===name.toLowerCase()||moodInput===name.toLowerCase())return {action:'mood',mood};
 const englishMoods={old:'retro',calm:'calm',relax:'calm',energy:'energy',devotional:'devotional',classics:'retro',retro:'retro',news:'news'};
  for(const [name,mood]of Object.entries({...Object.fromEntries(Object.keys(moodNames).map(m=>[m,m])),...englishMoods}))if(moodInput===name)return {action:'mood',mood};
  const bareArtist=s.replace(/^play /,'').replace(/ चलाओ$/,'');
  if(bareArtist!==s&&Object.values(artistAliases).includes(artistName(bareArtist)))return {action:'playArtist',artist:bareArtist};
  const artistSongs=s.match(/^(?:play )?(.+?) songs$/);if(artistSongs&&artistSongs[1].length<=80&&Object.values(artistAliases).includes(artistName(artistSongs[1])))return {action:'playArtist',artist:artistSongs[1]};
  const collection=s.match(/^(?:play )?(.+?) (?:गाने|गीतों|songs|tracks|music)(?: चलाओ)?$/);if(collection)return {action:'playSong',query:keywordQuery(collection[1])||collection[1]};
  const englishNumbers={one:1,two:2,five:5,ten:10,fifteen:15,twenty:20,thirty:30,'forty five':45,sixty:60};
  let enTimer=s.match(/^(?:set )?(?:sleep )?timer (one|two|five|ten|fifteen|twenty|thirty|forty five|sixty)(?: minutes?)?$/);
  if(enTimer)return {action:'timer',minutes:englishNumbers[enTimer[1]]};
  let enSearch=s.match(/^(?:search|find) (song|station) (.+)$/);
  if(enSearch)return {action:enSearch[1]==='song'?'searchSong':'searchStation',query:enSearch[2]};
  let q=s.match(/^(?:गाना|गीत|song) (.+) (?:खोजो|खोजें|search)$/);if(q)return {action:'searchSong',query:q[1]};
  q=s.match(/^(?:स्टेशन|रेडियो|station) (.+) (?:खोजो|खोजें|search)$/);if(q)return {action:'searchStation',query:q[1]};
  q=s.match(/^(?:(?:लाइव )?(?:स्टेशन|रेडियो)|(?:live )?(?:station|radio)) (.+) चलाओ$/)||s.match(/^play (?:live )?(?:station|radio) (.+)$/)||s.match(/^(.+?) (?:लाइव )?(?:रेडियो|स्टेशन) चलाओ$/)||s.match(/^play (.+?) (?:live )?(?:radio|station)$/);if(q)return {action:'playStation',query:q[1]};
  q=s.match(/^(?:गाना|गीत|song) (.+) चलाओ$/)||s.match(/^(.+) (?:गाना|गीत) चलाओ$/)||s.match(/^play (?:song )?(.+)$/);if(q)return {action:'playSong',query:q[1]};
  return {action:'unknown'};
 }
 const artistAliases={"मुकेश":"mukesh","आशा भोसले":"asha bhosle","मन्ना डे":"manna dey","हेमंत कुमार":"hemant kumar","मोहित चौहान":"mohit chauhan","अभिजीत भट्टाचार्य":"abhijeet bhattacharya","सुखविंदर सिंह":"sukhwinder singh","नुसरत फतेह अली खान":"nusrat fateh ali khan","राहत फतेह अली खान":"rahat fateh ali khan","गुलाम अली":"ghulam ali","सुरेश वाडकर":"suresh wadkar","शंकर महादेवन":"shankar mahadevan","सुनिधि चौहान":"sunidhi chauhan","आतिफ असलम":"atif aslam","शान":"shaan","के के":"kk","केके":"kk","मुहम्मद रफी":"mohammed rafi","मुहम्मद रफ़ी":"mohammed rafi","मोहम्मद रफ़ी":"mohammed rafi","मोहम्मद रफी":"mohammed rafi","mohamed rafi":"mohammed rafi","mohd rafi":"mohammed rafi",'अरिजीत सिंह':'arijit singh','अरिजीत':'arijit singh','किशोर कुमार':'kishore kumar','मोहम्मद रफी':'mohammed rafi','मोहम्मद रफ़ी':'mohammed rafi','मोहम्मद रफ़ी':'mohammed rafi','मोहम्मद रफ़ी':'mohammed rafi','mohammad rafi':'mohammed rafi','mohd rafi':'mohammed rafi','लता मंगेशकर':'lata mangeshkar','कुमार सानू':'kumar sanu','उदित नारायण':'udit narayan','अलका याग्निक':'alka yagnik','सोनू निगम':'sonu nigam','श्रेया घोषाल':'shreya ghoshal','जगजीत सिंह':'jagjit singh','पवन सिंह':'pawan singh','खेसारी लाल यादव':'khesari lal yadav','मनोज तिवारी':'manoj tiwari'};
 function artistName(value){
  const norm=s=>String(s||'').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{M}\p{N}]+/gu,' ').trim().replace(/\s+/g,' ');
  const aliases=new Map(Object.entries(artistAliases).map(([key,val])=>[norm(key),val]));for(const name of Object.values(artistAliases))aliases.set(name,name);
  const pattern=[...aliases.keys()].sort((a,b)=>b.length-a.length).map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|');
  return norm(value).replace(new RegExp('(^| )('+pattern+')(?= |$)','g'),(_,space,name)=>space+aliases.get(name));
 }

 function matchesArtist(row,value){const wanted=artistName(value),actual=artistName(row?.artist);if(!wanted||!actual)return false;return wanted.split(' ').every(token=>(' '+actual+' ').includes(' '+token+' ')||actual===wanted);}
 Object.assign(artistAliases,{'रफी':'mohammed rafi','रफ़ी':'mohammed rafi','रफ़ी':'mohammed rafi','rafi':'mohammed rafi','लता':'lata mangeshkar','lata':'lata mangeshkar','किशोर':'kishore kumar','kishore':'kishore kumar','कुमार सानु':'kumar sanu','कुमार शानू':'kumar sanu','कुमार सानू':'kumar sanu','mohd rafi':'mohammed rafi'});
 function artistChoices(value){
  const entered=artistName(value),known=[...new Set(Object.values(artistAliases))];if(known.includes(entered)||entered.length<4||entered.length>80)return [];
  const normalize=s=>s.normalize('NFKC').replace(/़/g,'');
  const distance=(a,b)=>{const row=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){let previous=row[0];row[0]=i;for(let j=1;j<=b.length;j++){const old=row[j];row[j]=Math.min(row[j]+1,row[j-1]+1,previous+(a[i-1]===b[j-1]?0:1));previous=old;}}return row[b.length];};
  const input=normalize(entered),scores=new Map();
  for(const [alias,name]of [...Object.entries(artistAliases),...known.map(x=>[x,x])]){const other=normalize(alias);if(Math.abs(input.length-other.length)>2)continue;const score=distance(input,other);if(score<=(Math.min(input.length,other.length)>=8?2:1))scores.set(name,Math.min(score,scores.get(name)??99));}
  return [...scores].sort((a,b)=>a[1]-b[1]||a[0].localeCompare(b[0])).slice(0,3).map(([name])=>name);
 }
 // Search uses transparent, bounded text matching; no remote AI inference.
 const consonants={'क':'k','ख':'kh','ग':'g','घ':'gh','ङ':'n','च':'ch','छ':'chh','ज':'j','झ':'jh','ञ':'n','ट':'t','ठ':'th','ड':'d','ढ':'dh','ण':'n','त':'t','थ':'th','द':'d','ध':'dh','न':'n','प':'p','फ':'ph','ब':'b','भ':'bh','म':'m','य':'y','र':'r','ल':'l','व':'v','श':'sh','ष':'sh','स':'s','ह':'h'};
 const vowels={'अ':'a','आ':'aa','इ':'i','ई':'ii','उ':'u','ऊ':'uu','ऋ':'ri','ए':'e','ऐ':'ai','ओ':'o','औ':'au'},matras={'ा':'aa','ि':'i','ी':'ii','ु':'u','ू':'uu','ृ':'ri','े':'e','ै':'ai','ो':'o','ौ':'au'};
 const nukta={'क':'q','ख':'kh','ग':'g','ज':'z','ड':'r','ढ':'rh','फ':'f','य':'y'};
 function romanize(value){
  return String(value||'').normalize('NFKC').toLowerCase().replace(/[\u0900-\u097f]+/g,word=>{
   let out='';for(let i=0;i<word.length;i++){
    const c=word[i];if(consonants[c]){let sound=consonants[c];if(word[i+1]==='़'){sound=nukta[c]||sound;i++;}out+=sound;
     if(word[i+1]==='्'){i++;continue;}if(matras[word[i+1]])out+=matras[word[++i]];else if(i<word.length-1)out+='a';
    }else if(vowels[c])out+=vowels[c];else if(c==='ं'||c==='ँ')out+='n';else if(c==='ः')out+='h';else if(/[०-९]/.test(c))out+=String(c.charCodeAt(0)-0x0966);else if(c==='।'||c==='॥')out+=' ';else if(c!=='़'&&c!=='्')out+=c;
   }return out;
  }).replace(/[^\p{L}\p{M}\p{N}]+/gu,' ').trim().replace(/\s+/g,' ');
 }
 function searchKey(value){return romanize(value).replace(/aa/g,'a').replace(/ee|ii/g,'i').replace(/oo|uu/g,'u').replace(/w/g,'v').replace(/ph/g,'f');}
 function devanagari(value,longEnding=false){
  const cs={chh:'छ',kh:'ख',gh:'घ',ch:'च',jh:'झ',th:'थ',dh:'ध',ph:'फ',bh:'भ',sh:'श',ng:'ं',ny:'ञ',k:'क',g:'ग',j:'ज',t:'त',d:'द',n:'न',p:'प',f:'फ़',b:'ब',m:'म',y:'य',r:'र',l:'ल',v:'व',w:'व',s:'स',h:'ह',q:'क',z:'ज़'};
  const vs={aa:['आ','ा'],ee:['ई','ी'],ii:['ई','ी'],oo:['ऊ','ू'],uu:['ऊ','ू'],ai:['ऐ','ै'],au:['औ','ौ'],a:['अ',''],i:['इ','ि'],u:['उ','ु'],e:['ए','े'],o:['ओ','ो']};
  return String(value||'').toLowerCase().replace(/[a-z]+/g,word=>{let out='',i=0;while(i<word.length){let v=Object.keys(vs).find(k=>word.startsWith(k,i));if(v){out+=vs[v][0];i+=v.length;continue;}let c=Object.keys(cs).find(k=>word.startsWith(k,i));if(!c){out+=word[i++];continue;}out+=cs[c];i+=c.length;v=Object.keys(vs).find(k=>word.startsWith(k,i));if(v){i+=v.length;out+=i===word.length&&v==='a'?'ा':longEnding&&i===word.length&&v==='i'?'ी':longEnding&&i===word.length&&v==='u'?'ू':vs[v][1];}else if(i<word.length)out+='्';}return out;});
 }
 function editDistance(a,b){if(Math.abs(a.length-b.length)>2)return 3;let prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){let row=[i];for(let j=1;j<=b.length;j++)row[j]=Math.min(row[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));prev=row;}return prev[b.length];}
 function titleKey(value){return searchKey(value).split(' ').filter(w=>!['hindi','official','audio','video','mp3'].includes(w)).join(' ');}
 function searchMatch(title,query){
  const a=titleKey(title),b=titleKey(query);if(!a||!b)return {level:0,score:0};if(a===b)return {level:2,score:1};
  const actual=a.split(' '),wanted=b.split(' ');if(wanted.length>12)return {level:0,score:0};
  const used=new Set();let errors=0;for(const word of wanted){let best=-1,cost=99;for(let i=0;i<actual.length;i++){if(used.has(i))continue;const d=word===actual[i]?0:Math.max(word.length,actual[i].length)>=4&&Math.min(word.length,actual[i].length)>=3?editDistance(word,actual[i]):99;if(d<cost){cost=d;best=i;}}
   if(best<0||cost>1)return {level:0,score:0};used.add(best);errors+=cost;
  }
  if(errors>1)return {level:0,score:0};return {level:1,score:Math.max(.5,.93-errors*.12-Math.abs(actual.length-wanted.length)*.04)};
 }
 function rankSearch(rows,query){return rows.filter(s=>s.kind!=='artistRadio').map(s=>({...s,searchMatch:searchMatch(s.name,query)})).filter(s=>s.searchMatch.level).sort((a,b)=>b.searchMatch.score-a.searchMatch.score);}
 function autoSearch(rows,query){
  const strong=rankSearch(rows,query).filter(s=>s.searchMatch.level===2);if(!strong.length)return null;
  const identities=new Set(strong.map(s=>titleKey(s.name)+'|'+(searchKey(artistName(s.artist))||'missing:'+(s.url||s.id))));return identities.size===1?strong[0]:null;
 }
 function searchVariants(query){
  const raw=String(query||'').trim().slice(0,150),roman=romanize(raw),variants=[raw];
  if(/[\u0900-\u097f]/.test(raw)){const readable=roman.replace(/ii/g,'ee').replace(/uu/g,'oo');variants.push(readable.replace(/aa/g,'a'),readable);}else if(/^[a-z\s]+$/i.test(raw))variants.push(devanagari(raw),devanagari(raw,true));
  const words=roman.split(' ');if(words.length>=2)variants.push(words.slice(0,-1).join(' '));else if(/^[a-z]{5,}$/i.test(raw))variants.push(raw.slice(0,-1));
  return [...new Set(variants.filter(Boolean))].slice(0,4);
 }

 // Command searches match meaningful words across title, artist and supplied tags.
 // Language/access rules are still applied by each catalog adapter.
 const keywordAliases={बॉलीवुड:'bollywood',बालीवुड:'bollywood',बॉलीवूड:'bollywood',bollywod:'bollywood',bollywood:'bollywood',फिल्मी:'bollywood',फ़िल्मी:'bollywood',फिल्म:'bollywood',फ़िल्म:'bollywood',filmi:'bollywood',filmy:'bollywood',films:'bollywood',film:'bollywood',movies:'bollywood',movie:'bollywood',पुराने:'retro',पुराना:'retro',पुरानी:'retro',old:'retro',oldies:'retro',रोमांटिक:'romantic',रोमांस:'romantic',भजन:'bhajan',भक्ति:'devotional',डांस:'dance',पार्टी:'party',ग़ज़ल:'ghazal',गजल:'ghazal',ग़ज़लें:'ghazal',gazal:'ghazal',गजलें:'ghazal',कव्वाली:'qawwali',सूफी:'sufi',सुफी:'sufi'};
 const keywordNoise=new Set(('play playing song songs music track tracks audio video online please some a an the of in on for by and with to me my now official hindi hin hi भोजपुरी bhojpuri bho english en हिंदी हिन्दी गाना गाने गीत गीतों संगीत म्यूजिक ऑनलाइन चलाओ बजाओ सुनाओ मुझे मेरा मेरी मेरे कोई कुछ अच्छे अच्छा वाली वाले वाला के की का में से पर और भी ही यह ये एक है हैं करो दीजिए सुनना सुनाओ').split(' '));
 function keywordWords(value,limit=12){return [...new Set((String(value||'').normalize('NFKC').toLowerCase().match(/[\p{L}\p{M}\p{N}]+/gu)||[]).filter(w=>!keywordNoise.has(w)&&!commandLanguages[w]).map(w=>keywordAliases[w]||w))].slice(0,limit);}
 function keywordQuery(value){return keywordWords(value).join(' ');}
 function relatedScore(row,query){
  if(!row||!row.kind||row.kind==='artistRadio')return 0;
  const title=searchMatch(row.name,query);if(title.level===2)return 100;if(title.level===1)return 70;
  const words=keywordWords(query).map(searchKey).filter(w=>w.length>=3);if(!words.length)return 0;
  const actual=new Set(keywordWords([row.name,row.artist,row.tags,row.genre,row.mood,row.album].filter(Boolean).join(' '),160).map(searchKey));
  const matched=words.filter(w=>actual.has(w)).length;return matched?20+40*matched/words.length:0;
 }
 function relatedRank(rows,query){return rows.map((row,i)=>({row,i,score:relatedScore(row,query)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.i-b.i).map(x=>({...x.row,relatedScore:x.score,searchMatch:searchMatch(x.row.name,query)}));}
 function relatedVariants(query){
  const q=keywordQuery(query)||String(query).trim(),words=keywordWords(q),variants=[q];
  if(q==='bollywood')variants.push('बॉलीवुड','filmi','film');
  else {variants.push(...searchVariants(q).slice(1,3));variants.push(...words.sort((a,b)=>b.length-a.length));}
  return [...new Set(variants.filter(Boolean))].slice(0,6);
 }

 return {keywordWords,keywordQuery,relatedScore,relatedRank,relatedVariants,recommend,parseCommand,moodNames,matchesMood,radioQueries,artistName,matchesArtist,matchesFilters,artistChoices,romanize,searchKey,devanagari,searchMatch,rankSearch,autoSearch,searchVariants};
});
