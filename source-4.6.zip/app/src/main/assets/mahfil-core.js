'use strict';
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.MahfilCore=factory();})(typeof window!=='undefined'?window:this,function(){
 const defaults=['bollywood','retro','ghazal','poetry','naat'];
 const text=(v,max=60)=>typeof v==='string'?v.replace(/[\u0000-\u001f\u007f]/g,' ').trim().slice(0,max):'';
 function moods(v,C){return [...new Set(Array.isArray(v)?v:[])].filter(k=>Object.hasOwn(C.groups,k));}
 function clean(v,C){
  v=v&&typeof v==='object'&&!Array.isArray(v)?v:{};
  const used=new Set(),id=(prefix,key,i)=>{let s=text(key,90);if(!s||!/^[\w-]+$/.test(s)||used.has(s)){s=prefix+'-'+i;while(used.has(s))s+='-copy';}used.add(s);return s;};
  const mixes=(Array.isArray(v.mixes)?v.mixes:[]).slice(0,20).filter(x=>x&&text(x.name)&&moods(x.moods,C).length).map((x,i)=>({id:id('mix',x.id,i),name:text(x.name),moods:moods(x.moods,C),language:['hindi','bhojpuri','urdu','english'].includes(x.language)?x.language:''}));
  const collections=(Array.isArray(v.collections)?v.collections:[]).slice(0,20).filter(x=>x&&text(x.name)).map((x,i)=>({id:id('collection',x.id,i),name:text(x.name),stations:C.unique(Array.isArray(x.stations)?x.stations.slice(0,500):[])}));
  return {quick:moods(v.quick,C).slice(0,5).length?moods(v.quick,C).slice(0,5):defaults.slice(),mixes,collections};
 }
 function parseBackup(raw,C){
  if(typeof raw!=='string'||raw.length>2000000)throw Error('size');
  const v=JSON.parse(raw);if(!v||v.app!=='com.zameer.radio'||v.format!==1||!v.mahfil||!Array.isArray(v.favorites))throw Error('format');
  return {mahfil:clean(v.mahfil,C),favorites:C.unique(v.favorites.slice(0,500))};
 }
 function backup(state,favorites,C){return JSON.stringify({app:'com.zameer.radio',format:1,createdAt:new Date().toISOString(),mahfil:clean(state,C),favorites:C.unique(favorites).slice(0,500)},null,2);}
 function merge(a,b,C){
  a=clean(a,C);b=clean(b,C);
  const mixes=a.mixes.slice(),collections=a.collections.slice();
  for(const x of b.mixes)if(!mixes.some(y=>y.name===x.name&&y.language===x.language&&JSON.stringify(y.moods)===JSON.stringify(x.moods)))mixes.push(x);
  for(const x of b.collections){const same=collections.find(y=>y.name===x.name);if(same)same.stations=C.unique([...same.stations,...x.stations]).slice(0,500);else collections.push(x);}
  return clean({quick:b.quick,mixes,collections},C);
 }
 function mixRows(mix,rows,C,P,favorites=[]){
  let found=[];for(const mood of moods(mix.moods,C)){
   const request=C.askRequest({moods:[mood],languages:mix.language?[mix.language]:[],strictMood:true});
   const result=C.discover(rows,request);
   if(!result.generalFallback)found.push(...result.rows);
   // Scheduled mixed programmes remain explicit manual choices, not mood-mix autoplay.
  }
  return C.rankFavorites(C.unique(found),{favorites}).slice(0,500);
 }
 return {defaults,clean,parseBackup,backup,merge,mixRows};
});
