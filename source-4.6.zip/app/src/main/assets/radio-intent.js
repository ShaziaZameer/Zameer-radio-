'use strict';
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.RadioIntent=api;})(globalThis,()=>{
 // Small, offline example-trained TF-IDF classifier. Scores are similarities, not probabilities.
 // Explicit commands, exclusions, artists and languages are resolved by RadioCore first.
 const examples={
  naat:["नबी की शान में कलाम सुनाओ","नबी की तारीफ में कुछ सुनना है","रसूल की तारीफ वाला कलाम","praise of the prophet recitations","nabi ki shaan mein kalaam sunao"],
  poetry:["शेर और अशआर की महफिल सुनाओ","अल्फाज की महफिल सुननी है","शायरों के कलाम सुनाओ","spoken verses and poetic recitations","shairon ke kalaam sunao"],
  calm:['बहुत थक गया हूँ आराम करना है','दिन भर की थकावट दूर करनी है','मन को चैन मिले ऐसा कुछ','तनाव दूर करने के लिए कुछ','दिल को तसल्ली देने वाला संगीत','need to unwind after a long day','help me wind down and take it easy','something peaceful to clear my head','bahut thak gaya hun aaram karna hai','dimag ko aaram dene wala kuch'],
  romantic:['प्यार भरी शाम साथ बितानी है','अपने साथी के साथ प्यार भरा समय','दो दिलों को जोड़ने वाली धुन','a candlelight dinner with my partner','set the mood for a date with my partner','a tender evening together','partner ke saath pyar bhari shaam'],
  energy:['मूड उठाने वाला धमाल चाहिए','दोस्तों के साथ झूमने का मन है','नाचने का मन कर रहा है','पसीना बहाने का वक्त है','get me moving and pumped up','something to get us dancing','need a boost for my exercise session','doston ke saath jhoomne ka mann hai'],
  devotional:['भगवान का नाम लेते हुए दिन शुरू करना है','आराधना के लिए धुन','ईश्वर की याद में कुछ सुनना है','music for worship and prayer','ishwar ki yaad mein kuch sunna hai'],
  retro:['बचपन की याद दिलाने वाले नगमे','बीते दिनों की यादें ताजा करनी हैं','गुजरे जमाने के नगमे','take me back to the good old days','songs that remind me of my childhood','bachpan ki yaad dilane wale nagme'],
  news:['दुनिया में क्या चल रहा है सुनाओ','देश विदेश की खबरें जाननी हैं','आज की घटनाएं सुननी हैं','tell me what is happening in the world','catch me up on current events','desh duniya ki khabrein sunao']
 };
 const omit=new Set('a an the to for of in on me my i is am are be and with something some music radio songs song please play listen put need want can could you मुझे कुछ कोई वाले वाला वाली में की के का है हैं हूँ हूं मैं सुनाओ चलाओ गाने संगीत रेडियो चाहिए करना लिए से और को बहुत today'.split(' '));
 const words=value=>String(value||'').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{M}\p{N}\s]/gu,' ').split(/\s+/u).filter(w=>w&&!omit.has(w));
 function features(value){const out=new Map();for(const w of words(value)){out.set('w:'+w,1);const chars=Array.from('^'+w+'$');for(let i=0;i<chars.length-2;i++)out.set('c:'+chars.slice(i,i+3).join(''),.22);}return out;}
 const docs=Object.entries(examples).flatMap(([mood,rows])=>rows.map(text=>({mood,text,features:features(text)}))),df=new Map();
 for(const d of docs)for(const key of d.features.keys())df.set(key,(df.get(key)||0)+1);
 function vector(text){const v=features(text);let sum=0;for(const [key,weight]of v){const x=weight*(1+Math.log((docs.length+1)/(1+(df.get(key)||0))));v.set(key,x);sum+=x*x;}sum=Math.sqrt(sum)||1;for(const [key,x]of v)v.set(key,x/sum);return v;}
 for(const d of docs)d.vector=vector(d.text);
 function infer(text){const v=vector(text),best=new Map();if(words(text).length<2)return null;for(const d of docs){let score=0;for(const [key,x]of v)score+=x*(d.vector.get(key)||0);if(score>(best.get(d.mood)?.score||0))best.set(d.mood,{mood:d.mood,score});}const ranked=[...best.values()].sort((a,b)=>b.score-a.score),first=ranked[0];if(!first||first.score<.47||first.score-(ranked[1]?.score||0)<.1)return null;return {...first,method:'offline-example-tfidf'};}
 return {infer};
});
