'use strict';
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.RadioSession=factory();})(typeof window!=='undefined'?window:this,function(){
 function countdown(end,now=Date.now()){
  const seconds=Math.max(0,Math.ceil((Number(end)-now)/1000));const pad=n=>String(n).padStart(2,'0');
  return {seconds,text:seconds>=3600?`${pad(Math.floor(seconds/3600))}:${pad(Math.floor(seconds/60)%60)}:${pad(seconds%60)}`:`${pad(Math.floor(seconds/60))}:${pad(seconds%60)}`};
 }
 function shouldWelcome(native,storage){try{if(native?.consumeWelcome)return !!native.consumeWelcome();if(storage.getItem('zrWelcomeSession'))return false;storage.setItem('zrWelcomeSession','1');return true;}catch(_){return false;}}
 return {countdown,shouldWelcome};
});
