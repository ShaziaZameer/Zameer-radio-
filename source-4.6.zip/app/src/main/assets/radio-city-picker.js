'use strict';
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./radio-near.js'));else root.RadioCityPicker=factory(root.RadioNear);})(typeof window!=='undefined'?window:this,function(N){
 const major=[['IN','Gorakhpur'],['IN','Lucknow'],['IN','Varanasi'],['IN','Prayagraj'],['IN','Ayodhya'],['IN','Basti'],['IN','Kanpur'],['IN','Agra'],['IN','Bareilly'],['IN','Meerut'],['IN','Noida'],['IN','Ghaziabad'],['IN','Delhi'],['IN','Mumbai'],['IN','Kolkata'],['IN','Chennai'],['IN','Bengaluru'],['IN','Hyderabad'],['IN','Pune'],['IN','Jaipur'],['IN','Ahmedabad'],['IN','Surat'],['IN','Bhopal'],['IN','Indore'],['IN','Patna'],['IN','Ranchi'],['IN','Raipur'],['IN','Bhubaneswar'],['IN','Chandigarh'],['IN','Dehradun'],['IN','Shimla'],['IN','Srinagar'],['IN','Jammu'],['IN','Guwahati'],['IN','Thiruvananthapuram'],['IN','Kochi'],['IN','Nagpur'],['PK','Lahore'],['PK','Karachi'],['NP','Kathmandu'],['GB','London'],['GB','Leeds'],['GB','Sheffield'],['AU','Sydney'],['CA','Toronto'],['AE','Dubai']];
 const extra={'Basti':['बस्ती'],'Ayodhya':['अयोध्या','Faizabad','फैजाबाद'],'Prayagraj':['प्रयागराज','इलाहाबाद','Allahabad'],'Bengaluru':['बेंगलुरु','बंगलुरु'],'Lucknow':['लखनऊ'],'Gorakhpur':['गोरखपुर']};
 const norm=v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^\p{L}\p{M}\p{N}]+/gu,' ').trim();
 function create(cities){
  const byId=new Map(cities.map(c=>[c.id,c])),main=major.map(([code,name])=>cities.find(c=>c.country===code&&c.name===name)).filter(Boolean),mainIds=new Set(main.map(c=>c.id));
  const index=cities.map(c=>({city:c,names:[c.name,...c.aliases,...(extra[c.name]||[])].map(norm),region:norm(c.region),country:norm(c.country)}));
  function choices(query='',selected='',limit=40){
   const q=norm(query);if(!q){const rows=[...main];if(selected&&byId.has(selected)&&!mainIds.has(selected))rows.push(byId.get(selected));return {rows,total:rows.length,search:false};}
   const terms=q.split(' '),hits=[];
   for(const entry of index){const exact=entry.names.includes(q),prefix=entry.names.some(n=>n.startsWith(q)),hay=[...entry.names,entry.region,entry.country].join(' ');if(!terms.every(t=>hay.includes(t)))continue;hits.push({city:entry.city,score:(exact?100:prefix?50:0)+(entry.city.country==='IN'?10:0)+(mainIds.has(entry.city.id)?5:0)});}
   hits.sort((a,b)=>b.score-a.score||a.city.name.localeCompare(b.city.name));return {rows:hits.slice(0,limit).map(x=>x.city),total:hits.length,search:true};
  }
  return {choices,mainCount:main.length};
 }
 return {create};
});
