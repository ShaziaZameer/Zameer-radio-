'use strict';
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.RadioDirectory=api;})(globalThis,()=>{
 // Share identical in-flight lookups. A slow mirror must not delay usable results.
 function create(request,core,{readyMs=4500,ttl=300000,concurrency=4}={}){
  const cache=new Map(),pending=new Map();
  async function get(params){const key=JSON.stringify(params),old=cache.get(key);if(old&&Date.now()-old.at<ttl)return old.rows;if(pending.has(key))return pending.get(key);const job=Promise.resolve().then(()=>request('/json/stations/search',params)).then(rows=>{if(!Array.isArray(rows))throw Error('directory');cache.set(key,{at:Date.now(),rows});if(cache.size>240)cache.delete(cache.keys().next().value);return rows;}).finally(()=>pending.delete(key));pending.set(key,job);return job;}
  function search(options,{onBatch=()=>{},isActive=()=>true}={}){
   const plan=core.searchPlan(options);let rows=[],cursor=0,success=0,failures=0,complete=false,done=true,resolveReady;
   const first=new Promise(resolve=>resolveReady=resolve),snapshot=()=>({rows:core.unique(rows),complete,done:complete&&done&&failures===0,partial:failures>0,failed:success===0&&failures>0});
   const timer=setTimeout(()=>resolveReady(snapshot()),readyMs);
   async function worker(){while(cursor<plan.length&&isActive()){const params=plan[cursor++];try{const part=await get(params);success++;rows.push(...part);if(part.length>=Number(params.limit))done=false;onBatch(snapshot());}catch(_){failures++;done=false;}}}
   const finished=Promise.all(Array.from({length:Math.min(concurrency,plan.length)},worker)).then(()=>{complete=true;clearTimeout(timer);const value=snapshot();onBatch(value);resolveReady(value);return value;});
   return {first,finished};
  }
  return {search};
 }
 return {create};
});
