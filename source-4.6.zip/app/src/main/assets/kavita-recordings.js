'use strict';
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./radio-core.js'));else root.KavitaRecordings=factory(root.RadioCore);})(typeof window!=='undefined'?window:this,function(C){
 // Selected episode enclosures published in the broadcaster's public podcast feed.
 // Audio remains on the publisher's servers; these are finite recordings, not stations.
 const feed='https://feeds.transistor.fm/pratidin-ek-kavita';
 const source='https://pratidinekkavita.transistor.fm/';
 const selected=[
  ['d6a77b1b','cc006d3d','हवा जब आएगी','चंपा वैद','Hawa Jab Aayegi | Champa Vaid',101],
  ['bd86d108','05386ff4','लहरों का गीत','सुमित्रानंदन पंत','Lehron Ka Geet | Sumitranandan Pant',137],
  ['934b11e7','729fae23','प्रेम समंदर','पल्लवी विनोद','Prem Samandar | Pallavi Vinod',118],
  ['1ec65f56','515a8fdf','गाँव-देहात की बेटियाँ','नीरा परमार','Gaon Dehaat Ki Betiyaan | Neera Parmar',96],
  ['4247f69f','f96dca74','बच्चा','इंदु जैन','Bachcha | Indu Jain',82],
  ['5ffcef1b','3f3235ce','तबला','विवेक निराला','Tabla | Vivek Nirala',130]
 ];
 const episodes=selected.map(([episode,file,name,artist,english,duration])=>Object.freeze({id:'kavita-'+episode,name,artist,english,duration,url:'https://media.transistor.fm/'+episode+'/'+file+'.mp3',sourceUrl:'https://share.transistor.fm/s/'+episode,kind:'podcast',assignedMood:'kavita',language:'hindi',tags:'hindi poetry kavita spoken word recorded',publisher:'नई धारा रेडियो',publisherEn:'Nayi Dhara Radio',series:'प्रतिदिन एक कविता',seriesEn:'Pratidin Ek Kavita'}));
 function select(request={}){if(!request.moods?.includes('kavita')||request.excludedMoods?.includes('kavita')||request.languages?.length&&!request.languages.includes('hindi'))return [];const terms=C.norm(request.query||'').split(' ').filter(Boolean);return episodes.filter(e=>terms.every(t=>C.norm(e.name+' '+e.artist+' '+e.english).includes(t)));}
 function queue(rows=episodes){const ids=new Set(rows.map(e=>e.id));return episodes.filter(e=>ids.has(e.id)).map(e=>({...e}));}
 function time(seconds){const n=Math.max(0,Math.floor(Number(seconds)||0));return Math.floor(n/60)+':'+String(n%60).padStart(2,'0');}
 return {episodes:Object.freeze(episodes),select,queue,time,feed,source};
});
