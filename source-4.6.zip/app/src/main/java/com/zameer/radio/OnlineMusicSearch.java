package com.zameer.radio;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Bounded public catalog reads usable without an Activity or WebView. */
final class OnlineMusicSearch {
    interface Fetcher { JSONObject get(String url) throws Exception; }
    static final class Track {
        final String id,title,artist,url,kind,language,license,share,tags;
        Track(String id,String title,String artist,String url,String kind,String language,String license,String share){this(id,title,artist,url,kind,language,license,share,"");}
        Track(String id,String title,String artist,String url,String kind,String language,String license,String share,String tags){this.tags=tags;this.id=id;this.title=title;this.artist=artist;this.url=url;this.kind=kind;this.language=language;this.license=license;this.share=share;}
    }
    static final class NeedsChoice extends IOException {NeedsChoice(){super("Open the app to choose a close or ambiguous song match");}}
    private final Fetcher fetcher;
    OnlineMusicSearch(Fetcher fetcher){this.fetcher=fetcher;}
    static String encode(String value){try{return URLEncoder.encode(value,"UTF-8").replace("+","%20");}catch(Exception e){throw new IllegalArgumentException(e);}}
    static String multi(Object value){if(value instanceof JSONArray){StringBuilder s=new StringBuilder();JSONArray a=(JSONArray)value;for(int i=0;i<Math.min(a.length(),30);i++)s.append(multi(a.opt(i))).append(' ');return s.toString().trim();}return value instanceof String?((String)value).substring(0,Math.min(600,((String)value).length())):"";}
    static boolean truth(JSONObject o,String key){return "true".equalsIgnoreCase(o.optString(key));}
    static String license(Object value){
        if(value instanceof JSONArray){JSONArray a=(JSONArray)value;for(int i=0;i<a.length();i++){String l=license(a.opt(i));if(!l.isEmpty())return l;}return "";}
        try{URI u=new URI(multi(value));String p=u.getPath();if(!"creativecommons.org".equals(u.getHost())||u.getUserInfo()!=null||u.getPort()!=-1||!("https".equals(u.getScheme())||"http".equals(u.getScheme())))return "";
            return p.matches("/(?:publicdomain/zero/1\\.0|licenses/(?:by|by-sa)/(?:[1-4]\\.0|2\\.5))/?")?"https://creativecommons.org"+p:"";
        }catch(Exception e){return "";}
    }
    static JSONObject read(String url,long deadline) throws Exception {
        URI uri=new URI(url);
        boolean radio=java.util.Arrays.asList("de1.api.radio-browser.info","nl1.api.radio-browser.info","at1.api.radio-browser.info").contains(uri.getHost())&&"/json/stations/search".equals(uri.getPath());
        boolean allowed=radio||CatalogUrlPolicy.allows(url)||"api.audius.co".equals(uri.getHost())&&"/v1/tracks/search".equals(uri.getPath()) || "archive.org".equals(uri.getHost())&&(uri.getPath().equals("/advancedsearch.php")||uri.getPath().matches("/metadata/[a-zA-Z0-9][a-zA-Z0-9_.-]{0,199}"));
        if(!allowed||!"https".equals(uri.getScheme())||uri.getUserInfo()!=null||uri.getPort()!=-1||uri.getFragment()!=null)throw new IOException("Invalid catalog endpoint");
        long remaining=deadline-System.nanoTime()/1_000_000;if(remaining<=0||Thread.currentThread().isInterrupted())throw new IOException("Search cancelled or timed out");
        HttpURLConnection c=(HttpURLConnection)uri.toURL().openConnection();
        try{c.setInstanceFollowRedirects(false);c.setUseCaches(false);c.setConnectTimeout((int)Math.min(7000,remaining));c.setReadTimeout((int)Math.min(8000,remaining));c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","ZameerRadio/3.23 (Android music player)");
            if(c.getResponseCode()!=200)throw new IOException("Catalog unavailable");
            try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>2_000_000||System.nanoTime()/1_000_000>deadline||Thread.currentThread().isInterrupted())throw new IOException("Search limit reached");out.write(b,0,n);}
                String body=new String(out.toByteArray(),StandardCharsets.UTF_8);
                return radio?new JSONObject().put("stations",new JSONArray(body)):"ccmixter.org".equals(uri.getHost())?new JSONObject().put("tracks",new JSONArray(body)):new JSONObject(body);
            }
        }finally{c.disconnect();}
    }
    List<Track> search(MusicRequest request,String provider) throws Exception {
        if(Thread.currentThread().isInterrupted())throw new InterruptedException("Search cancelled");
        if(request.station)provider="artistRadio";else if(!request.provider.isEmpty())provider=request.provider;
        boolean radio=request.filters.isEmpty()&&("artistRadio".equals(provider)||"all".equals(provider)&&!request.artist.isEmpty());
        if(!request.filters.isEmpty()&&"artistRadio".equals(provider))return new ArrayList<>();
        if(radio&&!request.titleOnly&&request.filters.isEmpty()){List<Track> cached=artistRadioTracks(ArtistRadioStations.rows(),ArtistNames.canonical(request.artist.isEmpty()?AssistantSearch.key(request.query):request.artist),request.language);if(!cached.isEmpty())return cached;}
        List<String> sources=new ArrayList<>();
        if("all".equals(provider)||"both".equals(provider)){sources.add("audius");sources.add("archive");if("all".equals(provider)){sources.add("ccmixter");sources.add("commons");}if(radio)sources.add("artistRadio");}
        else if(java.util.Arrays.asList("audius","archive","ccmixter","commons","artistRadio").contains(provider))sources.add(provider);
        else throw new IOException("Unknown catalog");
        java.util.concurrent.ExecutorService pool=java.util.concurrent.Executors.newFixedThreadPool(sources.size());
        java.util.concurrent.CompletionService<List<Track>> complete=new java.util.concurrent.ExecutorCompletionService<>(pool);
        List<java.util.concurrent.Future<List<Track>>> jobs=new ArrayList<>();Exception failure=null;int successful=0;boolean needsChoice=false;
        try{
            for(String source:sources)jobs.add(complete.submit(()->{
                if(Thread.currentThread().isInterrupted())throw new InterruptedException();
                boolean suggestion=false;
                List<String> variants=request.titleOnly?KeywordSearch.variants(request.query):java.util.Collections.singletonList(request.query);
                for(String variant:variants){
                    if(Thread.currentThread().isInterrupted())throw new InterruptedException();
                    MusicRequest probe=request.withQuery(variant);List<Track> rows;
                    switch(source){case "audius":rows=audius(probe);break;case "archive":rows=archive(probe,request);break;case "ccmixter":rows=mixter(probe);break;case "commons":rows=commons(probe);break;default:return request.titleOnly||!request.filters.isEmpty()?new ArrayList<>():artistRadio(request);}
                    List<Track> candidates=candidates(rows,request),selected=select(candidates,request);
                    if(!selected.isEmpty())return selected;
                    suggestion|=!candidates.isEmpty();
                }
                if(suggestion)throw new NeedsChoice();return new ArrayList<>();
            }));
            long deadline=System.nanoTime()+java.util.concurrent.TimeUnit.SECONDS.toNanos(35);
            for(int i=0;i<sources.size();i++){
                long remaining=deadline-System.nanoTime();if(remaining<=0)throw new IOException("Search timed out");
                java.util.concurrent.Future<List<Track>> job=complete.poll(remaining,java.util.concurrent.TimeUnit.NANOSECONDS);if(job==null)throw new IOException("Search timed out");
                try{List<Track> result=job.get();successful++;if(!result.isEmpty())return result;}catch(java.util.concurrent.ExecutionException e){failure=e;if(e.getCause() instanceof NeedsChoice)needsChoice=true;}
            }
            if(needsChoice)throw new NeedsChoice();if(successful==0&&failure!=null)throw failure;return new ArrayList<>();
        }finally{for(java.util.concurrent.Future<?> job:jobs)job.cancel(true);pool.shutdownNow();}
    }
    static List<Track> candidates(List<Track> tracks,MusicRequest request){
        List<Track> found=new ArrayList<>();for(Track track:filterArtist(tracks,request.artist))if(ArtistCommand.matches(track.title,track.tags,track.kind,request.filters)&&(!request.titleOnly||!"artistRadio".equals(track.kind)&&KeywordSearch.score(track.title,track.artist,track.tags,track.kind,request.query)>0))found.add(track);return found;
    }
    static List<Track> select(List<Track> tracks,MusicRequest request){
        tracks=candidates(tracks,request);if(!request.titleOnly)return tracks;
        tracks.sort((a,b)->Integer.compare(KeywordSearch.score(b.title,b.artist,b.tags,b.kind,request.query),KeywordSearch.score(a.title,a.artist,a.tags,a.kind,request.query)));
        return tracks;
    }
    private List<Track> artistRadio(MusicRequest request) throws Exception {
        String wanted=ArtistNames.canonical(request.artist.isEmpty()?AssistantSearch.key(request.query):request.artist);
        if(wanted.isEmpty())return new ArrayList<>();
        List<Track> verified=artistRadioTracks(ArtistRadioStations.rows(),wanted,request.language);
        if(!verified.isEmpty())return verified;
        List<String> hosts=new ArrayList<>(java.util.Arrays.asList("de1.api.radio-browser.info","nl1.api.radio-browser.info","at1.api.radio-browser.info"));java.util.Collections.shuffle(hosts);Exception failure=null;
        for(String host:hosts){
            if(Thread.currentThread().isInterrupted())throw new IOException("Search cancelled");
            try{
                JSONObject body=fetcher.get("https://"+host+"/json/stations/search?name="+encode(wanted)+"&hidebroken=true&order=votes&reverse=true&limit=50");
                JSONArray rows=body.optJSONArray("stations");if(rows==null)throw new IOException("Radio directory response invalid");
                return artistRadioTracks(rows,wanted,request.language);
            }catch(Exception e){failure=e;}
        }
        throw failure==null?new IOException("Radio directory unavailable"):failure;
    }
    static List<Track> artistRadioTracks(JSONArray rows,String wanted,String language){
        List<Track> result=new ArrayList<>();Set<String> seen=new HashSet<>();
        for(int i=0;i<Math.min(rows.length(),50);i++)try{
            JSONObject row=rows.optJSONObject(i);if(row==null)continue;
            String title=row.optString("name"),id=row.optString("stationuuid"),url=row.optString("url_resolved",row.optString("url"));
            URI uri=new URI(url);
            String artist=row.optString("search_name",title);
            if(id.isEmpty()||row.optInt("lastcheckok")!=1||!"https".equals(uri.getScheme())||uri.getHost()==null||uri.getUserInfo()!=null||!ArtistNames.matches(artist,wanted)||!MusicRequest.matchesLanguage(title,multi(row.opt("tags")),multi(row.opt("language")),language)||!seen.add(url))continue;
            String share=row.optString("homepage");try{URI home=new URI(share);if(!"https".equals(home.getScheme())||home.getHost()==null||home.getUserInfo()!=null)share="";}catch(Exception ignored){share="";}
            result.add(new Track("artistRadio:"+id,title,artist,url,"artistRadio",language,"",share));
        }catch(Exception ignored){}
        return result;
    }
    static List<Track> filterArtist(List<Track> tracks,String artist){if(artist.isEmpty())return tracks;List<Track> found=new ArrayList<>();for(Track track:tracks)if(ArtistNames.matches(track.artist,artist))found.add(track);return found;}
    private List<Track> audius(MusicRequest r) throws Exception {
        JSONObject result=fetcher.get("https://api.audius.co/v1/tracks/search?query="+encode(r.query.isEmpty()?MusicRequest.label(r.language):r.query)+"&limit=50&include_purchaseable=false&app_name=ZameerRadio");
        JSONArray rows=result.optJSONArray("data");if(rows==null)throw new IOException("Catalog response invalid");
        List<Track> tracks=new ArrayList<>();
        for(int i=0;i<Math.min(50,rows.length());i++){
            JSONObject o=rows.optJSONObject(i);if(o==null)continue;String id=o.optString("id");JSONObject access=o.optJSONObject("access"),user=o.optJSONObject("user"),conditions=o.optJSONObject("stream_conditions");
            if(!id.matches("[a-zA-Z0-9]{1,64}")||!truth(o,"is_streamable")||truth(o,"is_stream_gated")||truth(o,"is_purchaseable")||truth(o,"is_delete")||truth(o,"is_unlisted")||(user!=null&&truth(user,"is_deactivated"))||(access!=null&&access.has("stream")&&!truth(access,"stream"))||(conditions!=null&&conditions.length()>0))continue;
            String title=o.optString("title"),tags=multi(o.opt("tags")),lang=multi(o.has("language_code")?o.opt("language_code"):o.opt("language"));
            if(!MusicRequest.matchesLanguage(title,tags,lang,r.language))continue;
            tracks.add(new Track("audius:"+id,title,user==null?"":user.optString("name"),"https://api.audius.co/v1/tracks/"+encode(id)+"/stream?app_name=ZameerRadio","audius",r.language,"","https://audius.co",tags+" "+multi(o.opt("genre"))+" "+multi(o.opt("mood"))));
        }
        return tracks;
    }
    private static String literal(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"")+"\"";}
    private List<Track> archive(MusicRequest r,MusicRequest desired) throws Exception {
        StringBuilder query=new StringBuilder("mediatype:audio AND -access-restricted-item:true AND (");
        for(String path:new String[]{"publicdomain/zero/1.0/","licenses/by/4.0/","licenses/by-sa/4.0/","licenses/by/3.0/","licenses/by-sa/3.0/"})for(String protocol:new String[]{"http","https"}){if(query.charAt(query.length()-1)!='(')query.append(" OR ");query.append("licenseurl:").append(literal(protocol+"://creativecommons.org/"+path));}query.append(')');
        if(!"all".equals(r.language))for(String[] row:MusicRequest.LANGUAGES)if(row[0].equals(r.language)){query.append(" AND (");for(int i=0;i<row.length;i++){if(i>0)query.append(" OR ");query.append("language:").append(literal(row[i]));}query.append(" OR title:").append(literal(row[1])).append(" OR subject:").append(literal(row[1])).append(')');}
        for(String term:r.query.split(" "))if(!term.isEmpty())query.append(" AND (title:").append(literal(term)).append(" OR creator:").append(literal(term)).append(" OR subject:").append(literal(term)).append(" OR description:").append(literal(term)).append(')');
        JSONObject body=fetcher.get("https://archive.org/advancedsearch.php?q="+encode(query.toString())+"&output=json&rows=6&page=1&fl%5B%5D=identifier");
        JSONArray docs=body.optJSONObject("response")==null?null:body.getJSONObject("response").optJSONArray("docs");if(docs==null)throw new IOException("Catalog response invalid");
        List<Track> tracks=new ArrayList<>();
        // Return the first usable album instead of waiting for every metadata request.
        for(int i=0;i<Math.min(6,docs.length())&&tracks.isEmpty();i++){
            JSONObject doc=docs.optJSONObject(i);String id=doc==null?"":doc.optString("identifier");if(!id.matches("[a-zA-Z0-9][a-zA-Z0-9_.-]{0,199}"))continue;
            try{tracks.addAll(candidates(archiveTracks(id,fetcher.get("https://archive.org/metadata/"+id),r.language),desired));}catch(Exception e){if(Thread.currentThread().isInterrupted())throw e;}
        }
        return tracks.subList(0,Math.min(50,tracks.size()));
    }
    static List<Track> archiveTracks(String id,JSONObject body,String language){
        List<Track> tracks=new ArrayList<>();JSONObject m=body.optJSONObject("metadata");JSONArray files=body.optJSONArray("files");
        if(!id.matches("[a-zA-Z0-9][a-zA-Z0-9_.-]{0,199}")||truth(body,"is_dark")||truth(body,"is_restricted")||m==null||files==null||!"audio".equals(m.optString("mediatype"))||truth(m,"access-restricted-item"))return tracks;
        String license=license(m.opt("licenseurl"));if(license.isEmpty())return tracks;Set<String> seen=new HashSet<>();
        for(int i=0;i<Math.min(2000,files.length())&&tracks.size()<50;i++){
            JSONObject f=files.optJSONObject(i);if(f==null)continue;String name=f.optString("name");if(!name.toLowerCase(java.util.Locale.ROOT).endsWith(".mp3")||name.length()>500||name.startsWith("/")||java.util.Arrays.stream(name.split("/")).anyMatch(x->x.equals(".")||x.equals(".."))||truth(f,"private")||f.optLong("size",-1)==0)continue;
            String key=f.optString("original",name).replaceFirst("(?i)\\.(mp3|flac|wav|ogg)$","");if(seen.contains(key))continue;
            String title=multi(f.opt("title"));if(title.isEmpty())title=name.substring(name.lastIndexOf('/')+1).replaceFirst("(?i)\\.mp3$","").replace('_',' ');
            if(!MusicRequest.matchesLanguage(title+" "+multi(m.opt("title")),multi(m.opt("subject")),multi(f.has("language")?f.opt("language"):m.opt("language")),language))continue;
            seen.add(key);StringBuilder path=new StringBuilder();for(String part:name.split("/")){if(path.length()>0)path.append('/');path.append(encode(part));}
            String artist=multi(f.opt("creator"));if(artist.isEmpty())artist=multi(m.opt("creator"));
            tracks.add(new Track("archive:"+id+":"+name,title,artist,"https://archive.org/download/"+encode(id)+"/"+path,"archive",language,license,"https://archive.org/details/"+id,multi(m.opt("subject"))+" "+multi(f.opt("genre"))+" "+multi(m.opt("year"))+" "+multi(m.opt("title"))));
        }
        return tracks;
    }
    private static String plain(String value){return value.replaceAll("(?is)<(script|style)\\b[^>]*>.*?</\\1>","").replaceAll("<[^>]*>"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replace("&nbsp;"," ").replaceAll("\\s+"," ").trim();}
    private static String field(JSONObject metadata,String key){JSONObject item=metadata.optJSONObject(key);return item==null?"":plain(item.optString("value"));}
    private static String providerUrl(String raw,String host,String path){try{URI u=new URI(raw);return "https".equals(u.getScheme())&&host.equals(u.getHost())&&u.getUserInfo()==null&&u.getPort()==-1&&u.getPath().startsWith(path)?raw:"";}catch(Exception e){return "";}}
    private static String query(MusicRequest r){return r.query+("all".equals(r.language)||MusicRequest.matchesLanguage(r.query,"","",r.language)?"":" "+MusicRequest.label(r.language));}
    private List<Track> mixter(MusicRequest r)throws Exception{
        JSONObject body=fetcher.get("https://ccmixter.org/api/query?f=json&search="+encode(query(r))+"&search_type=all&lic=by&reqtags=remix&limit=12&offset=0");
        JSONArray rows=body.optJSONArray("tracks");if(rows==null)throw new IOException("Invalid ccMixter response");return mixterTracks(rows,r.language);
    }
    static List<Track> mixterTracks(JSONArray rows,String language){
        List<Track> result=new ArrayList<>();Set<String> seen=new HashSet<>();
        for(int i=0;i<Math.min(50,rows.length());i++){
            JSONObject row=rows.optJSONObject(i);if(row==null)continue;
            String id=row.optString("upload_id"),name=plain(row.optString("upload_name")),tags=plain(row.optString("upload_tags")),lic=license(row.opt("license_url")),share=providerUrl(row.optString("file_page_url"),"ccmixter.org","/files/");
            JSONObject extra=row.optJSONObject("upload_extra");JSONArray files=row.optJSONArray("files");
            if(!id.matches("[0-9]{1,15}")||seen.contains(id)||lic.isEmpty()||share.isEmpty()||extra!=null&&truth(extra,"nsfw")||!tags.matches("(?i)(?:^|.*,)remix(?:,.*|$)")||!MusicRequest.matchesLanguage(name,tags,"",language)||files==null)continue;
            for(int j=0;j<Math.min(50,files.length());j++){
                JSONObject file=files.optJSONObject(j);if(file==null)continue;JSONObject format=file.optJSONObject("file_format_info");
                String url=providerUrl(file.optString("download_url"),"ccmixter.org","/content/");
                if(format==null||!"audio".equals(format.optString("media-type"))||!"audio/mpeg".equals(format.optString("mime_type"))||file.optLong("file_rawsize")<=0||url.isEmpty())continue;
                double duration=0;try{for(String part:format.optString("ps","0").split(":"))duration=duration*60+Double.parseDouble(part);}catch(Exception ignored){}
                if(duration>0&&duration<30)continue;
                seen.add(id);result.add(new Track("ccmixter:"+id,name,plain(row.optString("user_real_name",row.optString("user_name"))),url,"ccmixter",language,lic,share,multi(row.opt("upload_tags"))));break;
            }
        }return result;
    }
    private List<Track> commons(MusicRequest r)throws Exception{
        String words=query(r).replaceAll("[^\\p{L}\\p{M}\\p{N} ]+"," ");
        JSONObject body=fetcher.get("https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2&generator=search&gsrsearch="+encode("filetype:audio "+words)+"&gsrnamespace=6&gsrlimit=6&gsroffset=0&prop=imageinfo&iiprop=url%7Cmime%7Csize%7Cextmetadata&iiextmetadatalanguage=en&origin=*");
        if(body.has("error")||!body.has("query")&&!body.has("batchcomplete"))throw new IOException("Invalid Commons response");
        return commonsTracks(body,r.language);
    }
    static List<Track> commonsTracks(JSONObject body,String language){
        List<Track> result=new ArrayList<>();JSONObject query=body.optJSONObject("query");JSONArray rows=query==null?null:query.optJSONArray("pages");if(rows==null)return result;Set<String> seen=new HashSet<>();
        for(int i=0;i<Math.min(12,rows.length());i++){
            JSONObject row=rows.optJSONObject(i);if(row==null)continue;String id=row.optString("pageid");JSONArray info=row.optJSONArray("imageinfo");JSONObject file=info==null?null:info.optJSONObject(0);
            if(file==null||row.optInt("ns")!=6||truth(row,"missing")||truth(file,"filehidden")||!id.matches("[0-9]{1,15}")||seen.contains(id)||file.optLong("size")<=0||!java.util.Arrays.asList("audio/ogg","application/ogg","audio/mpeg","audio/flac","audio/wav","audio/x-wav").contains(file.optString("mime")))continue;
            JSONObject m=file.optJSONObject("extmetadata");if(m==null)continue;String lic=license(field(m,"LicenseUrl")),name=field(m,"ObjectName");if(name.isEmpty())name=plain(row.optString("title")).replaceFirst("^File:","");
            double duration=file.optDouble("duration",0);String url=providerUrl(file.optString("url"),"upload.wikimedia.org","/wikipedia/commons/"),share=providerUrl(file.optString("descriptionurl"),"commons.wikimedia.org","/wiki/File:");
            if(lic.isEmpty()||url.isEmpty()||share.isEmpty()||duration>0&&duration<30||!MusicRequest.matchesLanguage(name,field(m,"Categories")+" "+field(m,"ImageDescription"),field(m,"Language"),language))continue;
            String artist=field(m,"Artist");if(artist.isEmpty())artist=field(m,"Credit");seen.add(id);result.add(new Track("commons:"+id,name,artist,url,"commons",language,lic,share,field(m,"Categories")+" "+field(m,"ImageDescription")));
        }return result;
    }

}
