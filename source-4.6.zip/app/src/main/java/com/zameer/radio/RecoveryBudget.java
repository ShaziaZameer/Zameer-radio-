package com.zameer.radio;

/** Monotonic-clock retry budget. A brief reconnect must not create an endless retry loop. */
final class RecoveryBudget {
    static final long STABLE_MS=60_000, WINDOW_MS=300_000;
    private static final long[] DELAYS={2_000,5_000,10_000,20_000,30_000,60_000};
    private long started=-1, playingSince=-1;
    private int attempts;
    long nextDelay(long now){
        settle(now);
        playingSince=-1;
        if(started<0)started=now;
        if(attempts>=DELAYS.length||now-started>=WINDOW_MS)return -1;
        return DELAYS[attempts++];
    }
    boolean expired(long now){return started>=0&&now-started>=WINDOW_MS;}
    void playing(boolean value,long now){
        settle(now);
        if(value){if(playingSince<0)playingSince=now;}else playingSince=-1;
    }
    private void settle(long now){if(playingSince>=0&&now-playingSince>=STABLE_MS)reset();}
    void reset(){started=-1;playingSince=-1;attempts=0;}
    int attempts(){return attempts;}
    static long restoredSleepDeadline(long saved,long now){return saved>now&&saved-now<=480L*60_000?saved:0;}
}
