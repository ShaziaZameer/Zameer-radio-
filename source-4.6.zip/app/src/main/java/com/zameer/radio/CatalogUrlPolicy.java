package com.zameer.radio;
import java.net.URI;
/** Native catalog transport accepts only the two documented public JSON endpoints. */
final class CatalogUrlPolicy {
    static boolean allows(String raw){
        if(raw==null||raw.length()>3500)return false;
        try{
            URI uri=new URI(raw);
            if(!"https".equals(uri.getScheme())||uri.getUserInfo()!=null||uri.getPort()!=-1||uri.getFragment()!=null||uri.getQuery()==null)return false;
            boolean mix="ccmixter.org".equals(uri.getHost())&&"/api/query".equals(uri.getRawPath());
            boolean commons="commons.wikimedia.org".equals(uri.getHost())&&"/w/api.php".equals(uri.getRawPath());
            if(!mix&&!commons)return false;
            java.util.Map<String,String> params=new java.util.HashMap<>();
            for(String pair:uri.getRawQuery().split("&")){
                String[] v=pair.split("=",2);String key=java.net.URLDecoder.decode(v[0],"UTF-8");
                if(params.put(key,v.length==2?java.net.URLDecoder.decode(v[1],"UTF-8"):"")!=null)return false;
            }
            String allowed=mix?"f search search_type lic reqtags limit offset":"action format formatversion generator gsrsearch gsrnamespace gsrlimit gsroffset prop iiprop iiextmetadatalanguage origin";
            for(String key:params.keySet())if(!java.util.Arrays.asList(allowed.split(" ")).contains(key))return false;
            if(mix)return "json".equals(params.get("f"))&&bounded(params.get("limit"),1,50)&&bounded(params.get("offset"),0,500);
            return "query".equals(params.get("action"))&&"json".equals(params.get("format"))&&"search".equals(params.get("generator"))&&"imageinfo".equals(params.get("prop"))&&"6".equals(params.get("gsrnamespace"))&&bounded(params.get("gsrlimit"),1,12)&&bounded(params.get("gsroffset"),0,500);
        }catch(Exception ignored){return false;}
    }
    private static boolean bounded(String value,int min,int max){try{int n=Integer.parseInt(value);return n>=min&&n<=max;}catch(Exception e){return false;}}
}
