package com.zameer.radio;

/** Android error values: retry only service/network/language failures, once locally. */
final class VoiceRetryPolicy {
    static boolean useOnDevice(boolean alreadyLocal, int error) {
        if (alreadyLocal) return false;
        return error == 1 || error == 2 || error == 4 || error == 5
            || error == 11 || error == 12 || error == 13;
    }
}
