package com.zameer.radio;

import android.content.Context;
import android.content.res.Configuration;
import java.util.Locale;

/** Match native prompts and Media3 resources to the explicit in-app language. */
final class AppLanguage {
    static String code(Context context){return "en".equals(context.getSharedPreferences("player",Context.MODE_PRIVATE).getString("uiLanguage","hi"))?"en":"hi";}
    @SuppressWarnings("deprecation")
    static void apply(Context context){
        Locale locale=new Locale(code(context),"IN");
        Locale.setDefault(locale);
        Configuration config=new Configuration(context.getResources().getConfiguration());
        config.setLocales(new android.os.LocaleList(locale));config.setLayoutDirection(locale);
        context.getResources().updateConfiguration(config,context.getResources().getDisplayMetrics());
    }
}
