package com.zameer.radio;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.LibraryResult;
import androidx.media3.session.MediaLibraryService.LibraryParams;
import androidx.media3.session.MediaLibraryService.MediaLibrarySession;
import androidx.media3.session.MediaSession;
import androidx.media3.session.SessionError;
import com.google.common.collect.ImmutableList;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.function.LongSupplier;
import java.util.function.Consumer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Standard browser/search bridge for trusted controllers, independent of the WebView. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
class AssistantLibrary implements MediaLibrarySession.Callback {
    private static final String ROOT = "zr:library";
    private final SharedPreferences prefs;
    private final Player player;
    private final LongSupplier generation;
    private final Consumer<String> status;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private Future<?> pending;
    private SettableFuture<List<MediaItem>> pendingResult;
    private String cachedQuery="";
    private String cachedProvider="",cachedLanguage="";
    private List<MediaItem> cachedItems=new ArrayList<>();
    private long cachedAt;
    private boolean closed;
    private MusicRequest lastArtist;
    private long lastArtistAt;
    AssistantLibrary(SharedPreferences prefs, Player player, LongSupplier generation, Consumer<String> status) {
        this.prefs = prefs; this.player = player; this.generation=generation; this.status=status;
        if("youtubeMusic".equals(prefs.getString("catalogProvider","all")))prefs.edit().putString("catalogProvider","all").apply();
    }
    void clearArtistContext(){lastArtist=null;lastArtistAt=0;}
    void close(){closed=true;cancelSearch();worker.shutdownNow();main.removeCallbacksAndMessages(null);cachedItems.clear();}
    void cancelSearch(){if(pending!=null)pending.cancel(true);pending=null;if(pendingResult!=null)pendingResult.cancel(false);pendingResult=null;}
    private static String queryWithExtras(String query, Bundle extras) {
        return AssistantQuery.resolve(query,
            extras == null ? null : extras.getString(android.provider.MediaStore.EXTRA_MEDIA_FOCUS),
            extras == null ? null : extras.getString(android.provider.MediaStore.EXTRA_MEDIA_ARTIST),
            extras == null ? null : extras.getString(android.provider.MediaStore.EXTRA_MEDIA_TITLE));
    }
    private MediaItem radioItem(JSONObject row){
        String url=row.optString("url_resolved",row.optString("url"));if(!RadioMatch.publicUrl(url))return null;
        Bundle extras=new Bundle();extras.putString("url",url);extras.putString("kind","");for(String key:new String[]{"tags","language","state","country"})extras.putString(key,row.optString(key));
        return new MediaItem.Builder().setMediaId(row.optString("stationuuid",row.optString("id",url))).setUri(url).setMediaMetadata(new MediaMetadata.Builder().setTitle(row.optString("name","Radio")).setArtist("Live radio").setGenre(row.optString("tags")).setExtras(extras).setIsBrowsable(false).setIsPlayable(true).setMediaType(MediaMetadata.MEDIA_TYPE_RADIO_STATION).build()).build();
    }
    private ListenableFuture<List<MediaItem>> searchAsync(String query){
        if(closed||query==null||query.length()>600||prefs.getBoolean("wipeWebData",false)||AssistantSearch.negated(query))return Futures.immediateFailedFuture(new IllegalArgumentException("Search unavailable"));
        cancelSearch();List<MediaItem> available=search(query);
        if(!available.isEmpty())return Futures.immediateFuture(available);
        if(AssistantSearch.localOnly(query))return Futures.immediateFailedFuture(new IllegalArgumentException("No matching phone songs"));
        SettableFuture<List<MediaItem>> result=SettableFuture.create();pendingResult=result;
        long epoch=generation.getAsLong(),transport=prefs.getLong("transportEpoch",0);
        status.accept("en".equals(prefs.getString("uiLanguage","hi"))?"Finding live radio stations…":"लाइव रेडियो स्टेशन खोज रहे हैं…");
        pending=worker.submit(()->{try{
            JSONArray rows=RadioApi.discover(query);List<MediaItem> resolved=new ArrayList<>();
            for(int i=0;i<Math.min(100,rows.length());i++){JSONObject row=rows.optJSONObject(i);if(row==null)continue;MediaItem item=radioItem(row);if(item!=null&&RadioMatch.verifiedContent(query,row.optString("url_resolved",row.optString("url")))&&RadioMatch.matches(query,row.optString("name")+" "+row.optString("tags"),row.optString("language"),row.optString("url_resolved",row.optString("url"))))resolved.add(item);}
            main.post(()->{if(closed||result.isCancelled())return;if(epoch!=generation.getAsLong()||transport!=prefs.getLong("transportEpoch",0)||prefs.getBoolean("wipeWebData",false)){result.cancel(false);return;}
                if(resolved.isEmpty()){status.accept("मिलता लाइव स्टेशन नहीं मिला। भाषा, मूड या स्टेशन का नाम बोलें।");result.setException(new IllegalArgumentException("No matching radio"));return;}
                sortLanguages(resolved,query);cachedItems=resolved;cachedAt=System.currentTimeMillis();status.accept("लाइव रेडियो मिला। गीत स्टेशन तय करता है।");result.set(resolved);
            });
        }catch(Exception e){main.post(()->{if(!closed&&!result.isCancelled()&&epoch==generation.getAsLong()){status.accept("रेडियो खोज नहीं खुली। इंटरनेट जाँचें।");result.setException(new IllegalArgumentException("Radio directory unavailable",e));}else result.cancel(false);});}});return result;
    }

    private MediaItem root() {
        return new MediaItem.Builder().setMediaId(ROOT).setMediaMetadata(new MediaMetadata.Builder()
            .setTitle("Zameer Radio").setIsBrowsable(true).setIsPlayable(false)
            .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED).build()).build();
    }
    private MediaItem browsableItem(MediaItem item) {
        return item.buildUpon().setMediaMetadata(item.mediaMetadata.buildUpon()
            .setIsBrowsable(false).setIsPlayable(true).build()).build();
    }
    private List<MediaItem> queue() {
        List<MediaItem> items = new ArrayList<>();
        for (int i = 0; i < Math.min(600, player.getMediaItemCount()); i++) items.add(browsableItem(player.getMediaItemAt(i)));
        return items;
    }
    private List<MediaItem> items() {
        if (prefs.getBoolean("wipeWebData", false)) return new ArrayList<>();
        LinkedHashMap<String, MediaItem> items = new LinkedHashMap<>();
        if(System.currentTimeMillis()-cachedAt<60000)for(MediaItem item:cachedItems)items.put(item.mediaId,item);
        for (MediaItem item : queue()) items.put(item.mediaId, item);
        try{JSONArray rows=new JSONArray(prefs.getString("radioDirectory","[]"));for(int i=0;i<Math.min(5000,rows.length());i++){JSONObject row=rows.optJSONObject(i);if(row==null)continue;MediaItem item=radioItem(row);if(item!=null)items.putIfAbsent(item.mediaId,item);}}catch(org.json.JSONException ignored){}
        try {
            JSONArray rows = new JSONArray(prefs.getString("library", "[]"));
            for (int i = 0; i < Math.min(500, rows.length()) && items.size() < 600; i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null || !"local".equals(row.optString("kind")) || !row.optBoolean("available", true)) continue;
                String url = row.optString("url"), id = row.optString("id", url);
                if (!"content".equals(Uri.parse(url).getScheme()) || id.isEmpty()) continue;
                Bundle extras = new Bundle(); extras.putString("url", url); extras.putString("kind", "local");
                MediaItem item = new MediaItem.Builder().setMediaId(id).setUri(url).setMediaMetadata(new MediaMetadata.Builder()
                    .setTitle(row.optString("name")).setArtist(row.optString("artist")).setGenre(row.optString("genre"))
                    .setExtras(extras).setIsBrowsable(false).setIsPlayable(true).setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC).build()).build();
                items.putIfAbsent(id, item);
            }
        } catch (org.json.JSONException ignored) {}
        return new ArrayList<>(items.values());
    }
    private void sortLanguages(List<MediaItem> rows,String query){if(!RadioMatch.language(RadioMatch.normalize(query)).isEmpty()||AssistantSearch.localOnly(query))return;rows.sort(java.util.Comparator.comparingInt(item->{MediaMetadata m=item.mediaMetadata;return RadioMatch.languageOrder(m.extras==null?"":m.extras.getString("language",""),String.valueOf(m.title)+" "+String.valueOf(m.genre));}));}
    private List<MediaItem> search(String query){
        List<MediaItem> result=new ArrayList<>();if(query==null||AssistantSearch.negated(query))return result;boolean local=AssistantSearch.localOnly(query);
        for(MediaItem item:items()){MediaMetadata m=item.mediaMetadata;boolean phone=item.localConfiguration!=null&&"content".equals(item.localConfiguration.uri.getScheme());if(local!=phone)continue;
            String title=m.title==null?"":m.title.toString(),artist=m.artist==null?"":m.artist.toString(),tags=m.genre==null?"":m.genre.toString();
            if(local?AssistantSearch.matches(query,title,artist,tags):RadioMatch.verifiedContent(query,m.extras==null?"":m.extras.getString("url",""))&&RadioMatch.matches(query,title+" "+tags,m.extras==null?"":m.extras.getString("language",""),m.extras==null?"":m.extras.getString("url","")))result.add(item);
        }sortLanguages(result,query);return result.size()>100?new ArrayList<>(result.subList(0,100)):result;
    }
    private List<MediaItem> page(List<MediaItem> items, int page, int size) {
        if (page < 0 || size < 1) return new ArrayList<>();
        long start = (long) page * size;
        if (start >= items.size()) return new ArrayList<>();
        return items.subList((int) start, (int) Math.min(items.size(), start + size));
    }
    @Override public ListenableFuture<LibraryResult<MediaItem>> onGetLibraryRoot(MediaLibrarySession session, MediaSession.ControllerInfo browser, LibraryParams params) {
        return Futures.immediateFuture(LibraryResult.ofItem(root(), params));
    }
    @Override public ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> onGetChildren(MediaLibrarySession session, MediaSession.ControllerInfo browser, String parent, int page, int size, LibraryParams params) {
        return Futures.immediateFuture(ROOT.equals(parent) ? LibraryResult.ofItemList(page(items(), page, size), params) : LibraryResult.ofError(SessionError.ERROR_BAD_VALUE));
    }
    @Override public ListenableFuture<LibraryResult<MediaItem>> onGetItem(MediaLibrarySession session, MediaSession.ControllerInfo browser, String id) {
        if (ROOT.equals(id)) return Futures.immediateFuture(LibraryResult.ofItem(root(), null));
        for (MediaItem item : items()) if (item.mediaId.equals(id)) return Futures.immediateFuture(LibraryResult.ofItem(item, null));
        return Futures.immediateFuture(LibraryResult.ofError(SessionError.ERROR_BAD_VALUE));
    }
    @Override public ListenableFuture<LibraryResult<Void>> onSearch(MediaLibrarySession session, MediaSession.ControllerInfo browser, String query, LibraryParams params) {
        return Futures.transform(searchAsync(queryWithExtras(query,params==null?null:params.extras)),items->{session.notifySearchResultChanged(browser, query, items.size(), params);return LibraryResult.ofVoid(params);},Runnable::run);
    }
    @Override public ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> onGetSearchResult(MediaLibrarySession session, MediaSession.ControllerInfo browser, String query, int page, int size, LibraryParams params) {
        return Futures.transform(searchAsync(queryWithExtras(query,params==null?null:params.extras)),items->LibraryResult.ofItemList(page(items, page, size),params),Runnable::run);
    }
    @Override public ListenableFuture<List<MediaItem>> onAddMediaItems(MediaSession session, MediaSession.ControllerInfo controller, List<MediaItem> requests) {
        // The app's existing bridge validates its own queues. External clients can only choose known items.
        if (controller.getUid() == android.os.Process.myUid()) return Futures.immediateFuture(requests);
        if(requests.size()==1&&requests.get(0).requestMetadata.searchQuery!=null)
            return searchAsync(queryWithExtras(requests.get(0).requestMetadata.searchQuery,requests.get(0).requestMetadata.extras));
        List<MediaItem> resolved = new ArrayList<>(), available = items();
        for (MediaItem request : requests) {
            List<MediaItem> matches = new ArrayList<>();
            if (request.requestMetadata.searchQuery != null) matches.addAll(search(queryWithExtras(request.requestMetadata.searchQuery,request.requestMetadata.extras)));
            else for (MediaItem item : available) if (item.mediaId.equals(request.mediaId) ||
                (request.requestMetadata.mediaUri != null && item.localConfiguration != null && request.requestMetadata.mediaUri.equals(item.localConfiguration.uri))) { matches.add(item); break; }
            if (matches.isEmpty()) return Futures.immediateFailedFuture(new IllegalArgumentException("No matching available song. Open Zameer Radio to discover live stations or add phone songs."));
            resolved.addAll(matches);
            if (resolved.size() > 600) return Futures.immediateFailedFuture(new IllegalArgumentException("Queue too large"));
        }
        return Futures.immediateFuture(resolved);
    }
    @Override public ListenableFuture<MediaSession.MediaItemsWithStartPosition> onSetMediaItems(MediaSession session, MediaSession.ControllerInfo controller, List<MediaItem> requests, int startIndex, long startPositionMs) {
        // Legacy playFromSearch("") is resume; preserve the current track and position.
        if (!prefs.getBoolean("wipeWebData", false) && requests.size() == 1 && "".equals(requests.get(0).requestMetadata.searchQuery) && queryWithExtras("",requests.get(0).requestMetadata.extras).isEmpty() && player.getMediaItemCount() > 0)
            return Futures.immediateFuture(new MediaSession.MediaItemsWithStartPosition(queue(), player.getCurrentMediaItemIndex(), player.getCurrentPosition()));
        return MediaLibrarySession.Callback.super.onSetMediaItems(session, controller, requests, startIndex, startPositionMs);
    }
}
