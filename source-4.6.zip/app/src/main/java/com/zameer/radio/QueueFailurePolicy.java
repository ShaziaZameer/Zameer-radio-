package com.zameer.radio;

/** A finite budget per explicitly loaded queue; never changes play intent. */
final class QueueFailurePolicy {
    private int failures;
    void reset(){failures=0;}
    int nextIndex(int index,int count,boolean repeatAll,boolean wants,boolean suppressed,boolean onlineSong){
        if(!wants||suppressed||!onlineSong||index<0||index>=count)return -1;
        if(++failures>=5||count<2)return -1;
        if(index+1<count)return index+1;
        return repeatAll?0:-1;
    }
}
