package com.zameer.radio;

/** Memory-only intent: a device connection by itself never starts music. */
public final class BluetoothResumePolicy {
    public static final long WINDOW_MS=30*60_000L;
    private String item="", device="";
    private long expires;
    public void arm(boolean enabled,boolean wasPlaying,String mediaId,String deviceKey,long now){
        if(!enabled||!wasPlaying||mediaId==null||mediaId.isEmpty()||deviceKey==null||deviceKey.isEmpty())return;
        item=mediaId;device=deviceKey;expires=now+WINDOW_MS;
    }
    public boolean pending(long now){if(expires>0&&now>=expires)cancel();return expires>0;}
    public boolean matches(String mediaId,String deviceKey,long now){return pending(now)&&item.equals(mediaId)&&device.equals(deviceKey);}
    public void cancel(){item="";device="";expires=0;}
}
