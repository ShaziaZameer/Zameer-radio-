package com.zameer.radio;

import java.text.Normalizer;
import java.util.Locale;

/** Bounded matching for already available media; never invents an online result. */
final class AssistantSearch {
    static boolean localOnly(String query) {
        return query != null && query.matches("(?is)^(?:मेरे (?:गाने|गानों|गीत|गीतों)|मेरा गीत (?:में|से)|फोन के |my (?:songs|music|playlist)).*");
    }
    static boolean negated(String query) {
        return query != null && (" " + query.toLowerCase(Locale.ROOT) + " ").matches("(?s).*\\s(?:मत|नहीं|नही|don't|dont|never|do not)\\s.*");
    }
    static String key(String value) {
        if (value == null) return "";
        String s = Normalizer.normalize(value.substring(0, Math.min(600, value.length())), Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);
        s = s.replace("रेडियो", "radio").replace("मिर्ची", "mirchi").replace("विविध भारती", "vividh bharati")
            .replace("हिन्दी", "hindi").replace("हिंदी", "hindi").replace("रोमांटिक", "romantic")
            .replace("रोमांस", "romantic").replace("romance", "romantic").replace("पुराने", "retro").replace("oldies", "retro");
        return s.replaceAll("[^\\p{L}\\p{M}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
    }
    static String queryKey(String query) {
        String s = query == null ? "" : query.trim();
        s = s.replaceFirst("(?i)^(?:(?:मेरे (?:गानों|गीतों|गाने|गीत)|फोन के (?:गानों|गीतों|गाने|गीत)|मेरी प्लेलिस्ट|my (?:songs|music|playlist))(?: में से| में| से)?|मेरा गीत (?:में से|में|से))\\s+", "");
        s = s.replaceFirst("(?i)^(?:play|गाना|गीत|song)\\s+", "");
        s = s.replaceFirst("\\s+(?:चलाओ|चलाएं|चलाएँ|चलाइए|बजाओ|बजा दो|चला दो|सुनाओ|प्ले करो)$", "");
        s = s.replaceFirst("(?i)\\s+(?:गाने|गाना|गीत|संगीत|songs?|music)$", "");
        return key(s);
    }
    static boolean matches(String query, String title, String artist, String genre) {
        if (query == null || query.length() > 160 || negated(query)) return false;
        String wanted = queryKey(query);
        if (wanted.isEmpty()) return query.trim().isEmpty();
        String metadata = key(title) + " " + key(artist) + " " + key(genre);
        for (String token : wanted.split(" ")) if (!metadata.contains(token)) return false;
        return true;
    }
}
