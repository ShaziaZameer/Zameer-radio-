package com.zameer.radio;

import org.json.JSONArray;
import org.json.JSONObject;

/** Public live-radio streams checked 2026-09-26; broadcaster controls the schedule. */
final class ArtistRadioStations {
    private static final String[][] STATIONS={
        {"kumar-sanu","Bollywood Kumar Sanu","Kumar Sanu","https://drive.uber.radio/uber/bollywoodkumarsanu/icecast.audio"},
        {"alka-yagnik","Bollywood Alka Yagnik","Alka Yagnik","https://drive.uber.radio/uber/bollywoodalkayagnik/icecast.audio"},
        {"mohammed-rafi","Bollywood Mohammed Rafi","Mohammed Rafi","https://drive.uber.radio/uber/bollywoodmohammedrafi/icecast.audio"},
        {"shreya-ghoshal","Bollywood Shreya Ghosal","Shreya Ghoshal","https://drive.uber.radio/uber/bollywoodshreyaghosal/icecast.audio"},
        {"udit-narayan","Bollywood Udit Narayan","Udit Narayan","https://drive.uber.radio/uber/bollywooduditnarayan/icecast.audio"}
    };
    static JSONArray rows(){
        JSONArray result=new JSONArray();
        for(String[] s:STATIONS)try{result.put(new JSONObject().put("stationuuid","curated-"+s[0]).put("name",s[1]).put("search_name",s[2]).put("language","hindi").put("tags","bollywood,hindi").put("lastcheckok",1).put("url_resolved",s[3]).put("homepage","https://play.you.radio/").put("provider","Bollywood Radio"));}catch(org.json.JSONException ignored){}
        return result;
    }
}
