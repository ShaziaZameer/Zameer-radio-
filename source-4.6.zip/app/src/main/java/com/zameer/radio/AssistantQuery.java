package com.zameer.radio;

/** Preserve structured artist intent instead of searching the artist as a song title. */
final class AssistantQuery {
    static String resolve(String query, String focus, String artist, String title) {
        String raw = query == null ? "" : query.trim();
        if (raw.length() > 160 || AssistantSearch.negated(raw) || AssistantSearch.localOnly(raw)) return raw;
        String name = artist == null ? "" : artist.trim();
        String song = title == null ? "" : title.trim();
        boolean artistFocus = "vnd.android.cursor.item/artist".equals(focus);
        if (!name.isEmpty() && name.length() <= 80 && (artistFocus || (raw.isEmpty() && song.isEmpty()))) {
            MusicRequest parsed = MusicRequest.parse(raw, "hi");
            if (parsed != null && !parsed.artist.isEmpty()) return raw;
            String prefix = parsed != null && parsed.online ? "online " : "";
            if (parsed != null && parsed.explicitLanguage) prefix += MusicRequest.label(parsed.language) + " ";
            return prefix + "songs by " + name;
        }
        if (!raw.isEmpty()) return raw;
        return song.isEmpty() ? "" : "play song " + song.substring(0, Math.min(145, song.length()));
    }
}
