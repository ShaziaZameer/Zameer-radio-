package com.zameer.radio;

import android.media.audiofx.AudioEffect;
import android.media.audiofx.Equalizer;
import java.util.function.Consumer;

/** Owns only this player's nonzero audio session. Device-wide audio is untouched. */
final class SmartSound {
    private Equalizer equalizer;
    private int session,failedSession;
    private String profile="",status="waiting",currentTags="";
    private final Consumer<String> changed;
    SmartSound(Consumer<String> changed){this.changed=changed;}
    private void report(String value){if(!value.equals(status)){status=value;changed.accept(value);}}
    void apply(int audioSession,boolean enabled,String tags){
        if(!enabled){release();failedSession=0;report("off");return;}
        if(audioSession<=0){release();report("waiting");return;}
        currentTags=tags;String target=SmartSoundProfile.choose(tags);
        if(failedSession==audioSession){report("unsupported");return;}
        if(session!=audioSession){release();failedSession=0;}
        try {
            if(equalizer==null){
                session=audioSession;equalizer=new Equalizer(0,audioSession);
                equalizer.setControlStatusListener((effect,hasControl)->{
                    if(effect!=equalizer)return;
                    if(!hasControl)report("unsupported");else {profile="";apply(session,true,currentTags);}
                });
            }
            if(!equalizer.hasControl()){report("unsupported");return;}
            if(!target.equals(profile)){
                short[] range=equalizer.getBandLevelRange();short bands=equalizer.getNumberOfBands();
                if(range.length<2||range[0]>0||range[1]<0||bands<1)throw new UnsupportedOperationException();
                for(short band=0;band<bands;band++)equalizer.setBandLevel(band,SmartSoundProfile.level(target,equalizer.getCenterFreq(band),range[0],range[1]));
                profile=target;
            }
            if(equalizer.setEnabled(true)!=AudioEffect.SUCCESS)throw new UnsupportedOperationException();
            report(target);
        } catch(RuntimeException error){release();failedSession=audioSession;report("unsupported");}
    }
    void release(){
        Equalizer old=equalizer;equalizer=null;session=0;profile="";
        if(old!=null){try{old.setControlStatusListener(null);old.setEnabled(false);}catch(RuntimeException ignored){}finally{try{old.release();}catch(RuntimeException ignored){}}}
    }
}
