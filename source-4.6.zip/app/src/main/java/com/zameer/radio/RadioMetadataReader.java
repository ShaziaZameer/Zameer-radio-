package com.zameer.radio;

import androidx.media3.common.Metadata;
import androidx.media3.extractor.metadata.icy.IcyInfo;
import androidx.media3.extractor.metadata.id3.TextInformationFrame;

@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
final class RadioMetadataReader {
    static void accept(RadioNowPlaying target,String id,Metadata metadata,long at){
        String title="",artist="",album="";boolean icy=false,sawTitle=false;
        for(int i=0;i<Math.min(100,metadata.length());i++){
            Metadata.Entry entry=metadata.get(i);
            if(entry instanceof IcyInfo){target.icy(id,((IcyInfo)entry).title,at);icy=true;}
            else if(entry instanceof TextInformationFrame){
                TextInformationFrame frame=(TextInformationFrame)entry;
                String value=frame.values.isEmpty()?"":frame.values.get(0);
                switch(frame.id){case "TIT2":case "TT2":title=value;sawTitle=true;break;case "TPE1":case "TP1":artist=value;break;case "TALB":case "TAL":album=value;break;default:break;}
            }
        }
        if(!icy&&sawTitle)target.id3(id,title,artist,album,at);
    }
}
