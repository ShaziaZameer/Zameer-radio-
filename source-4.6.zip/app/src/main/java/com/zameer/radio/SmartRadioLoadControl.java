package com.zameer.radio;

import android.os.SystemClock;
import androidx.media3.common.C;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.LoadControl;
import androidx.media3.exoplayer.upstream.DefaultAllocator;

@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
final class SmartRadioLoadControl extends DefaultLoadControl {
    private volatile boolean radio;
    private final SmartBufferPolicy policy=new SmartBufferPolicy();
    SmartRadioLoadControl(){super(new DefaultAllocator(true,C.DEFAULT_BUFFER_SEGMENT_SIZE),60_000,180_000,2_500,5_000,16*1024*1024,false,0,false);}
    void station(boolean radio){this.radio=radio;policy.reset();}
    @Override public boolean shouldStartPlayback(LoadControl.Parameters p){
        boolean ready=super.shouldStartPlayback(p);
        if(!radio||!p.rebuffering)return ready;
        long goal=SmartBufferPolicy.capToLiveWindow(policy.requiredMs(SystemClock.elapsedRealtime(),p.lastRebufferRealtimeMs)*1000,p.targetLiveOffsetUs);
        // A live playlist may expose less media than the full desired cushion.
        return ready&&p.bufferedDurationUs/Math.max(0.1f,p.playbackSpeed)>=goal;
    }
}
