package com.zameer.radio;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Language intent shared by native search and metadata filtering; no speech capture. */
final class MusicRequest {
    static final String[][] LANGUAGES = {
        {"hi","hindi","hin","हिंदी","हिन्दी"},{"bho","bhojpuri","भोजपुरी"},
        {"pa","punjabi","pan","पंजाबी"},{"ur","urdu","urd","उर्दू"},
        {"bn","bengali","ben","बंगाली"},{"mr","marathi","mar","मराठी"},
        {"gu","gujarati","guj","गुजराती"},{"ta","tamil","tam","तमिल"},
        {"te","telugu","tel","तेलुगु"},{"kn","kannada","kan","कन्नड़"},
        {"ml","malayalam","mal","मलयालम"},{"en","english","eng","अंग्रेज़ी","अंग्रेजी"}
    };
    final String language, query, artist, provider;
    final boolean titleOnly,followup;
    final java.util.List<String> filters;
    final boolean explicitLanguage, online, station;
    private MusicRequest(String language,String query,String artist,boolean explicit,boolean online,String provider){this(language,query,artist,explicit,online,provider,false);}
    private MusicRequest(String language,String query,String artist,boolean explicit,boolean online,String provider,boolean station){this(language,query,artist,explicit,online,provider,station,java.util.Collections.emptyList(),false);}
    private MusicRequest(String language,String query,String artist,boolean explicit,boolean online,String provider,boolean station,java.util.List<String> filters,boolean followup){this.filters=java.util.Collections.unmodifiableList(new java.util.ArrayList<>(filters));this.followup=followup;this.language=language;this.query=query;this.artist=artist;this.explicitLanguage=explicit;this.online=online;this.provider=provider;this.station=station;this.titleOnly=!station&&!followup&&filters.isEmpty()&&!query.isEmpty()&&artist.isEmpty()&&!query.matches("romantic|retro|old|calm|sad|happy|devotional|party|sleep|personal|bhajan|focus|meditation|travel|acoustic|energy|workout|news");}
    MusicRequest withArtist(String value){return new MusicRequest(language,ArtistNames.canonical(value)+(filters.isEmpty()?"":" "+ArtistCommand.join(" ",filters)),value,explicitLanguage,online,provider,station,filters,false);}
    MusicRequest broadQuery(){return new MusicRequest(language,ArtistNames.canonical(artist),artist,explicitLanguage,online,provider,station,filters,followup);}
    MusicRequest withQuery(String query){return new MusicRequest(language,query,artist,explicitLanguage,online,provider,station,filters,followup);}
    static String normalize(String value){return Normalizer.normalize(value==null?"":value,Normalizer.Form.NFKC).toLowerCase(Locale.ROOT).replaceAll("[।.!?,]"," ").replaceAll("\\s+"," ").trim();}
    static String valid(String code){for(String[] row:LANGUAGES)if(row[0].equals(code))return code;return "all".equals(code)?code:"hi";}
    static String label(String code){for(String[] row:LANGUAGES)if(row[0].equals(code))return row[1];return "music";}
    static String pattern(){StringBuilder b=new StringBuilder();for(String[] row:LANGUAGES)for(int i=1;i<row.length;i++){if(b.length()>0)b.append('|');b.append(Pattern.quote(row[i]));}return b.toString();}
    static MusicRequest parse(String raw,String fallback){
        if(raw==null||raw.length()>160||AssistantSearch.negated(raw)||AssistantSearch.localOnly(raw))return null;
        String s=normalize(raw).replaceFirst("^(?:कृपया|प्लीज|please) ","").replaceFirst("(?: on zameer radio| (?:ज़मीर|जमीर|ज़मीर) रेडियो पर)$","");
        CatalogCommand catalog=CatalogCommand.parse(s);s=catalog.query;
        if(!CatalogCommand.parse(s).provider.isEmpty())return null;
        String languagePrefix="";
        Matcher prefix=Pattern.compile("^(?:play )?("+pattern()+")(?: में| भाषा में| language)? (.+)$").matcher(s);
        if(prefix.matches()){languagePrefix=prefix.group(1)+" ";s=prefix.group(2);}
        Matcher stationMatch=Pattern.compile("^(?:play )?(?:live )?(?:radio|station) (.+)$|^(?:लाइव )?(?:रेडियो|स्टेशन) (.+)$|^(.+?) (?:लाइव )?(?:रेडियो|स्टेशन) (?:चलाओ|बजाओ|सुनाओ)$|^(?:play )?(.+?) (?:live )?(?:radio|station)$").matcher(s);
        if(!stationMatch.matches())return parseBare(raw,fallback);
        for(int i=1;i<=4;i++)if(stationMatch.group(i)!=null){s=stationMatch.group(i);break;}
        MusicRequest r=parseBare(languagePrefix+s,fallback);if(r==null)return null;
        return new MusicRequest(r.language,r.query,r.artist,r.explicitLanguage,true,catalog.provider,true);
    }
    private static MusicRequest parseBare(String raw,String fallback){
        if(raw==null||raw.length()>160||AssistantSearch.negated(raw)||AssistantSearch.localOnly(raw))return null;
        String s=normalize(raw).replaceFirst("(?: on zameer radio| (?:ज़मीर|जमीर|ज़मीर) रेडियो पर)$","").replaceFirst("^(?:कृपया|प्लीज|please) ","").replaceFirst("^(?:अब|अभी|now) ","");
        CatalogCommand catalog=CatalogCommand.parse(s);s=catalog.query;
        if(!CatalogCommand.parse(s).provider.isEmpty())return null;
        boolean online=!catalog.provider.isEmpty()||Pattern.compile("(?:^| )(?:ऑनलाइन|online)(?: |$)").matcher(s).find();
        s=s.replaceAll("(?:^| )(?:ऑनलाइन|online)(?= |$)"," ").trim().replaceAll("\\s+"," ");
        String words=pattern();
        s=s.replaceFirst("^(?:"+words+") से (?=(?:"+words+")(?: |$))","")
            .replaceFirst("^(?:switch |change )?from (?:"+words+") to ","")
            .replaceFirst("^(?:play |listen to |switch to |change to )","");
        Matcher m=Pattern.compile("^("+words+")(?: में| भाषा में| language)?(?: |$)(.*)$").matcher(s);
        String language=valid(fallback);boolean explicit=m.matches();
        if(explicit){for(String[] row:LANGUAGES)for(int i=1;i<row.length;i++)if(row[i].equals(m.group(1)))language=row[0];s=m.group(2);}
        if(!explicit&&s.matches(".*(?:गाने|songs|tracks|music)(?: (?:चलाओ|बजाओ|सुनाओ))?$")){
            Matcher anywhere=Pattern.compile("(?<![\\p{L}\\p{M}])("+words+")(?![\\p{L}\\p{M}])").matcher(s);String chosen="";
            while(anywhere.find()){String code="";for(String[] row:LANGUAGES)for(int i=1;i<row.length;i++)if(row[i].equals(anywhere.group(1)))code=row[0];if(!chosen.isEmpty()&&!chosen.equals(code))return null;chosen=code;}
            if(!chosen.isEmpty()){language=chosen;explicit=true;s=anywhere.replaceAll(" ").trim().replaceAll("\\s+"," ");}
        }
        s=s.replaceFirst("(?:^| )(?:चलाओ|चलाएं|चलाएँ|चलाइए|चलाइये|चलाईए|चलाये|बजाओ|बजा दो|बजा दें|बजा दीजिए|बजाइए|बजाइये|बजाएं|बजाएँ|चला दो|चला दें|चला दीजिए|सुनाओ|सुना दो|सुनाइए|सुनाइये|प्ले करो|प्ले कर दो|लगाओ|लगा दो|बदलो|बदल दो)$","").trim();
        ArtistCommand combined=ArtistCommand.parse(s);
        if(combined!=null){
            if(!combined.language.isEmpty()){language=combined.language;explicit=true;}
            return new MusicRequest(language,ArtistNames.canonical(combined.artist)+(combined.filters.isEmpty()?"":" "+ArtistCommand.join(" ",combined.filters)),combined.followup?"":combined.artist,explicit,online,catalog.provider,false,combined.filters,combined.followup);
        }
        String artist="";
        Matcher artistMatch=Pattern.compile("^(?:गायक |कलाकार )?(.+?) (?:के|की|का) (?:गाने|गीत|गाना|संगीत)$").matcher(s);
        if(artistMatch.matches())artist=artistMatch.group(1);
        else{artistMatch=Pattern.compile("^(?:songs?|music) (?:by|of) (.+)$|^(?:artist|singer|गायक|कलाकार) (.+)$").matcher(s);if(artistMatch.matches())artist=artistMatch.group(1)!=null?artistMatch.group(1):artistMatch.group(2);}
        if(artist.isEmpty()){artistMatch=Pattern.compile("^(.+?) songs$").matcher(s);if(artistMatch.matches()&&ArtistNames.known(artistMatch.group(1)))artist=artistMatch.group(1);}
        if(artist.isEmpty()&&ArtistNames.known(s))artist=s;
        if(!artist.isEmpty())return new MusicRequest(language,ArtistNames.canonical(artist),artist,explicit,online,catalog.provider);
        boolean namedPrefix=s.matches("^(?:गाना|गीत|song) .+");
        s=namedPrefix?s.replaceFirst("^(?:गाना|गीत|song) ",""):s.replaceFirst("(?:^| )(?:गाने|गाना|गीत|संगीत|songs?|music)$","").trim();
        s=KeywordSearch.canonical(s);
        if(s.isEmpty()&&!explicit&&catalog.provider.isEmpty())return null;
        return new MusicRequest(language,s,"",explicit,online,catalog.provider);
    }
    static boolean matchesLanguage(String title,String tags,String rawLanguage,String wanted){
        if("all".equals(wanted))return true;
        String meta=normalize(title+" "+tags).replace('_',' '),codes=normalize(rawLanguage);
        boolean match=false;
        for(String[] row:LANGUAGES){
            boolean found=false;
            for(int i=0;i<row.length;i++){
                String word=Pattern.quote(row[i]);
                if(Pattern.compile("(?:^|[\\s,;|/])"+word+"(?:[-_][a-z]+)?(?=$|[\\s,;|/])").matcher(codes).find())found=true;
                if(i==1||i>=3||row[i].matches(".*[^a-z].*"))if(Pattern.compile("(?<![\\p{L}\\p{M}])"+word+"(?![\\p{L}\\p{M}])").matcher(meta).find())found=true;
            }
            if(found&&!row[0].equals(wanted))return false;
            if(found)match=true;
        }
        return match;
    }
}
