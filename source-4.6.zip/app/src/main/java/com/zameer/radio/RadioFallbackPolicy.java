package com.zameer.radio;
import java.util.*;
/** One failed station is never revisited within a failure chain; four bounded switches. */
final class RadioFallbackPolicy {
 private final Set<String> failed=new HashSet<>();private int switches;private long stableAt=-1;
 void reset(){failed.clear();switches=0;stableAt=-1;}
 void playing(boolean playing,long now){if(playing){if(stableAt<0)stableAt=now;}else{if(stableAt>=0&&now-stableAt>=60000)reset();stableAt=-1;}}
 int next(String current,List<String> urls,List<Integer> scores,boolean allowed,long now){if(!allowed)return -1;if(stableAt>=0&&now-stableAt>=60000)reset();stableAt=-1;failed.add(current);if(switches>=4)return -1;int best=-1,value=2;for(int i=0;i<urls.size();i++)if(!failed.contains(urls.get(i))&&scores.get(i)>value){best=i;value=scores.get(i);}if(best>=0)switches++;return best;}
}
