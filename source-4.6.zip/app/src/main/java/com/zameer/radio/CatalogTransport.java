package com.zameer.radio;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.concurrent.*;

/** Public JSON reads for mobile APIs; no cookies, credentials, redirects or arbitrary hosts. */
final class CatalogTransport {
    interface Listener {void result(String id,int status,String body);}
    private final Listener listener;
    private final ExecutorService pool=new ThreadPoolExecutor(2,2,0L,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(4));
    private final ConcurrentHashMap<String,Task> tasks=new ConcurrentHashMap<>();
    CatalogTransport(Listener listener){this.listener=listener;}
    private static final class Task {volatile boolean cancelled;volatile HttpURLConnection connection;volatile Future<?> future;}
    void request(String id,String url){
        if(id==null||!id.matches("[a-zA-Z0-9_-]{1,40}"))return;
        if(!CatalogUrlPolicy.allows(url)){listener.result(id,403,"");return;}
        Task task=new Task();if(tasks.putIfAbsent(id,task)!=null)return;
        try{task.future=pool.submit(()->{
            int status=503;String body="";
            try{
                if(task.cancelled)return;
                HttpURLConnection connection=(HttpURLConnection)new java.net.URL(url).openConnection();task.connection=connection;
                connection.setInstanceFollowRedirects(false);connection.setUseCaches(false);connection.setConnectTimeout(25000);connection.setReadTimeout(25000);
                connection.setRequestProperty("Accept","application/json");
                connection.setRequestProperty("User-Agent","ZameerRadio/3.9 (Android music player; com.zameer.radio)");
                if(task.cancelled)return;
                status=connection.getResponseCode();
                if(status==200){
                    try(InputStream input=connection.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream()){
                        byte[] buffer=new byte[8192];int n;
                        while((n=input.read(buffer))!=-1){if(task.cancelled)return;if(bytes.size()+n>2_000_000)throw new java.io.IOException("Catalog response too large");bytes.write(buffer,0,n);}
                        body=new String(bytes.toByteArray(),StandardCharsets.UTF_8);
                    }
                }
            }catch(Exception ignored){status=503;body="";}
            finally{if(task.connection!=null)task.connection.disconnect();tasks.remove(id,task);}
            if(!task.cancelled)listener.result(id,status,body);
        });if(task.cancelled)task.future.cancel(true);}catch(RejectedExecutionException e){tasks.remove(id,task);listener.result(id,429,"");}
    }
    void cancel(String id){Task task=tasks.remove(id);if(task!=null){task.cancelled=true;if(task.connection!=null)task.connection.disconnect();if(task.future!=null)task.future.cancel(true);}}
    void clear(){for(String id:tasks.keySet())cancel(id);}
    void close(){clear();pool.shutdownNow();}
}
