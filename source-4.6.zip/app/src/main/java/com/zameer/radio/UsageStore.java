package com.zameer.radio;
import android.content.SharedPreferences;
import org.json.*;
import java.util.*;
import java.text.SimpleDateFormat;
/** Private, bounded local diary; all callers serialize read/modify/write here. */
final class UsageStore {
 static synchronized String read(SharedPreferences p){return p.getString("radioUsage","{}");}
 static synchronized void clear(SharedPreferences p){p.edit().remove("radioUsage").putLong("usageReset",System.nanoTime()).apply();}
 private static String day(long time){return new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).format(new Date(time));}
 static synchronized void open(SharedPreferences p){if(!enabled(p))return;try{JSONObject log=new JSONObject(read(p)),d=log.optJSONObject(day(System.currentTimeMillis()));if(d==null)d=new JSONObject();d.put("opens",d.optInt("opens")+1);log.put(day(System.currentTimeMillis()),d);save(p,log);}catch(JSONException ignored){}}
 static boolean enabled(SharedPreferences p){return p.getBoolean("usageEnabled",true)&&!p.getBoolean("wipeWebData",false);}
 static synchronized void add(SharedPreferences p,long end,long millis,String id,String name,String tags,boolean foreground){if(!enabled(p)||millis<=0)return;try{JSONObject log=new JSONObject(read(p));long start=end-Math.min(millis,86400000L);while(start<end){Calendar c=Calendar.getInstance();c.setTimeInMillis(start);c.add(Calendar.DATE,1);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);long next=Math.min(end,c.getTimeInMillis()),amount=next-start;if(amount<=0)break;String date=day(start);JSONObject d=log.optJSONObject(date);if(d==null)d=new JSONObject();if(foreground)d.put("foregroundMs",d.optLong("foregroundMs")+amount);else if(id!=null&&!id.isEmpty()){JSONObject rows=d.optJSONObject("stations");if(rows==null)rows=new JSONObject();JSONObject row=rows.optJSONObject(id);if(row==null)row=new JSONObject();row.put("name",name).put("tags",tags).put("ms",row.optLong("ms")+amount);rows.put(id,row);d.put("stations",rows);}log.put(date,d);start=next;}save(p,log);}catch(JSONException ignored){}}
 private static void save(SharedPreferences p,JSONObject log){Calendar c=Calendar.getInstance();c.add(Calendar.DATE,-89);String oldest=day(c.getTimeInMillis());java.util.List<String> drop=new ArrayList<>();Iterator<String> it=log.keys();while(it.hasNext()){String k=it.next();if(k.compareTo(oldest)<0)drop.add(k);}for(String k:drop)log.remove(k);p.edit().putString("radioUsage",log.toString()).apply();}
}
