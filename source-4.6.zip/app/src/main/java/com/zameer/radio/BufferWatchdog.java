package com.zameer.radio;

/** Detect a stuck buffer, rather than discarding audio that is still arriving. */
final class BufferWatchdog {
    static final long POLL_MS=5_000, NO_PROGRESS_MS=30_000, MAX_WAIT_MS=90_000;
    private long started=-1, lastProgress=-1, buffered;
    void begin(long now,long bufferedMs){
        if(started>=0)return;
        started=lastProgress=now;buffered=Math.max(0,bufferedMs);
    }
    boolean stalled(long now,long bufferedMs){
        return stalled(now,bufferedMs,NO_PROGRESS_MS,MAX_WAIT_MS);
    }
    boolean stalled(long now,long bufferedMs,long noProgressMs,long maxWaitMs){
        begin(now,bufferedMs);
        if(bufferedMs>=buffered+250){buffered=bufferedMs;lastProgress=now;}
        return now-lastProgress>=noProgressMs||now-started>=maxWaitMs;
    }
    void reset(){started=lastProgress=-1;buffered=0;}
}
