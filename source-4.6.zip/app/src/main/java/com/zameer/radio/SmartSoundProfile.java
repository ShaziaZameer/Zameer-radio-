package com.zameer.radio;

import java.util.Locale;

/** Small, cut-only tone curves. These do not reconstruct missing audio or raise gain. */
final class SmartSoundProfile {
    static String choose(String tags) {
        String value=tags==null?"":tags.toLowerCase(Locale.ROOT);
        return java.util.regex.Pattern.compile("(?:^|[ ,;/])(news|talk|poetry|shayari|mushaira|naat|hamd)(?:$|[ ,;/])").matcher(value).find()?"speech":"music";
    }
    static short level(String profile,int frequencyMilliHz,short min,short max) {
        int hz=frequencyMilliHz/1000;
        int value="speech".equals(profile)?(hz<200?-300:hz<600?-150:hz>5000?-150:0)
            :(hz<100?-150:hz<400?-50:hz>8000?-100:0);
        return (short)Math.max(min,Math.min(max,value));
    }
}
