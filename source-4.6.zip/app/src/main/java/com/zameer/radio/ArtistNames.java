package com.zameer.radio;
import java.util.regex.Pattern;
final class ArtistNames {
    private static final String[][] ALIASES={
        {"रफी","mohammed rafi"},{"रफ़ी","mohammed rafi"},{"rafi","mohammed rafi"},{"लता","lata mangeshkar"},{"lata","lata mangeshkar"},{"किशोर","kishore kumar"},{"kishore","kishore kumar"},{"कुमार सानु","kumar sanu"},{"कुमार शानू","kumar sanu"},
        {"मुकेश","mukesh"},{"आशा भोसले","asha bhosle"},{"मन्ना डे","manna dey"},{"हेमंत कुमार","hemant kumar"},{"मोहित चौहान","mohit chauhan"},{"अभिजीत भट्टाचार्य","abhijeet bhattacharya"},{"सुखविंदर सिंह","sukhwinder singh"},{"नुसरत फतेह अली खान","nusrat fateh ali khan"},{"राहत फतेह अली खान","rahat fateh ali khan"},{"गुलाम अली","ghulam ali"},{"सुरेश वाडकर","suresh wadkar"},{"शंकर महादेवन","shankar mahadevan"},{"सुनिधि चौहान","sunidhi chauhan"},{"आतिफ असलम","atif aslam"},{"शान","shaan"},{"के के","kk"},{"केके","kk"},{"मुहम्मद रफी","mohammed rafi"},{"मुहम्मद रफ़ी","mohammed rafi"},{"मोहम्मद रफ़ी","mohammed rafi"},{"मोहम्मद रफी","mohammed rafi"},{"mohamed rafi","mohammed rafi"},{"mohd rafi","mohammed rafi"},
        {"अरिजीत सिंह","arijit singh"},{"किशोर कुमार","kishore kumar"},{"मोहम्मद रफी","mohammed rafi"},{"मोहम्मद रफ़ी","mohammed rafi"},{"mohammad rafi","mohammed rafi"},{"mohd rafi","mohammed rafi"},
        {"लता मंगेशकर","lata mangeshkar"},{"कुमार सानू","kumar sanu"},{"उदित नारायण","udit narayan"},{"अलका याग्निक","alka yagnik"},{"सोनू निगम","sonu nigam"},{"श्रेया घोषाल","shreya ghoshal"},{"जगजीत सिंह","jagjit singh"},{"पवन सिंह","pawan singh"},{"खेसारी लाल यादव","khesari lal yadav"},{"मनोज तिवारी","manoj tiwari"},{"अरिजीत","arijit singh"}
    };
    static String canonical(String value){
        String input=MusicRequest.normalize(value).replaceAll("[^\\p{L}\\p{M}\\p{N}]+"," ").trim().replaceAll("\\s+"," ");
        java.util.Map<String,String> aliases=new java.util.HashMap<>();
        for(String[] row:ALIASES){aliases.put(MusicRequest.normalize(row[0]),row[1]);aliases.put(row[1],row[1]);}
        java.util.List<String> keys=new java.util.ArrayList<>(aliases.keySet());keys.sort((a,b)->Integer.compare(b.length(),a.length()));
        String regex=ArtistCommand.join("|",java.util.Arrays.asList(keys.stream().map(Pattern::quote).toArray(String[]::new)));
        java.util.regex.Matcher matcher=Pattern.compile("(^| )("+regex+")(?= |$)").matcher(input);StringBuffer output=new StringBuffer();
        while(matcher.find())matcher.appendReplacement(output,java.util.regex.Matcher.quoteReplacement(matcher.group(1)+aliases.get(matcher.group(2))));
        return matcher.appendTail(output).toString();
    }
    static java.util.List<String> suggestions(String value){
        String input=canonical(value).replace("़","");if(known(value)||input.length()<4||input.length()>80)return java.util.Collections.emptyList();
        java.util.Map<String,Integer> scores=new java.util.HashMap<>();
        for(String[] row:ALIASES)for(String alias:row){String candidate=MusicRequest.normalize(alias).replace("़","");int limit=Math.min(input.length(),candidate.length())>=8?2:1;if(Math.abs(input.length()-candidate.length())>limit)continue;
            int[] d=new int[candidate.length()+1];for(int j=0;j<d.length;j++)d[j]=j;
            for(int i=1;i<=input.length();i++){int previous=d[0];d[0]=i;for(int j=1;j<d.length;j++){int old=d[j];d[j]=Math.min(Math.min(d[j]+1,d[j-1]+1),previous+(input.charAt(i-1)==candidate.charAt(j-1)?0:1));previous=old;}}
            int score=d[candidate.length()];if(score<=limit)scores.put(row[1],Math.min(score,scores.getOrDefault(row[1],99)));
        }
        java.util.List<String> names=new java.util.ArrayList<>(scores.keySet());names.sort((a,b)->scores.get(a).equals(scores.get(b))?a.compareTo(b):Integer.compare(scores.get(a),scores.get(b)));return names.subList(0,Math.min(3,names.size()));
    }
    static boolean known(String value){String key=canonical(value);for(String[] alias:ALIASES)if(alias[1].equals(key))return true;return false;}
    static boolean matches(String actual,String requested){String a=" "+canonical(actual)+" ",wanted=canonical(requested);if(wanted.isEmpty())return false;for(String word:wanted.split(" "))if(!a.contains(" "+word+" "))return false;return true;}
}
