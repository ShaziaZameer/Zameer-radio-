package com.zameer.radio;

/** Main-thread-only, last intention wins while the media controller connects. */
final class PendingPlayerAction {
    private Runnable pending;
    void replace(Runnable action) { pending=action; }
    boolean clear() { boolean had=pending!=null; pending=null; return had; }
    void run() { Runnable action=pending; pending=null; if(action!=null)action.run(); }
}
