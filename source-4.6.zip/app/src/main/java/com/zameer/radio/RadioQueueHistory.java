package com.zameer.radio;
import java.util.*;
/** Attempted stations belong to the current queue, not to recommendation ranking. */
final class RadioQueueHistory {
 private final Set<String> visited=new HashSet<>();
 private final Random random;
 RadioQueueHistory(){this(new Random());}
 RadioQueueHistory(Random random){this.random=random;}
 synchronized void reset(){visited.clear();}
 synchronized void visit(String url){if(url!=null&&!url.isEmpty())visited.add(url);}
 synchronized boolean contains(String url){return visited.contains(url);}
 synchronized int next(List<String> urls,int current){for(int step=1;step<=urls.size();step++){int i=(Math.max(-1,current)+step)%urls.size();if(i!=current&&!visited.contains(urls.get(i)))return i;}return -1;}
 synchronized int next(List<String> urls,int current,boolean shuffle){
  if(!shuffle)return next(urls,current);
  List<Integer> candidates=new ArrayList<>();
  for(int i=0;i<urls.size();i++)if(i!=current&&!visited.contains(urls.get(i)))candidates.add(i);
  return candidates.isEmpty()?-1:candidates.get(random.nextInt(candidates.size()));
 }
 synchronized int step(List<String> urls,int current,int direction,boolean shuffle){
  if(urls.isEmpty())return -1;
  if(direction<0)return (current>0?current:urls.size())-1;
  if(!shuffle)return (current+1)%urls.size();
  int result=next(urls,current,true);
  if(result<0){visited.clear();if(current>=0&&current<urls.size())visit(urls.get(current));result=next(urls,current,true);}
  return result<0?Math.max(0,current):result;
 }
}
