package com.zameer.radio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;

/** Explicit, foreground-only voice sessions. No external voice-search Activity. */
final class VoiceInput {
    static final int PERMISSION_REQUEST = 104;
    interface Host {
        void pausePlayback();
        void status(String message);
        void result(String text);
        void typeInstead();
    }
    private final Activity activity;
    private final Host host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private AlertDialog dialog;
    private boolean pendingPermission, active, onDevice, english, waitingForResult;
    private String partialText = "";
    private int generation;

    VoiceInput(Activity activity, Host host) { this.activity = activity; this.host = host; }
    private String text(String hi, String en) { return english ? en : hi; }

    void start() {
        if (pendingPermission || active || dialog != null || activity.isFinishing()) return;
        english = "en".equals(AppLanguage.code(activity));
        if (activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingPermission = true;
            host.status(text("बोलकर आदेश देने के लिए माइक की अनुमति दें।", "Allow microphone access for voice commands."));
            activity.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST);
            return;
        }
        show();
    }

    void permissionResult(int[] grants) {
        if (!pendingPermission) return; // Ignore permission results after leaving the app.
        pendingPermission = false;
        if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) show();
        else host.status(text("माइक की अनुमति नहीं मिली। आदेश लिखें या ऐप की अनुमति में माइक चालू करें।", "Microphone permission was not granted. Type a command or allow it in app permissions."));
    }

    private void show() {
        if (activity.isFinishing() || activity.isDestroyed()) return;
        host.pausePlayback();
        dialog = new AlertDialog.Builder(activity)
            .setTitle(text("बोलकर आदेश दें", "Give a voice command"))
            .setMessage(text("माइक तैयार हो रहा है…", "Preparing microphone…"))
            .setPositiveButton(text("फिर कोशिश करें", "Try again"), null)
            .setNegativeButton(text("रद्द करें", "Cancel"), (d, w) -> {})
            .setNeutralButton(text("लिखकर चलाएँ", "Type instead"), (d, w) -> {
                cancel(); host.typeInstead();
            }).create();
        dialog.setOnDismissListener(d -> {
            release(); dialog = null;
            host.status(text("वॉइस बंद है। फिर सुनने के लिए प्ले दबाएँ या आदेश दें।", "Voice is off. Press Play or give a command to continue."));
        });
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (!partialText.isEmpty()) complete(partialText); // Explicit user confirmation only.
            else if (active) finishListening();
            else begin(false);
        });
        begin(false);
    }

    private void release() {
        active = false; generation++;
        handler.removeCallbacksAndMessages(null);
        SpeechRecognizer old = recognizer; recognizer = null;
        if (old != null) {
            try { old.cancel(); } catch (RuntimeException ignored) {}
            try { old.destroy(); } catch (RuntimeException ignored) {}
        }
    }

    void cancel() {
        pendingPermission = false;
        release();
        if (dialog != null) { AlertDialog old = dialog; dialog = null; old.dismiss(); }
    }

    private void update(String message) {
        if (dialog != null) dialog.setMessage(message);
        host.status(message);
    }

    private void begin(boolean local) {
        release();
        if (dialog == null) return;
        onDevice = local; waitingForResult = false; partialText = "";
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText(text("बोलना पूरा", "Done speaking"));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
        update(text("माइक तैयार हो रहा है…", "Preparing microphone…"));
        try {
            if (!local && !SpeechRecognizer.isRecognitionAvailable(activity)) {
                if (hasLocalService()) { begin(true); return; }
                fail(text("फोन में वॉइस पहचान सेवा उपलब्ध नहीं है। नीचे ‘लिखकर चलाएँ’ चुनें।", "No speech recognition service is available. Choose Type instead.")); return;
            }
            recognizer = local && Build.VERSION.SDK_INT >= 31
                ? SpeechRecognizer.createOnDeviceSpeechRecognizer(activity)
                : SpeechRecognizer.createSpeechRecognizer(activity);
            final int token = generation;
            active = true;
            recognizer.setRecognitionListener(new RecognitionListener() {
                private boolean current() { return active && token == generation && dialog != null; }
                public void onReadyForSpeech(Bundle params) {
                    if (current()) update(text("अब बोलें… जैसे ‘अगला गाना’ या ‘गाना रोक दो’।", "Speak now… for example ‘next song’ or ‘pause music’."));
                }
                public void onBeginningOfSpeech() {
                    if (current()) update(text("आवाज़ मिल रही है… आदेश बोलकर ‘बोलना पूरा’ दबा सकते हैं।", "Speech detected… say your command, then you can tap Done speaking."));
                }
                public void onRmsChanged(float rmsdB) {}
                public void onBufferReceived(byte[] buffer) {}
                public void onEndOfSpeech() {
                    if (current()) awaitFinalResult();
                }
                public void onError(int error) { if (current()) error(error); }
                public void onResults(Bundle results) {
                    if (!current()) return;
                    String value = recognizedText(results);
                    if (value.isEmpty()) { error(SpeechRecognizer.ERROR_NO_MATCH); return; }
                    complete(value);
                }
                public void onPartialResults(Bundle results) {
                    if (!current()) return;
                    String value = recognizedText(results);
                    if (value.isEmpty()) return;
                    partialText = value;
                    update(text("सुना: “", "Heard: “") + value + text("”\nआदेश सही है तो ‘यह आदेश चलाएँ’ दबाएँ, या बोलना जारी रखें।", "”\nIf this is your complete command, tap Run this command, or keep speaking."));
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText(text("यह आदेश चलाएँ", "Run this command"));
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                }
                public void onEvent(int eventType, Bundle params) {}
            });
            Intent request = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, english ? "en-IN" : "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            recognizer.startListening(request);
            handler.postDelayed(() -> {
                if (active && token == generation) finishListening();
            }, 15000);
        } catch (SecurityException e) {
            error(SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS);
        } catch (RuntimeException e) {
            error(SpeechRecognizer.ERROR_CLIENT);
        }
    }

    private String recognizedText(Bundle results) {
        ArrayList<String> words = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        String value = words == null || words.isEmpty() || words.get(0) == null ? "" : words.get(0).trim();
        return value.substring(0, Math.min(160, value.length()));
    }

    private void complete(String value) {
        if (dialog == null || value.isEmpty()) return;
        cancel(); partialText = ""; host.result(value);
    }

    private void finishListening() {
        if (!active || recognizer == null || waitingForResult) return;
        awaitFinalResult();
        try { recognizer.stopListening(); }
        catch (RuntimeException e) { error(SpeechRecognizer.ERROR_CLIENT); }
    }

    private void awaitFinalResult() {
        if (!active || waitingForResult) return;
        waitingForResult = true;
        handler.removeCallbacksAndMessages(null);
        if (partialText.isEmpty()) {
            update(text("बोलना पूरा। आदेश का अंतिम परिणाम ले रहे हैं…", "Speech ended. Waiting for the final command…"));
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
        }
        final int token = generation;
        handler.postDelayed(() -> {
            if (active && token == generation) error(SpeechRecognizer.ERROR_NETWORK_TIMEOUT);
        }, 7000);
    }

    private boolean hasLocalService() {
        try { return Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(activity); }
        catch (RuntimeException e) { return false; }
    }

    private void error(int code) {
        // One alternative engine attempt, never a restart loop or hidden model download.
        if (partialText.isEmpty() && VoiceRetryPolicy.useOnDevice(onDevice, code) && hasLocalService()) {
            release();
            update(text("फोन की स्थानीय वॉइस पहचान आज़मा रहे हैं…", "Trying on-device speech recognition…"));
            final int token = generation;
            handler.postDelayed(() -> { if (dialog != null && token == generation) begin(true); }, 300);
            return;
        }
        String reason;
        switch (code) {
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                reason = text("माइक की अनुमति नहीं मिली। ऐप की अनुमति में माइक देखें।", "Microphone access was not granted. Check this app's microphone permission."); break;
            case SpeechRecognizer.ERROR_AUDIO:
                reason = text("माइक से आवाज़ नहीं मिल रही। कॉल या दूसरी रिकॉर्डिंग बंद करके फिर कोशिश करें।", "Microphone audio is unavailable. End calls or other recording, then try again."); break;
            case SpeechRecognizer.ERROR_NETWORK: case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                reason = text("वॉइस सेवा का नेटवर्क उत्तर नहीं मिला। इंटरनेट आने पर फिर कोशिश करें।", "The speech service did not respond over the network. Try again when connected."); break;
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED: case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE:
                reason = text("इस वॉइस सेवा में हिंदी अभी उपलब्ध नहीं है। ‘लिखकर चलाएँ’ चुनें; कीबोर्ड का माइक भी इस्तेमाल कर सकते हैं।", "English (India) is unavailable in this speech service. Choose Type instead; you can also use the keyboard microphone."); break;
            case SpeechRecognizer.ERROR_NO_MATCH: case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                reason = text("आवाज़ समझ नहीं आई। ‘फिर कोशिश करें’ दबाकर छोटा आदेश बोलें।", "Speech was not recognized. Tap Try again and say a short command."); break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: case SpeechRecognizer.ERROR_TOO_MANY_REQUESTS:
                reason = text("वॉइस सेवा व्यस्त है। थोड़ी देर बाद फिर कोशिश करें।", "The speech service is busy. Try again shortly."); break;
            default:
                reason = text("फोन की वॉइस सेवा शुरू नहीं हो सकी। ‘लिखकर चलाएँ’ चुनें; कीबोर्ड का माइक भी इस्तेमाल कर सकते हैं।", "The phone's speech service could not start. Choose Type instead; you can also use the keyboard microphone.");
        }
        fail(reason + " (" + code + ")");
    }

    private void fail(String message) {
        release();
        if (!partialText.isEmpty()) message += text("\nसुना: “", "\nHeard: “") + partialText + text("”\nसही हो तो ‘यह आदेश चलाएँ’ दबाएँ।", "”\nIf correct, tap Run this command.");
        update(message);
        if (dialog != null) {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText(partialText.isEmpty() ? text("फिर कोशिश करें", "Try again") : text("यह आदेश चलाएँ", "Run this command"));
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
        }
    }
}
