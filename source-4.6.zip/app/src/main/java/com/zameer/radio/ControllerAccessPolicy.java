package com.zameer.radio;

/** Caller identity comes from Android/Media3, never from WebView or voice text. */
final class ControllerAccessPolicy {
    static boolean allowed(int ownUid,int callerUid,boolean systemTrusted) {
        return ownUid==callerUid || systemTrusted;
    }
}
