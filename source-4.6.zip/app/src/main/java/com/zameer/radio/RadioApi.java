package com.zameer.radio;

import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.*;

/** Bounded directory requests. Only the explicit owner-submit action uses POST. */
final class RadioApi {
    private static final String[] HOSTS={"de1.api.radio-browser.info","nl1.api.radio-browser.info","at1.api.radio-browser.info"};
    static String request(String path, JSONObject params, String method) throws Exception {
        boolean post="POST".equals(method);
        if(!(post&&"/json/add".equals(path)||"GET".equals(method)&&("/json/stations/search".equals(path)||"/json/stations/byurl".equals(path))))throw new IllegalArgumentException("Unsupported request");
        StringBuilder form=new StringBuilder();
        java.util.Iterator<String> keys=params.keys();
        while(keys.hasNext()) {String key=keys.next();if(!java.util.Arrays.asList("name","url","homepage","countrycode","state","language","tags","tag","tagList","has_geo_info","hidebroken","is_https","limit","offset","order","reverse").contains(key))throw new IllegalArgumentException("Invalid field");
            String value=params.optString(key);if(value.length()>2000)throw new IllegalArgumentException("Field too long");
            if(form.length()>0)form.append('&');form.append(URLEncoder.encode(key,"UTF-8")).append('=').append(URLEncoder.encode(value,"UTF-8"));}
        if(post&&(!RadioMatch.publicUrl(params.optString("url"))||params.optString("name").trim().isEmpty()))throw new IllegalArgumentException("Station invalid");
        Exception last=new IOException("Directory unavailable");long deadline=android.os.SystemClock.elapsedRealtime()+22000;
        // Mutations must never automatically retry on another server after an uncertain reply.
        for(int i=0;i<(post?1:HOSTS.length);i++) {
            if(Thread.currentThread().isInterrupted())throw new InterruptedException();
            int timeout=(int)Math.min(6500,deadline-android.os.SystemClock.elapsedRealtime());if(timeout<500)break;
            HttpURLConnection c=null;
            try {c=(HttpURLConnection)new URL("https://"+HOSTS[i]+path+(post?"":"?"+form)).openConnection();
                c.setRequestMethod(method);c.setConnectTimeout(timeout);c.setReadTimeout(timeout);c.setInstanceFollowRedirects(false);
                c.setRequestProperty("User-Agent","ZameerRadio/4.3 (Android; com.zameer.radio)");c.setRequestProperty("Accept","application/json");
                if(post){byte[] bytes=form.toString().getBytes(StandardCharsets.UTF_8);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}}
                int code=c.getResponseCode();if(code<200||code>=300)throw new IOException("Directory HTTP "+code);
                ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(Thread.currentThread().isInterrupted()||android.os.SystemClock.elapsedRealtime()>deadline)throw new IOException("Request expired");if(out.size()+n>4_000_000)throw new IOException("Response too large");out.write(buf,0,n);}}
                String result=out.toString("UTF-8");if(post)new JSONObject(result);else new JSONArray(result);return result;
            }catch(Exception e){last=e;}finally{if(c!=null)c.disconnect();}
        }throw last;
    }
    static JSONArray discover(String query) throws Exception {
        JSONObject params=parameters(query);JSONArray rows=new JSONArray(request("/json/stations/search",params,"GET"));
        if(rows.length()>0)return rows;
        String mood=RadioMatch.mood(RadioMatch.normalize(query));
        if(!mood.isEmpty()) {params.remove("language");params.remove("tag");params.put("name",mood.equals("ghazal")?"gazal":mood);rows=new JSONArray(request("/json/stations/search",params,"GET"));}
        return rows;
    }
    static JSONObject parameters(String query) throws JSONException {
        String q=RadioMatch.normalize(query);JSONObject o=new JSONObject().put("hidebroken","true").put("is_https","true").put("limit","100").put("order","votes").put("reverse","true");
        String language=RadioMatch.language(q);if(language.isEmpty())o.put("language","hindi");if(!language.isEmpty()){o.put("language",language);q=q.replace(language,"").trim();}
        String decade=RadioMatch.decade(q);if(!decade.isEmpty())return o.put("tag",decade.substring(2)+"s");String tag=RadioMatch.mood(q);if(!tag.isEmpty())o.put("tag",tag);else if(!q.isEmpty())o.put("name",q);return o;
    }
}
