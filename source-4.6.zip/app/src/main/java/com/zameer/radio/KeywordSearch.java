package com.zameer.radio;

import java.util.*;

/** Related command results use actual title/artist/tags, never language alone. */
final class KeywordSearch {
    private static final Map<String,String> ALIASES=new HashMap<>();
    private static final Set<String> NOISE=new HashSet<>(Arrays.asList(("play playing song songs music track tracks audio video online please some a an the of in on for by and with to me my now official गाना गाने गीत गीतों संगीत म्यूजिक ऑनलाइन चलाओ बजाओ सुनाओ मुझे मेरा मेरी मेरे कोई कुछ अच्छे अच्छा वाली वाले वाला के की का में से पर और भी ही यह ये एक है हैं करो दीजिए सुनना सुनाओ").split(" ")));
    static {
        String[][] groups={{"bollywood","बॉलीवुड","बालीवुड","बॉलीवूड","bollywod","फिल्मी","फ़िल्मी","फिल्म","फ़िल्म","filmi","filmy","films","film","movies","movie"},{"retro","पुराने","पुराना","पुरानी","old","oldies"},{"romantic","रोमांटिक","रोमांस"},{"bhajan","भजन"},{"devotional","भक्ति"},{"dance","डांस"},{"party","पार्टी"},{"ghazal","ग़ज़ल","गजल","ग़ज़लें","gazal","गजलें"},{"qawwali","कव्वाली"},{"sufi","सूफी","सुफी"}};
        for(String[] group:groups)for(String word:group)ALIASES.put(MusicRequest.normalize(word),group[0]);
        for(String[] group:MusicRequest.LANGUAGES)NOISE.addAll(Arrays.asList(group));
    }
    static String canonical(String value){List<String> out=new ArrayList<>();for(String word:MusicRequest.normalize(value).split(" "))out.add(ALIASES.getOrDefault(word,word));return String.join(" ",out);}
    static List<String> words(String value){LinkedHashSet<String> out=new LinkedHashSet<>();for(String word:MusicRequest.normalize(value).replaceAll("[^\\p{L}\\p{M}\\p{N}]+"," ").split(" "))if(!word.isEmpty()&&!NOISE.contains(word))out.add(ALIASES.getOrDefault(word,word));return new ArrayList<>(out);}
    static int score(String title,String artist,String tags,String kind,String query){
        if(kind.isEmpty()||"artistRadio".equals(kind))return 0;
        int match=SmartSearch.match(title,query);if(match==2)return 100;if(match==1)return 70;
        Set<String> actual=new HashSet<>();for(String word:words(title+" "+artist+" "+tags))actual.add(SmartSearch.key(word));
        int count=0,total=0;for(String word:words(query)){String key=SmartSearch.key(word);if(key.length()<3)continue;total++;if(actual.contains(key))count++;}
        return count==0?0:20+40*count/Math.max(1,total);
    }
    static List<String> variants(String query){
        String q=String.join(" ",words(query));if(q.isEmpty())q=query.trim();LinkedHashSet<String> found=new LinkedHashSet<>();found.add(q);
        if(q.equals("bollywood"))found.addAll(Arrays.asList("बॉलीवुड","filmi","film"));
        else {List<String> scripts=SmartSearch.variants(q);for(int i=1;i<Math.min(3,scripts.size());i++)found.add(scripts.get(i));List<String> words=words(q);words.sort((a,b)->Integer.compare(b.length(),a.length()));found.addAll(words);}
        found.remove("");return new ArrayList<>(found).subList(0,Math.min(6,found.size()));
    }
}
