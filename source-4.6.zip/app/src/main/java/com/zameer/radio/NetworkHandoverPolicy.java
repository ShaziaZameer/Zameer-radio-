package com.zameer.radio;

/** Reconnect a stalled socket after a validated network change, without touching flowing audio. */
final class NetworkHandoverPolicy {
    private String network="";
    private boolean lost;
    private long changedAt=-1,progressAt=-1,buffered,lastReconnect=-1;
    void validated(String key,long now){
        if(key==null||key.isEmpty())return;
        if((!network.isEmpty()&&!network.equals(key))||lost){changedAt=now;progressAt=-1;}
        network=key;lost=false;
    }
    void lost(String key){if(network.equals(key))lost=true;}
    void cancel(){changedAt=progressAt=-1;}
    boolean reconnect(long now,long bufferedMs){
        if(changedAt<0)return false;
        if(now-changedAt>30_000){cancel();return false;}
        if(progressAt<0||bufferedMs>=buffered+250){progressAt=now;buffered=bufferedMs;return false;}
        if(now-progressAt<4_000||lastReconnect>=0&&now-lastReconnect<20_000)return false;
        lastReconnect=now;cancel();return true;
    }
}
