package com.zameer.radio;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Explicit artist + mood/era grammar. No probabilistic audio/artist identification. */
final class ArtistCommand {
    final String artist,language;
    final List<String> filters;
    final boolean followup;
    ArtistCommand(String artist,String language,List<String> filters,boolean followup){this.artist=artist;this.language=language;this.filters=filters;this.followup=followup;}
    static String join(String delimiter,java.util.List<String> parts){StringBuilder out=new StringBuilder();for(String part:parts){if(out.length()>0)out.append(delimiter);out.append(part.startsWith("decade")?part.substring(6)+"s":part);}return out.toString();}
    static ArtistCommand parse(String input){
        String s=MusicRequest.normalize(input),artist="",words="";boolean follow=false;
        Matcher m=Pattern.compile("^(.+?) (?:के|की|का) (.*?)\\s*(?:गाने|गीत|गाना|संगीत)$").matcher(s);
        if(m.matches()){artist=m.group(1);words=m.group(2);follow=artist.matches("(?:इसी|इस|उस) (?:कलाकार|गायक)");}
        else if((m=Pattern.compile("^(?:इनके|उनके|उसी के) (.*?)\\s*(?:गाने|गीत|गाना)$").matcher(s)).matches()){follow=true;words=m.group(1);}
        else if((m=Pattern.compile("^(.*?)\\s*(?:songs?|music) (?:by|of) (.+)$").matcher(s)).matches()){words=m.group(1);artist=m.group(2);follow=artist.matches("(?:(?:this|the same) artist|him|her|them)");}
        else return null;
        if(!follow&&words.isEmpty())return null;
        List<String> filters=new ArrayList<>();String language="";
        Matcher decades=Pattern.compile("(?:19|20)\\d0s|(?:19|20)\\d0 के दशक|90s|90 के दशक").matcher(words);while(decades.find()){String v=decades.group();filters.add("decade"+(v.startsWith("90")?1990:Integer.parseInt(v.substring(0,4))));}words=decades.replaceAll(" ");
        for(String word:words.split(" ")){
            if(word.isEmpty())continue;String mood=modifier(word);
            if(!mood.isEmpty()){if(!filters.contains(mood))filters.add(mood);continue;}
            String code="";for(String[] row:MusicRequest.LANGUAGES)for(int i=1;i<row.length;i++)if(row[i].equals(word))code=row[0];
            if(code.isEmpty()||!language.isEmpty()&&!language.equals(code))return null;language=code;
        }
        return new ArtistCommand(artist,language,filters,follow);
    }
    private static String modifier(String word){
        if(word.matches("पुराने|पुराना|पुरानी|old|oldies|retro"))return "retro";
        if(word.matches("रोमांटिक|रोमांस|romantic|romance"))return "romantic";
        if(word.matches("सुकून|शांत|calm|relaxing"))return "calm";
        if(word.matches("उदास|sad"))return "sad";
        if(word.matches("खुशी|happy"))return "happy";
        if(word.matches("भक्ति|devotional"))return "devotional";
        if(word.matches("पार्टी|party"))return "party";
        if(word.matches("पढ़ाई|focus|study"))return "focus";
        if(word.matches("कसरत|workout"))return "workout";
        if(word.matches("ध्यान|meditation"))return "meditation";
        return "";
    }
    static boolean matches(String title,String tags,String kind,List<String> filters){
        if(filters.isEmpty())return true;
        if(kind.isEmpty()||"artistRadio".equals(kind))return false;
        String info=MusicRequest.normalize(title+" "+tags).replaceAll("[_./-]"," ");
        for(String filter:filters){String regex;
            if(filter.matches("decade(?:19|20)\\d0")){int d=Integer.parseInt(filter.substring(6));Matcher years=Pattern.compile("\\b(?:19|20)\\d{2}\\b").matcher(info);boolean found=false;while(years.find()){int y=Integer.parseInt(years.group());found|=y>=d&&y<d+10;}if(!found&&!info.contains(d+"s")&&!(d==1990&&Pattern.compile("\\b90s\\b").matcher(info).find()))return false;continue;}
            switch(filter){
                case "retro":regex="\\b(old|oldies|retro|classic|golden|nostalgic|evergreen)\\b|पुरान[ेाी]";break;
                case "romantic":regex="\\b(romantic|romance|love|tender|pyar|pyaar|mohabbat|prem|piya|sajan|saiyan)\\b|रोमांटिक|प्यार|मोहब्बत|प्रेम|पिया|साजन";break;
                case "calm":regex="\\b(relax|ambient|chill|peaceful|soft|classical|calm)\\b|सुकून|शांत|मधुर";break;
                case "sad":regex="\\b(sad|bewafa|birha|virah|melancholy|heartbreak|emotional|yearning)\\b|उदास|दर्द|बेवफा|विरह|बिरहा";break;
                case "happy":regex="\\b(happy|cheerful|uplifting|joy|joyful|upbeat)\\b|खुशी|खुशियाँ";break;
                case "devotional":regex="\\b(bhakti|bhajan|chhath|chhat|devotional|spiritual|religious|mantra|kirtan|aart[iy])\\b|भक्ति|भजन|आरती|कीर्तन|देवी|छठ";break;
                case "party":regex="\\b(party|dance|edm|house|disco|celebration)\\b|पार्टी|नाच";break;
                case "focus":regex="\\b(focus|study|lofi|lo fi|instrumental|concentration)\\b|पढ़ाई|एकाग्रता|वाद्य";break;
                case "workout":regex="\\b(workout|gym|running|fitness|energetic|powerful)\\b|कसरत|व्यायाम";break;
                case "meditation":regex="\\b(meditation|meditative|mantra|zen|healing|peaceful)\\b|ध्यान|मंत्र";break;
                default:return false;
            }
            if(!Pattern.compile(regex).matcher(info).find())return false;
        }
        return true;
    }
}
