package com.zameer.radio;

/** Current broadcast information only; never persists audio or a listening history. */
final class RadioNowPlaying {
    static final class Info {
        final String id, raw, title, artist, album, source;
        final long updatedAt;
        Info(String id,String raw,String title,String artist,String album,String source,long at){this.id=id;this.raw=raw;this.title=title;this.artist=artist;this.album=album;this.source=source;this.updatedAt=at;}
    }
    private String id="", station="";
    private boolean radio;
    private Info info=new Info("","","","","","",0);
    static String clean(String value){
        if(value==null)return "";
        String text=value.replaceAll("[\\p{Cntrl}\\u202A-\\u202E\\u2066-\\u2069]"," ").replaceAll("\\s+"," ").trim();
        return text.substring(0,Math.min(400,text.length()));
    }
    static boolean useful(String value){return !value.isEmpty()&&!value.matches("(?i)unknown(?:\\s*[-–]\\s*unknown)?|undefined|null|n/?a|untitled|stream|live");}
    synchronized void reset(String mediaId,String kind,String stationName){
        id=mediaId==null?"":mediaId;station=clean(stationName);radio=!id.isEmpty()&&(kind==null||kind.isEmpty()||"artistRadio".equals(kind));
        info=new Info(id,"","","","","",0);
    }
    synchronized void icy(String mediaId,String value,long at){
        if(!radio||!id.equals(mediaId))return;
        String raw=clean(value);
        if(!useful(raw)||raw.equalsIgnoreCase(station)){info=new Info(id,"","","","","",0);return;}
        // ICY provides one string; its artist/title order is not standardized. Do not guess.
        info=new Info(id,raw,"","","","ICY",at);
    }
    synchronized void id3(String mediaId,String title,String artist,String album,long at){
        if(!radio||!id.equals(mediaId))return;
        title=clean(title);artist=clean(artist);album=clean(album);
        if(!useful(title)||title.equalsIgnoreCase(station)){info=new Info(id,"","","","","",0);return;}
        info=new Info(id,title,title,useful(artist)?artist:"",useful(album)?album:"","ID3",at);
    }
    synchronized Info snapshot(String mediaId){return radio&&id.equals(mediaId)?info:new Info("","","","","","",0);}
}
