package com.zameer.radio;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

/** Bounded Hindi/Roman matching. No remote inference, invented metadata or lyrics index. */
final class SmartSearch {
    private static final String[] CONS={"k","kh","g","gh","n","ch","chh","j","jh","n","t","th","d","dh","n","t","th","d","dh","n","","p","ph","b","bh","m","y","r","","l","","","v","sh","sh","s","h"};
    private static final Map<Character,String> VOWELS=new HashMap<>(),MATRAS=new HashMap<>(),NUKTA=new HashMap<>();
    static {put(VOWELS,"अ आ इ ई उ ऊ ऋ ए ऐ ओ औ","a aa i ii u uu ri e ai o au");put(MATRAS,"ा ि ी ु ू ृ े ै ो ौ","aa i ii u uu ri e ai o au");put(NUKTA,"क ख ग ज ड ढ फ य","q kh g z r rh f y");}
    private static void put(Map<Character,String> map,String a,String b){String[] keys=a.split(" "),values=b.split(" ");for(int i=0;i<keys.length;i++)map.put(keys[i].charAt(0),values[i]);}
    private static String consonant(char c){int i=c-'क';return i>=0&&i<CONS.length?CONS[i]:"";}
    static String romanize(String value){
        String s=Normalizer.normalize(value==null?"":value,Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);StringBuilder out=new StringBuilder();
        for(int i=0;i<s.length();i++){char c=s.charAt(i);String sound=consonant(c);
            if(!sound.isEmpty()){if(i+1<s.length()&&s.charAt(i+1)=='़'){sound=NUKTA.getOrDefault(c,sound);i++;}out.append(sound);
                if(i+1<s.length()&&s.charAt(i+1)=='्'){i++;continue;}
                if(i+1<s.length()&&MATRAS.containsKey(s.charAt(i+1)))out.append(MATRAS.get(s.charAt(++i)));
                else if(i+1<s.length()&&s.charAt(i+1)>='\u0900'&&s.charAt(i+1)<='\u097f')out.append('a');
            }else if(VOWELS.containsKey(c))out.append(VOWELS.get(c));else if(c=='ं'||c=='ँ')out.append('n');else if(c=='ः')out.append('h');else if(c>='०'&&c<='९')out.append((char)('0'+c-'०'));else if(c=='।'||c=='॥')out.append(' ');else if(c!='़'&&c!='्')out.append(c);
        }
        return out.toString().replaceAll("[^\\p{L}\\p{M}\\p{N}]+"," ").trim().replaceAll("\\s+"," ");
    }
    static String key(String value){return romanize(value).replace("aa","a").replaceAll("ee|ii","i").replaceAll("oo|uu","u").replace('w','v').replace("ph","f");}
    static String titleKey(String value){List<String> words=new ArrayList<>();for(String w:key(value).split(" "))if(!Arrays.asList("hindi","official","audio","video","mp3").contains(w))words.add(w);return String.join(" ",words);}
    static int distance(String a,String b){if(Math.abs(a.length()-b.length())>2)return 3;int[] prev=new int[b.length()+1];for(int j=0;j<prev.length;j++)prev[j]=j;for(int i=1;i<=a.length();i++){int[] row=new int[b.length()+1];row[0]=i;for(int j=1;j<=b.length();j++)row[j]=Math.min(Math.min(row[j-1]+1,prev[j]+1),prev[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));prev=row;}return prev[b.length()];}
    /** 2: strong title; 1: suggestion only; 0: unrelated. */
    static int match(String title,String query){String a=titleKey(title),b=titleKey(query);if(a.isEmpty()||b.isEmpty())return 0;if(a.equals(b))return 2;String[] actual=a.split(" "),wanted=b.split(" ");if(wanted.length>12)return 0;Set<Integer> used=new HashSet<>();int errors=0;
        for(String word:wanted){int best=-1,cost=99;for(int i=0;i<actual.length;i++){if(used.contains(i))continue;int d=word.equals(actual[i])?0:Math.max(word.length(),actual[i].length())>=4&&Math.min(word.length(),actual[i].length())>=3?distance(word,actual[i]):99;if(d<cost){cost=d;best=i;}}if(best<0||cost>1)return 0;used.add(best);errors+=cost;}return errors>1?0:1;
    }
    private static final String[] ROMAN_C={"chh","kh","gh","ch","jh","th","dh","ph","bh","sh","ng","ny","k","g","j","t","d","n","p","f","b","m","y","r","l","v","w","s","h","q","z"};
    private static final String[] DEVA_C={"छ","ख","ग","च","झ","थ","ध","फ","भ","श","ं","ञ","क","ग","ज","त","द","न","प","फ़","ब","म","य","र","ल","व","व","स","ह","क","ज़"};
    private static final String[] ROMAN_V={"aa","ee","ii","oo","uu","ai","au","a","i","u","e","o"},DEVA_V={"आ","ई","ई","ऊ","ऊ","ऐ","औ","अ","इ","उ","ए","ओ"},DEVA_M={"ा","ी","ी","ू","ू","ै","ौ","","ि","ु","े","ो"};
    private static int prefix(String s,int i,String[] keys){for(int k=0;k<keys.length;k++)if(s.startsWith(keys[k],i))return k;return -1;}
    static String devanagari(String value,boolean longEnding){Matcher m=Pattern.compile("[a-z]+").matcher(value.toLowerCase(Locale.ROOT));StringBuffer out=new StringBuffer();while(m.find()){String word=m.group();StringBuilder b=new StringBuilder();int i=0;while(i<word.length()){int v=prefix(word,i,ROMAN_V);if(v>=0){b.append(DEVA_V[v]);i+=ROMAN_V[v].length();continue;}int c=prefix(word,i,ROMAN_C);if(c<0){b.append(word.charAt(i++));continue;}b.append(DEVA_C[c]);i+=ROMAN_C[c].length();v=prefix(word,i,ROMAN_V);if(v>=0){i+=ROMAN_V[v].length();b.append(i==word.length()&&ROMAN_V[v].equals("a")?"ा":longEnding&&i==word.length()&&ROMAN_V[v].equals("i")?"ी":longEnding&&i==word.length()&&ROMAN_V[v].equals("u")?"ू":DEVA_M[v]);}else if(i<word.length())b.append('्');}m.appendReplacement(out,Matcher.quoteReplacement(b.toString()));}m.appendTail(out);return out.toString();}
    static List<String> variants(String query){String raw=query.trim(),roman=romanize(raw);LinkedHashSet<String> set=new LinkedHashSet<>();set.add(raw);if(raw.matches(".*[\\u0900-\\u097f].*")){String readable=roman.replace("ii","ee").replace("uu","oo");set.add(readable.replace("aa","a"));set.add(readable);}else if(raw.matches("(?i)[a-z\\s]+")){set.add(devanagari(raw,false));set.add(devanagari(raw,true));}String[] words=roman.split(" ");if(words.length>=2)set.add(String.join(" ",Arrays.copyOf(words,words.length-1)));else if(raw.matches("(?i)[a-z]{5,}"))set.add(raw.substring(0,raw.length()-1));set.remove("");return new ArrayList<>(set).subList(0,Math.min(4,set.size()));}
}
