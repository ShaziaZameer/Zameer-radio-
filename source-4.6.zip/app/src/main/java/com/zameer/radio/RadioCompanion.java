package com.zameer.radio;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.provider.CalendarContract;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

/** Explicit user initiated document, calendar and Android share-sheet operations. */
final class RadioCompanion {
    private static final int EXPORT=701, IMPORT=702, MAX_BYTES=2_000_000;
    private final Activity activity;
    private final Consumer<String> javascript, message;
    private final ExecutorService files=Executors.newSingleThreadExecutor();
    private byte[] pendingExport;
    private boolean busy;
    private int pendingRequest, requestGeneration;
    private volatile int generation;
    RadioCompanion(Activity a,Consumer<String> js,Consumer<String> msg){activity=a;javascript=js;message=msg;}
    private String t(String hi,String en){return "en".equals(AppLanguage.code(activity))?en:hi;}
    void exportBackup(String json){
        if(busy){message.accept(t("पहले खुली फ़ाइल प्रक्रिया पूरी करें।","Finish the open file operation first."));return;}
        try{
            byte[] bytes=json.getBytes(StandardCharsets.UTF_8);
            org.json.JSONObject o=new org.json.JSONObject(json);
            if(bytes.length>MAX_BYTES||!"com.zameer.radio".equals(o.optString("app"))||o.optInt("format")!=1)throw new IllegalArgumentException();
            pendingExport=bytes;busy=true;pendingRequest=EXPORT;requestGeneration=generation;
            activity.startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"Zameer-Radio-backup.json"),EXPORT);
        }catch(Exception e){busy=false;pendingExport=null;message.accept(t("बैकअप फ़ाइल नहीं खुली। आकार और फ़ाइल ऐप जाँचें।","Cannot open the backup file. Check its size and the Files app."));}
    }
    void importBackup(){
        if(busy){message.accept(t("पहले खुली फ़ाइल प्रक्रिया पूरी करें।","Finish the open file operation first."));return;}
        try{busy=true;pendingRequest=IMPORT;requestGeneration=generation;activity.startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"}),IMPORT);}
        catch(ActivityNotFoundException e){busy=false;message.accept(t("फ़ाइल चुनने वाला ऐप उपलब्ध नहीं है।","No document picker is available."));}
    }
    boolean result(int request,int result,Intent data){
        if(request!=EXPORT&&request!=IMPORT)return false;
        if(pendingRequest!=request||requestGeneration!=generation)return true;
        pendingRequest=0;final byte[] export=pendingExport;pendingExport=null;busy=false;
        if(result!=Activity.RESULT_OK||data==null||data.getData()==null)return true;
        final Uri uri=data.getData();if(!"content".equals(uri.getScheme()))return true;
        final int epoch=generation;
        if(request==EXPORT&&export==null){message.accept(t("ऐप दोबारा खुला है। बैकअप फिर सहेजें।","The app restarted. Please save the backup again."));return true;}
        files.execute(()->{
            try{
                if(epoch!=generation)return;
                if(request==EXPORT){
                    try(java.io.OutputStream out=activity.getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new java.io.IOException();out.write(export);}
                    activity.runOnUiThread(()->{if(epoch==generation)message.accept(t("बैकअप फ़ाइल सहेज दी गई।","Backup file saved."));});
                }else{
                    java.io.ByteArrayOutputStream buffer=new java.io.ByteArrayOutputStream();
                    try(java.io.InputStream in=activity.getContentResolver().openInputStream(uri)){if(in==null)throw new java.io.IOException();byte[] chunk=new byte[8192];int n;while((n=in.read(chunk))!=-1){if(buffer.size()+n>MAX_BYTES)throw new java.io.IOException("size");buffer.write(chunk,0,n);}}
                    final String json=new String(buffer.toByteArray(),StandardCharsets.UTF_8);
                    activity.runOnUiThread(()->{if(epoch==generation)javascript.accept("window.onPersonalBackup && window.onPersonalBackup("+org.json.JSONObject.quote(json)+")");});
                }
            }catch(Exception e){activity.runOnUiThread(()->{if(epoch==generation)message.accept(t("बैकअप पढ़ा या सहेजा नहीं जा सका। 2 MB से छोटी सही फ़ाइल चुनें।","Could not read or save the backup. Choose a valid file under 2 MB."));});}
        });return true;
    }
    void calendar(String json){
        try{
            org.json.JSONObject o=new org.json.JSONObject(json);long start=o.optLong("start"),end=o.optLong("end"),now=System.currentTimeMillis();
            if(start<now-60_000||start>now+366L*86400000||end<=start||end-start>86400000)throw new IllegalArgumentException();
            String title=o.optString("title"),description=o.optString("description");if(title.isEmpty()||title.length()>200||description.length()>5000)throw new IllegalArgumentException();
            Intent intent=new Intent(Intent.ACTION_INSERT,CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE,title).putExtra(CalendarContract.Events.DESCRIPTION,description)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME,start).putExtra(CalendarContract.EXTRA_EVENT_END_TIME,end)
                .putExtra(CalendarContract.Events.AVAILABILITY,CalendarContract.Events.AVAILABILITY_FREE);
            activity.startActivity(intent);
        }catch(ActivityNotFoundException e){message.accept(t("कैलेंडर ऐप नहीं मिला। कोई रिमाइंडर सहेजा नहीं गया।","No calendar app found. No reminder was saved."));}
        catch(Exception e){message.accept(t("कार्यक्रम का समय सही नहीं है। सूची दोबारा खोलें।","Invalid programme time. Reopen the list."));}
    }
    void share(String text){
        if(text==null||text.isEmpty()||text.length()>5000)return;
        try{activity.startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,text),t("स्टेशन साझा करें","Share station")));}
        catch(ActivityNotFoundException e){message.accept(t("साझा करने वाला ऐप नहीं मिला।","No sharing app is available."));}
    }
    void clear(){generation++;pendingRequest=0;pendingExport=null;busy=false;}
    void destroy(){clear();files.shutdown();}
}
