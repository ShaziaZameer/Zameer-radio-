package com.zameer.radio;

/** Bounded provider qualifiers shared by activity-independent assistant requests. */
final class CatalogCommand {
    final String provider, query;
    CatalogCommand(String provider,String query){this.provider=provider;this.query=query;}
    static CatalogCommand parse(String raw){
        String value=MusicRequest.normalize(raw);
        String[][] choices={{"all","all catalogs|all catalogues|सभी कैटलॉग|सभी कैटलोग|सभी catalog|सारे कैटलॉग"},{"both","both catalogs|दोनों कैटलॉग"},{"audius","audius|ऑडियस|ऑडियस कैटलॉग"},{"archive","internet archive|archive|इंटरनेट आर्काइव|आर्काइव"},{"ccmixter","ccmixter|cc mixter|सीसीमिक्सटर|सीसी मिक्स्टर"},{"commons","wikimedia commons|commons|विकिमीडिया कॉमन्स"},{"artistRadio","artist radio|कलाकार रेडियो|कलाकार लाइव रेडियो"}};
        for(String[] choice:choices){
            String names="(?:"+choice[1]+")";
            String rest=value.replaceFirst("^(?:(?:from|on|in) )?"+names+"(?: में से| में| से| पर| पे)?\\s+","")
                .replaceFirst("\\s+(?:from|on|in) "+names+"$","")
                .replaceFirst("(?:^|\\s+)"+names+" (?:में से|में|से|पर|पे)(?=\\s|$)"," ").replaceAll("\\s+"," ").trim();
            if(!rest.equals(value))return new CatalogCommand(choice[0],rest);
        }
        return new CatalogCommand("",value);
    }
}
